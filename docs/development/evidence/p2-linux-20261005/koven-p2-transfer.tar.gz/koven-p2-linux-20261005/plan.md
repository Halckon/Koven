# Koven P2 Linux 成本续验草案

日期：2026-10-05。范围仅为本云端；未开始性能测量，未安装 LLVM，未修改仓库、推送或清理用户文件。

## 已确认输入与剩余退出条件

- checkout：`__KOVEN_REPO__`，main `c5c4a8df271858b23898e0bcf4b55d823c760bb9`
- 本机 Debian 13/trixie x86_64，约 9.7 GiB RAM、无 swap、32 GiB 文件系统。frontend 全量产物约 1.1 GiB 后仍剩 28 GiB；工具链约 659 MiB
- 工具链环境入口：`source __CLOUD_WORKSPACE__/toolchain-env.sh`，Rust/Cargo 1.96.0
- 当前 main 不存在 `docs/development/p2-cost-retrospective.md`；有效入口是 `engineering-governance-plan.md` 的 P2、`governance-local-continuation.md`、`p2-frontend-cost-followup.md`
- `static-review.json` 已重核十对完整 SHA/tree/changed-path，每对 Cargo manifest、lockfile、toolchain 与 `.cargo` 配置 diff 都为空；400 个旧/新函数块摘要和九个生产文件摘要匹配已有证据
- 旧云端 raw 与部分旧本地对象（例如 `6cc87fe...`）仍缺失。不得生成替代对象假装恢复；本轮只使用存在的公开历史配对，新证据另列
- 关闭条件包括：身份与语义保全、每对冷/热 compile/link、固定执行与 RSS、受影响非默认 CI 的真实证据、明确噪声解释及由用户接受的退化预算。完成测量不自动等于已接受性能，也不关闭整个 P0–P5
- 当前最新 frontend 全量有两个失败，必须以主负责人的最终复核为准；本草案不把它称为通过，也不将历史成本对照当成修复

## 固定矩阵

所有构建均 `cargo test --locked --offline -j 2 ... --no-run --message-format=json`，`CARGO_INCREMENTAL=0`，默认 debug profile，Rust flags 仅加入同一链接计时 wrapper。不得复用全量 frontend 的 `CARGO_PROFILE_DEV_DEBUG=0` 等减符号覆盖而不声明新的 cohort。

| 顺序 | 配对 | 构建选择 | 固定执行 cohort | 仅热重编 touch 路径 | native LLVM |
|---|---|---|---|---|---|
| 1 | multifile ownership `f28359f→422786e` | `-p lang-frontend --test multifile_ownership_checking` | 全部72 | `crates/lang-frontend/tests/multifile_ownership_checking.rs` | 不需要 |
| 2 | ownership iteration `e30f9af→5b53bf6` | `-p lang-frontend --test ownership_iteration` | 全部184 | `crates/lang-frontend/tests/ownership_iteration.rs` | 不需要 |
| 3 | multifile type `b36d504→25f8977` | `-p lang-frontend --test multifile_type_checking` | 全部107 | `crates/lang-frontend/tests/multifile_type_checking.rs` | 不需要 |
| 4 | LSP `3418904→1f3991b` | `-p lang-lsp --bin lang-lsp` | `server::tests`，11 | `crates/lang-lsp/src/server.rs` | 不需要 |
| 5 | iteration private tests `9f9ee52→1df4df1` | `-p lang-frontend --lib` | `ownership_checking::checker::drop_planner::iteration::tests`，40 | `crates/lang-frontend/src/ownership_checking/checker/drop_planner/iteration.rs` | 不需要 |
| 6 | iteration production `14612da→1b24f45` | `-p lang-frontend --lib` | `ownership_checking::checker::drop_planner::iteration`，93（40+53） | 同上一行 | 不需要 |
| 7 | receiver tests `7318d53→7e542a5` | `-p lang-codegen --lib` | `unit_lower_receiver_tests`，46 | `crates/lang-codegen/src/ssa/unit_lower_receiver_tests.rs` | 需要 |
| 8 | plan tests `5e9a295→7720ea9` | `-p lang-codegen --lib` | `unit_plan_tests`，48 | `crates/lang-codegen/src/ssa/unit_plan_tests.rs` | 需要 |
| 9 | runtime layout `f329efa→61e6816` | `-p lang-codegen --lib` | `unit_plan_tests`，48 | `crates/lang-codegen/src/ssa/unit_plan.rs` | 需要 |
| 10 | unit planner `1b24f45→fa277de` | `-p lang-codegen --lib` | `unit_plan_tests`，48 | 同上一行 | 需要 |

完整 SHA 见 `static-review.json`。前七组测试迁移只测相应测试产物；三个生产迁移的成本是上列库测试产物的代表性结构成本，不冒充发布编译器或所有下游执行成本。

iteration production 另用同一侧最终源码执行一次完整 `ownership_iteration` 184 项并核身份；runtime layout 与 unit planner 复用对应已记录的双宿主完整 codegen/native 语义证据，若父任务判断本次必须重跑，作为独立语义验证，不混进48项固定成本 cohort。新成本样本只证明当前 Linux 宿主，不能冒充重测 macOS。

libtest 名称先从实际二进制 `--list` 获得，按已有映射一对一比较：保留 package/target/full_name、cfg/ignore、未变化身份；不得仅去任意前缀后靠数量认同一测试。integration 全 target 无 filter；窄 lib/bin 的原 substring filter 必须精确命中既有映射集合。执行统一 `--test-threads=1`，作为控制并行资源的新采样条件，不能直接与旧默认并行数字比较。

## 新 Linux 方法，执行前冻结

本节需在第一批 after 样本前固定到 protocol.json，记录协议文件与脚本 SHA256。它不改写旧 Mac 的范围/MAD停止线、失败、首启或归因。固定次数采完即报告，不因为不理想而循环重试。

1. 所有 Cargo 和成本执行严格串行，等待当前 frontend 复核结束。依赖预取、工具安装、文档校验、压缩及下载在计时之外，测量期间不并行执行它们。每侧从 `git archive` 导出干净源码，记录 tree、Cargo输入与命令环境白名单
2. 先做计时器小型自测（空进程与已知等待）并保留全部原值。主计时用 `perf_counter_ns` 围绕进程创建及 blocking `wait4`。超时/资源看门狗独立工作，绝不使用 `Popen.wait(timeout=...)` 的最高50ms轮询结果作短运行墙时。记录 spawn 与 observer 开销，不减去估算值来美化结果
3. 每组 before 校准固定：1次预构建、首次执行、3次真实目标重编且每次之后单列首次执行、随后10次同一不变二进制热执行。校准的散布是诊断；超线不删除数据，也不自动反复校准。仅发现计时错误、身份错误或资源不安全时停止相关测量
4. 正式冷构建3对，各自全新空 target，固定顺序 AB/BA/AB，即 ABBAAB；冷仅指构建产物缓存为空，registry缓存已热、OS page cache/宿主负载不受控。每个冷产物首次执行单列，不放进热执行
5. 热构建5对，固定 AB/BA/AB/BA/AB。只 touch 表中实际输入文件；每次 Cargo JSON 必须显示恰好目标 bin/lib-test/integration nonfresh，其他依赖 fresh。每次重编后的第一次执行独立记录，再进行后续热执行。touch 不更改文件字节
6. 固定热运行10对，AB/BA交替，直接执行已编译的二进制，不含 Cargo；不得重编后直接将第一轮算热运行。no-op 3对单列，所有artifact均 fresh、无 rustc/link 调用才算 no-op。first-launch、hot-run、no-op永不混合
7. 原始每次命令、stdout/stderr、退出码、JSON artifacts、rustc/link argv与PID关联、单调开始/结束、CPU与RSS、test summary、环境/负载、磁盘前后值全部保留。失败和停止也有 outcome.json；每条原始记录立即落盘

### 归因口径

- `RUSTC_WRAPPER` 记录每个 rustc；Cargo target linker wrapper 调用现有 `/usr/bin/cc` 并以环境传递父 rustc ID。两侧 wrapper 完全相同
- Rustc总 elapsed、嵌套 C linker driver elapsed 分别报告；`rustc elapsed − 嵌套 linker elapsed` 是包含 rustc前后开销的非链接区间，绝不叫 exclusive CPU。j2 时不同 rustc 区间可重叠，不能把相加值充当构建墙时
- Linux wait4 `ru_maxrss` 单位为 KiB；它是单个受等待进程及其已等待后代的最大报告峰值，既非同时进程树RSS，也不是各RSS之和。报告最大单进程值与原始逐进程值，另记录主机 MemAvailable/pressure 作为环境信息，不把它冒充本构建内存
- 保存 user/sys、minor/major faults、voluntary/involuntary context switches，帮助区分调度、页缓存和工作量线索；这些仍不能证明宿主上哪个活动造成差异
- 旧探针的 timeout polling 可引入最高约50ms观察延迟；旧 Mac 的 time/harness 本身也曾变慢，所以不据此推翻旧失败结论

### 冻结统计与结论边界

- 每阶段/每侧列完整序列、median、MAD、range、每对 after−before 与百分比；同时列每对峰值RSS差额与最大异常，不能只列中位数掩盖单对异常
- Linux诊断噪声线预定：`1.4826*MAD > max(5ms, 10% median)` 或 `range > max(20ms, 30% median)` 则标记不稳定。这是针对新计时器的工程诊断线，不是通用统计定理或旧结果豁免。保留所有不稳定阶段，继续其他独立组；不得以扩样采到过线为结束条件
- 预登记调查线：build增长 `max(20%, 1s)`；单进程RSS增长 `max(10%, 64MiB)`；execution增长 `max(30%, 20ms)`。检查配对中位和每个单对；一旦触发就用已保留阶段记录调查，独立诊断与正式 cohort 分开
- 三冷/五热构建样本只支撑有界描述和明显退化排查，不能给出性能等价或精确总体95%界限。若噪声大、方向互相矛盾或阶段归因不足，结论明确“不确定”，不强判通过
- 以上均非用户接受的成本预算。最终应区分“十组测量完成”“未见超过调查线的已观察差异”“噪声/退化需处理”“用户成本接受尚缺”；不能把前两项缩写为P2完全通过

## 资源预算与停止条件

- 初估十组需45–90分钟，生产iteration的93项cohort可能主导执行时间；不是交付保证。全批最多2小时测量墙时，单命令20分钟
- 当前28GiB空闲；保留至少8GiB空闲，本批新target合计最多10GiB；另外预留source/toolchain空间，MemAvailable低于1.5GiB不启动下一条命令。无swap环境出现OOM/kill明确失败，不用悄悄切profile、jobs或测试线程重做同一cohort
- 每组执行前按该组预构建产物大小估算六个冷target和两个热侧的占用；所有 raw 始终保留。已获父任务授权：每组完成后只清理本探针新建的该组targets，先保留全部raw/commands/env/source与二进制hash；不删 frontend target、用户缓存或旧证据，不执行 cargo clean。若单组就超过上限则停止
- 对纯新生成的临时target，如父任务明确授权在记录raw/hash后释放，则在协议中冻结精确路径范围和释放时点；仍每个冷样本从新空目录开始，不复制缓存冒充冷构建
- 编译/测试非零、映射不一致、缺失依赖、磁盘/时间/内存越界分别记录为失败/阻塞，保留所取得的数据。不得转去用户Mac，不推送或触发远端CI

## LLVM21.1.8 只读依赖调查

- 四个 codegen 配对的 Cargo依赖固定 `inkwell 0.10.0`、`llvm-sys 211.0.1`；feature为 `llvm21-1-prefer-dynamic`、AArch64、X86、`no-libffi-linking`
- 仓库官方CI脚本只支持Ubuntu24.04 Noble，不在Debian13执行或去掉宿主检查。Linux宿主合同为x86_64/glibc，本机符合宿主类别；当前并不等于复现Ubuntu exact CI镜像
- LLVM官方网站列出 Debian13 trixie 的 LLVM21 签名源：https://apt.llvm.org/ 。实际读取的官方索引：https://apt.llvm.org/trixie/dists/llvm-toolchain-trixie-21/main/binary-amd64/Packages.gz
- 索引确有21.1.8，精确版本为 `1:21.1.8~++20251221033036+2078da43e25a-1~exp1~20251221153213.50`，不同于Noble包后缀但同一上游commit `2078da43e25a`
- 完整包路径/依赖/SHA256在 `llvm-package-metadata.json`。十一项LLVM组件：llvm-21、llvm-21-dev、llvm-21-runtime、llvm-21-linker-tools、llvm-21-tools、libllvm21、clang-21、libclang-cpp21、libclang-common-21-dev、libclang1-21、libclang-rt-21-dev
- 这十一项合计下载117.752MiB、Installed-Size合计755.251MiB；还不含缺失的Debian依赖、解包临时量和下载缓存，安装/工作区提取建议预留1.5GiB。无需源码构建LLVM、lldb、flang、mlir或完整工具大包
- 系统 dpkg 数据库不可用于确认依赖（对libc等均返回no packages），不能据此断言所有库都缺失。需用实际loader/库路径、glibc版本及解包后`ldd`/工具实跑核定，不能把元数据依赖满足冒充实际可运行
- 安装前验证签名主key指纹 `6084F3CF814B57C1CF12EFD515CF4D18AF4F7421`、InRelease签名→Packages SHA256→每个deb SHA256；本调查保留索引但工具可用性仍未实测
- 首选工作区隔离提取官方匹配包，不写系统apt配置；最终冻结 `LLVM_SYS_211_PREFIX` 与必需动态库路径。若无法满足正式依赖或工具自检，就报告四组阻塞，不换LLVM22或依赖Rust内置LLVM
- 验收工具：`llvm-config --version`精确21.1.8，`--targets-built`含AArch64/X86，匹配`clang --version`和`llvm-dwarfdump --version`，动态库loader全部解析；系统`/usr/bin/cc`真实link/run。完整native/sanitizer复核还需要匹配compiler-rt与资源目录

## 交付

每组协议/原始数据/身份/统计/退出状态，以及跨十组状态总表；原始与发布版hash分开，敏感本机路径脱敏但不改数值。新证据与旧macOS/失效旧云端记录严格分列。原始阶段不确定性、两个frontend失败和未接受预算都如实保留。
