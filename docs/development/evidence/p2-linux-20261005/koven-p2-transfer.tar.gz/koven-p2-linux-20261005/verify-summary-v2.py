#!/usr/bin/env python3
"""Cross-check summary-v2 against the separately implemented raw audit."""
from pathlib import Path
import hashlib
import json
import math
import subprocess
import sys

B=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
audit=read(B/'independent-audit-initial.json')
errors=[]
metric_series=0
inquiry_comparisons=0
noise_keys=[]
for key,group in audit['groups'].items():
    v2=read(B/key/'summary-v2.json')
    if v2['sample_count']!=group['rows']:errors.append(key+': count')
    for phase,metrics in group['all_phase_statistics'].items():
        for metric,sides in metrics.items():
            for side,expected in sides.items():
                got=v2['phases'][phase]['time_metrics'][metric][side]
                metric_series+=1
                for field in ['values','median','mad','range']:
                    if got[field]!=expected[field]:errors.append(f'{key}/{phase}/{metric}/{side}/{field}')
                if len(expected['values'])>1 and got['noise_flag']!=expected['noise_flag']:errors.append(f'{key}/{phase}/{metric}/{side}/noise')
                if got['noise_flag']:noise_keys.append((key,phase,metric,side))
    for phase,expected in group['investigations'].items():
        if 'time_investigation' not in v2['phases'][phase]:
            if phase!='identity':errors.append(key+'/'+phase+': missing inquiry')
            continue
        got=v2['phases'][phase]['time_investigation'];inquiry_comparisons+=1
        if got['paired_delta']!=expected['paired_delta_seconds'] or got['hit_pair_indices']!=expected['time_pairs'] or got['paired_median_hit']!=expected['time_paired_median']:errors.append(key+'/'+phase+': time inquiry')
        if phase in ['cold','warm']:
            got=v2['phases'][phase]['build_rss_investigation'];inquiry_comparisons+=1
            if got['paired_delta']!=expected['paired_delta_reported_rss_kib'] or got['hit_pair_indices']!=expected['rss_pairs'] or got['paired_median_hit']!=expected['rss_paired_median']:errors.append(key+'/'+phase+': build RSS inquiry')
    if v2['c_child_rss']:
        source_key=str(Path(v2['c_child_rss']['source_group']).relative_to(B));expected=audit['groups'][source_key]['c_child_rss'];got=v2['c_child_rss'];inquiry_comparisons+=1
        if got['values_kib']!=expected['values_kib'] or got['investigation']['paired_delta']!=expected['paired_delta_kib'] or got['investigation']['hit_pair_indices']!=expected['investigation_pairs'] or got['investigation']['paired_median_hit']!=expected['investigation_paired_median']:errors.append(key+': true C RSS')
expected_noise_keys=[(r['group'],r['phase'],r['metric'],r['side']) for r in audit['noise_flags']]
if sorted(noise_keys)!=sorted(expected_noise_keys):errors.append('full phase noise sets differ')
# Run the completed correction a second time under a byte-level immutability check.
original_paths=[B/'probe-frozen-v1.py',B/'rss_support.py',B/'rss-observer.c',B/'plan.md']
for directory in B.glob('run-*'):
    original_paths.extend(p for p in directory.rglob('*') if p.is_file() and '/sources/' not in str(p) and '/targets/' not in str(p) and p.suffix in ['.json','.log'] and p.name!='summary-v2.json')
# No large archives, toolchain or binary payloads are hashed.
before={str(p.relative_to(B)):hashfile(p) for p in sorted(set(original_paths))}
summary_before={str(p.relative_to(B)):hashfile(p) for p in B.glob('run-*/*/summary-v2.json')}
proc=subprocess.run([sys.executable,str(B/'summarize-v2.py')],capture_output=True,text=True)
(B/'summary-v2-repeat.log').write_text(proc.stdout+proc.stderr)
after={str(p.relative_to(B)):hashfile(p) for p in sorted(set(original_paths))}
changed=[k for k,v in before.items() if after[k]!=v]
if proc.returncode:errors.append('second derivation returned '+str(proc.returncode))
if changed:errors.append('original inputs changed: '+str(changed))
summary_after={str(p.relative_to(B)):hashfile(p) for p in B.glob('run-*/*/summary-v2.json')}
if summary_before!=summary_after:errors.append('v2 derivation not deterministic')
result={'status':'passed' if not errors else 'failed','metric_series_compared':metric_series,'paired_inquiries_compared':inquiry_comparisons,'noise_entries_compared':len(noise_keys),'original_small_files_hash_checked':len(before),'originals_changed':changed,'derived_summaries_deterministic':summary_before==summary_after,'recompute_exit_code':proc.returncode,'errors':errors,'original_input_hashes':before,'summary_v2_hashes':summary_after,'verification_script_sha256':hashfile(Path(__file__))}
(B/'summary-v2-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['original_input_hashes','summary_v2_hashes']},indent=2))
sys.exit(bool(errors))
