#!/usr/bin/env python3
"""Separate RSS-only evidence for the three groups whose v1 targets retired."""
import importlib.util
import json
import os
from pathlib import Path
import sys
import rss_support

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_p2',HERE/'probe-frozen-v1.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
p.RUN=HERE/'run-20261005-rss-only'
p.RUN.mkdir()
selected=p.CONFIGS[:3]
rss_support.freeze(p,p.RUN,[c[0] for c in selected],'RSS-only supplement for first three retired targets; one binary preparation build per side, no new cold/warm performance comparison')
p.save(p.RUN/'preparation.json',{'driver_sha256':p.digest(Path(__file__)),
       'rustc':p.get('rustc','-vV'),'cargo':p.get('cargo','-V'),
       'profile':'default debug, jobs2, incremental0, identical frozen-v1 wrappers',
       'environment':{k:os.environ[k] for k in ['CARGO_HOME','RUSTUP_HOME','PATH'] if k in os.environ}})
for mode in ['rustc','link']:
    path=p.RUN/(mode+'-wrapper')
    path.write_text('#!/bin/sh\nexec '+sys.executable+' '+str(HERE/'probe-frozen-v1.py')+' '+mode+' "$@"\n')
    path.chmod(0o755)
for config in selected:
    name,package,selection,filt,count,touch,mapping=config
    old=HERE/'run-20261005'/name
    group=p.RUN/name;group.mkdir();(group/'targets').mkdir()
    (group/'sources').symlink_to(old/'sources',target_is_directory=True)
    cfg=json.loads((old/'protocol.json').read_text())
    cfg['original_cost_group']=str(old)
    cfg['source_manifest_sha256']=p.digest(old/'source-inputs.json')
    p.save(group/'protocol.json',cfg)
    command=['cargo','test','--locked','--offline','-j','2','-p',package,*selection,'--no-run','--message-format=json']
    try:
        latest={}
        for side in ['before','after']:
            target=group/'targets'/side
            row=p.sample(group,'preparation-build-'+side,side,'rss-preparation-build',command,target)
            latest[side]={'binary':p.binary(row),'target':target}
        p.identity(group,cfg,latest)
        rss_support.supplement(p,group)
        p.save(group/'outcome.json',{'status':'RSS measured','samples':len(json.loads((group/'samples.json').read_text())),
             'cost_comparison':'none; preparation builds are not formal cold/warm samples','acceptance':'not approved'})
        p.cleanup_targets(group)
    except Exception as ex:
        p.save(group/'outcome.json',{'status':'stopped','reason':repr(ex)})
        raise
print('FIRST THREE RSS SUPPLEMENTS COMPLETE',flush=True)
