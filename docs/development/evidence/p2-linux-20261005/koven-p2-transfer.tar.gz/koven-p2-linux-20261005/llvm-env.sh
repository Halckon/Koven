export LLVM_SYS_211_PREFIX=__P2_EVIDENCE_DIR__/llvm-21-local/usr/lib/llvm-21
export LD_LIBRARY_PATH=__P2_EVIDENCE_DIR__/llvm-21-local/usr/lib/x86_64-linux-gnu:__P2_EVIDENCE_DIR__/llvm-21-local/usr/lib/llvm-21/lib
