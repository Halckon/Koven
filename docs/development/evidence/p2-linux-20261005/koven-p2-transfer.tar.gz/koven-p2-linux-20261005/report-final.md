# P2 Linux 十组有界成本续验（2026-10-05）

> **性质**：有界成本验收记录 · **状态**：十组采样完成，整体接受仍开放 · **读取时机**：复核本轮 Linux 成本与证据、接续 Spec 时 · **唯一真源**：本页的本轮结论及链接的原始证据；整体退出条件仍从属已批准治理计划

## 1. 结果与边界

十组固定配对的冷构建、仅目标重编、首启、热执行、no-op 与独立 C child RSS 采样均已完成。全部原值、失败及中断保留；不删除异常值，不扩样直到过线。正式成本的调查结果、所有阶段噪声与独立审计见下表及附件。**调查线不是用户接受的成本预算，采样完成不是 P2 整体通过，也不是性能等价证明。**

主入口固定为 main `c5c4a8df271858b23898e0bcf4b55d823c760bb9`。成本采样期间未修改编译器、测试或仓库配置，未推送。基线 main 的独立 frontend 全量 **1701 passed / 2 failed / 0 ignored**，默认 debug 的定向复跑仍失败；两项陈旧测试预期涉及长十六进制字面量与上下文关键字清单。详见 [frontend 报告](frontend-validation/frontend-report.md)及[逐目标结果](frontend-validation/frontend-results.json)。该失败不能由历史成本成功覆盖，后续修复/复测必须另记新 SHA。

本结果只适用于本 Debian Linux 宿主、下列历史 SHA 与固定测试产物。旧 macOS 超噪声线结果和停止结论不变；旧云端 raw 及部分历史对象缺失仍未恢复。新成本证据不冒充原记录或macOS重测；本轮另以只读API核验的当前精确head CI如下，仍不替代frontend全量。

## 2. 固定输入与方法

Debian 13.6/trixie x86_64、glibc 2.41、约9.7 GiB RAM、无swap；Rust/Cargo 1.96.0。codegen 使用隔离提取的官方 LLVM/Clang **21.1.8**；Rust 内置 LLVM22.1.2 不是本 native 依赖。工具包签名链、SHA256、loader、C/IR真实link/run核验在[LLVM核验](llvm-toolchain-verification.json)与[下载核验](llvm-download-verification.json)。不称复现 Ubuntu24.04 exact CI镜像。

- 两侧从固定公开 SHA 的 git archive 导出；完整 tree/changed-path/构建输入见[静态核验](static-review.json)，每组保留 source-inputs.json 和源归档摘要
- 默认 debug，CARGO_INCREMENTAL=0，--locked --offline -j2，同一 rustc/linker wrapper；执行 --test-threads=1。清除 CARGO_PROFILE_*；独立frontend全量减符号profile不混入成本
- before校准：1次预构建，3次仅目标重编，每次之后首次执行单列，再10次热执行
- 正式冷构建3对，AB/BA/AB，各自空target；仅目标重编5对，AB/BA交替，仅touch真实输入且字节不变
- 每个冷产物及每次热重编后的首次执行单列；固定热执行10对，AB/BA交替，直接运行二进制不含Cargo；no-op3对，BA/AB/BA
- 仅目标重编时Cargo JSON核恰好目标nonfresh、其他依赖fresh；no-op全部fresh且无rustc/link调用。各阶段绝不混合统计
- 独立C observer先各侧预热一次，再5对AB/BA child RSS；准备重建与补测墙时不并入正式成本

主墙时为 perf_counter_ns 围绕进程创建与 blocking wait4；不使用 timeout polling 测短运行、不减估算观察开销。逐调用保留命令、stdout/stderr、退出码、单调时间、CPU、RSS、fault、context-switch、Cargo artifacts和环境。计时器自测及独立C RSS校准均另存，证明本次探针机制，不证明主机恒定。

Linux新诊断噪声线：1.4826×MAD > max(5ms,10% median)，或 range > max(20ms,30% median)。这是采after前冻结的诊断条件，不是旧Mac停止线修改；继续固定样本，保留全部噪声。调查线：构建增长 max(20%,1s)，执行增长 max(30%,20ms)，RSS增长 max(10%,64MiB)，同时查各单对和配对中位。三/五/十对仅支持有界描述。

原方法与冻结脚本：[计划](plan.md)、[probe](probe-frozen-v1.py)、[frontend协议](run-20261005/protocol-frontend.json)、[recovery协议](run-20261005-recovery/protocol-frontend.json)、[codegen协议](run-20261005-codegen/protocol-codegen.json)、[C RSS方法](rss_support.py)。

### 固定配对与执行范围

| 配对 | before→after | 目标与固定执行filter | 每次执行数量 |
|---|---|---|---:|
| multifile-ownership | f28359f→422786e | lang-frontend --test multifile_ownership_checking；整个integration target | 72 |
| ownership-iteration | e30f9af→5b53bf6 | lang-frontend --test ownership_iteration；整个integration target | 184 |
| multifile-type | b36d504→25f8977 | lang-frontend --test multifile_type_checking；整个integration target | 107 |
| lsp | 3418904→1f3991b | lang-lsp --bin lang-lsp；server::tests | 11 |
| iteration-tests | 9f9ee52→1df4df1 | lang-frontend --lib；ownership_checking::checker::drop_planner::iteration::tests | 40 |
| iteration-production | 14612da→1b24f45 | lang-frontend --lib；ownership_checking::checker::drop_planner::iteration | 93 |
| receiver | 7318d53→7e542a5 | lang-codegen --lib；unit_lower_receiver_tests | 46 |
| plan-tests | 5e9a295→7720ea9 | lang-codegen --lib；unit_plan_tests | 48 |
| runtime-layout | f329efa→61e6816 | lang-codegen --lib；unit_plan_tests | 48 |
| unit-planner | 1b24f45→fa277de | lang-codegen --lib；unit_plan_tests | 48 |

三个生产迁移的库测试产物仅是代表性结构成本，不冒充发布编译器或所有下游执行成本。

## 3. 全十组固定结果

秒；Δ为各对after−before的中位，Δ%为各对百分比的中位，不能用两侧中位数相减替代。每个完整序列、MAD、range、单对RSS均在对应summary/raw。

| 配对 | 冷构建 B/A；Δ% | 热构建 B/A；Δ% | 热执行 B/A；Δ% | 最大单对增长（冷/热/执行，秒） |
|---|---:|---:|---:|---:|
| multifile-ownership | 16.1958/15.7042；-0.69% | 1.0418/1.1107；+6.24% | 0.2529/0.2479；-2.98% | +0.0040 / +0.0781 / +0.0053 |
| ownership-iteration | 18.7474/18.7790；-0.31% | 3.6714/3.7796；+2.95% | 0.7710/0.7907；+1.97% | +0.0782 / +0.1758 / +0.0389 |
| multifile-type | 16.4046/16.4013；+0.61% | 1.5767/1.5775；-0.87% | 0.2704/0.2746；+0.72% | +0.8709 / +0.1330 / +0.0407 |
| lsp | 22.1524/23.0276；+3.73% | 2.4083/2.3719；+1.28% | 0.1504/0.1531；+1.49% | +1.2627 / +0.1184 / +0.0064 |
| iteration-tests | 22.0003/24.0990；+4.58% | 23.2981/22.0799；-3.68% | 0.1520/0.1489；-2.85% | +2.0987 / +1.3716 / +0.0119 |
| iteration-production | 24.7625/26.1647；+4.79% | 25.3682/25.7374；+1.76% | 38.9124/39.2908；+0.41% | +2.0774 / +1.8168 / +1.4065 |
| receiver | 36.7141/36.8696；-0.62% | 14.4072/15.1139；+4.62% | 0.1898/0.1880；-1.06% | +0.5475 / +0.8380 / +0.0141 |
| plan-tests | 38.8705/37.4067；-3.64% | 14.1202/13.7459；-1.34% | 0.1786/0.1787；+0.05% | +0.9640 / -0.0297 / +0.0081 |
| runtime-layout | 35.9411/36.0664；+2.90% | 15.3749/15.3471；-0.90% | 0.1783/0.1785；+0.01% | +1.6220 / +0.1292 / +0.0137 |
| unit-planner | 37.3885/38.2936；+0.85% | 15.2702/15.4919；+1.73% | 0.1764/0.1744；-2.26% | +1.6942 / +1.0847 / +0.0076 |

正式冷构建/热构建/热执行的单对与配对中位时间调查线：未触发。

### 首启与no-op（B中位/A中位/配对Δ中位，秒）

| 配对 | 冷产物首启（每侧3） | 热重编后首启（每侧5） | no-op（每侧3） |
|---|---:|---:|---:|
| multifile-ownership | 0.2632/0.2696/+0.0063 | 0.2494/0.2523/+0.0038 | 0.0360/0.0320/-0.0038 |
| ownership-iteration | 0.7989/0.8492/+0.0313 | 0.7799/0.7914/+0.0076 | 0.0324/0.0331/+0.0007 |
| multifile-type | 0.2742/0.3161/+0.0346 | 0.2768/0.2715/-0.0016 | 0.0332/0.0326/-0.0016 |
| lsp | 0.1532/0.1578/+0.0049 | 0.1515/0.1548/+0.0047 | 0.0401/0.0385/-0.0014 |
| iteration-tests | 0.1469/0.1623/+0.0163 | 0.1619/0.1590/-0.0029 | 0.0366/0.0393/+0.0027 |
| iteration-production | 38.8242/38.7902/-0.4971 | 39.2038/39.2354/+0.4782 | 0.0387/0.0457/+0.0026 |
| receiver | 0.2020/0.2041/-0.0034 | 0.2007/0.1995/-0.0096 | 0.0665/0.0674/+0.0009 |
| plan-tests | 0.1781/0.2062/+0.0225 | 0.1818/0.1862/+0.0044 | 0.0636/0.0637/+0.0019 |
| runtime-layout | 0.1896/0.1770/-0.0150 | 0.1839/0.1946/+0.0107 | 0.0601/0.0592/-0.0002 |
| unit-planner | 0.1870/0.1880/+0.0015 | 0.1860/0.1806/-0.0125 | 0.0637/0.0643/+0.0016 |

### 编译/链接归属（before/after中位秒）

非link是rustc elapsed减其嵌套cc driver elapsed，包含rustc前后开销；j2可重叠，sum不是总墙时或exclusive CPU。link是完整cc driver，不是纯ld。非link sum按冻结脚本只统计带分离式--crate-name参数的rustc；依赖build.rs内部以--crate-name=形式进行的能力探测未计入该sum，仍完整保留raw。部分探测rustc退出1是依赖的预期能力检测，不能混称Cargo或目标测试失败。

| 配对 | 冷非link sum | 冷link sum | 热非link sum | 热link sum |
|---|---:|---:|---:|---:|
| multifile-ownership | 15.7355/15.2599 | 0.1970/0.2061 | 0.7810/0.8352 | 0.1830/0.1914 |
| ownership-iteration | 18.2578/18.2621 | 0.2285/0.2296 | 3.3486/3.4771 | 0.2449/0.2398 |
| multifile-type | 15.9270/15.9267 | 0.2100/0.2194 | 1.2807/1.2875 | 0.2286/0.2159 |
| lsp | 30.0304/31.2237 | 0.5093/0.5185 | 2.0512/2.0148 | 0.2663/0.2716 |
| iteration-tests | 21.4943/23.5132 | 0.2631/0.3231 | 22.9713/21.7389 | 0.2629/0.2683 |
| iteration-production | 24.2432/25.6409 | 0.2692/0.2855 | 24.9635/25.3582 | 0.2694/0.2916 |
| receiver | 39.6950/39.7819 | 0.7553/0.7178 | 13.8834/14.4791 | 0.4125/0.4620 |
| plan-tests | 42.0008/40.4270 | 0.7208/0.7167 | 13.6469/13.2404 | 0.4204/0.3816 |
| runtime-layout | 38.8065/38.8433 | 0.7107/0.6753 | 14.7265/14.7902 | 0.4574/0.4168 |
| unit-planner | 40.1640/41.0684 | 0.7341/0.7122 | 14.7287/14.9826 | 0.3805/0.4485 |

## 4. 全阶段噪声、归因与独立审计

[独立审计](independent-audit.md)与[机器可读结果](independent-audit.json)从raw重算，覆盖所有正式阶段、校准重编/热执行、单独三次校准重编首启、内部非link/link区间与C child RSS。单次校准预构建/首启无散布估计；RSS没有另冻结MAD噪声门禁，不称“RSS噪声通过”。审计发现与限制必须随本报告传递。

独立审计确认唯一正式执行调查触发是首启单对：plan-tests冷产物首启第2对after比before增加0.057241119秒（35.3884%），超过execution调查线，配对中位未触线。冻结summary仅对cold/warm/run生成调查标志，独立审计将遗漏的首启phase也纳入检查；该后处理不改原采样方法或原值。完整触线清单以独立审计为准。

噪声清单和逐进程资源线索用于说明差异发生在哪个区间，不能确定未知宿主负载来源，也不能将全部差额归因于模块拆分。若某phase噪声较大，该phase解释为不确定；总墙时不触线不代表所有内部阶段稳定。

独立审计终态：917条完整记录、4964份raw摘要核对、0条一致性错误；12条指标噪声、1处时间单对调查命中、0处构建或C child RSS调查命中。辅助rustc记录342条，其中91次退出1为已识别依赖能力探测，另列为工具边界。

| 配对 | 阶段/指标/侧 | median | MAD | range | 触发项 |
|---|---|---:|---:|---:|---|
| multifile-type | cold / linker_seconds_sum / after | 0.219382 | 0.009963 | 0.129608 | range |
| plan-tests | cold / auxiliary_rustc_seconds_sum / before | 0.104527 | 0.009131 | 0.018468 | scaled MAD |
| receiver | warm / linker_seconds_sum / after | 0.461964 | 0.033580 | 0.121412 | scaled MAD |
| runtime-layout | warm / linker_seconds_sum / before | 0.457402 | 0.064849 | 0.135333 | scaled MAD |
| runtime-layout | rss-run / seconds / after | 0.191118 | 0.015575 | 0.051659 | scaled MAD |
| runtime-layout | rss-run / c_child_seconds / after | 0.189614 | 0.015367 | 0.051453 | scaled MAD |
| iteration-production | warm / linker_seconds_sum / before | 0.269356 | 0.019536 | 0.071582 | scaled MAD |
| iteration-production | noop / seconds / before | 0.038729 | 0.003634 | 0.026968 | scaled MAD, range |
| iteration-tests | calibration-rebuild-first-launch / seconds / before | 0.154692 | 0.013438 | 0.037011 | scaled MAD |
| iteration-tests | calibration-run / seconds / before | 0.158597 | 0.002890 | 0.048051 | range |
| iteration-tests | cold / linker_seconds_sum / after | 0.323064 | 0.050245 | 0.102041 | scaled MAD, range |
| iteration-tests | warm / linker_seconds_sum / before | 0.262858 | 0.022714 | 0.089477 | scaled MAD, range |

RSS补测外层与C内部child墙时的两条噪声来自同一补测事件，不能当作两次独立异常；它们都不混入正式10对热运行。plan-tests首启慢样本的CPU总量0.066837→0.108116秒，非自愿上下文切换4→21，major faults均0；这些是工作/调度线索，不足以归因模块迁移或特定宿主活动。

### 汇总遗漏修复（采样结束后）

冻结summary未给两类first-launch生成execution调查标志。已新增[summarize-v2.py](summarize-v2.py)，直接读取raw/sample.json并核samples索引一致；原probe、summary、协议和raw不变。v2区分单对/配对中位、噪声/调查线/接受决定，将校准预构建首启与重编首启分开，并禁止Python launcher RSS回退。详见[修复说明](summary-v2-repair.md)、[验证结果](summary-v2-validation.json)、[最终20项回归日志](summary-v2-tests-final.log)及[v2结果索引](summary-v2-index.json)。

最终20项Python回归通过，首轮16项日志另保留；14个组/attempt共917条记录完成重算。独立audit与v2核462条指标序列、118项配对调查和12条噪声完全一致；第二次重算确定性一致，5099份原始小文件hash不变。新增结果为各组summary-v2.json，旧summary继续保留；不重新采样、不筛值、不将调查触发改称代码性能退化。

## 5. RSS与资源

Linux wait4 ru_maxrss为KiB，表示被等待进程及已等待后代的最大报告峰值；不是同时进程树RSS或RSS之和。构建表用各报告进程最大值。Python fork会污染小child高水位，原run RSS仍完整保留但不用于测试child接受；真实child来自exec后小C observer内部wait4。18条正常/膨胀父进程校准可分离该污染，true仍有384KiB启动地板，见[校准](rss-observer-calibration/summary.json)。

| 配对 | 冷构建RSS B/A（MiB） | 热构建RSS B/A（MiB） | C child B/A（KiB） | C配对Δ中位；最小…最大（KiB） |
|---|---:|---:|---:|---:|
| multifile-ownership | 2000.883/1973.609 | 488.809/490.199 | 11004/11100 | +96；-156…+128 |
| ownership-iteration | 1998.191/2034.773 | 591.738/587.719 | 14812/14716 | +80；-148…+132 |
| multifile-type | 2041.414/2019.641 | 499.324/500.488 | 12776/13032 | +244；+8…+520 |
| lsp | 2017.793/2016.676 | 579.070/579.199 | 18868/18720 | -136；-256…+248 |
| iteration-tests | 2537.250/2527.852 | 2554.984/2527.953 | 19324/19416 | +12；-212…+144 |
| iteration-production | 2498.160/2513.211 | 2504.152/2522.832 | 21848/21900 | +56；-348…+380 |
| receiver | 2024.613/1964.160 | 1487.191/1485.328 | 77844/77440 | -308；-496…+304 |
| plan-tests | 2020.562/1980.480 | 1524.391/1502.113 | 75296/75596 | +584；+140…+1120 |
| runtime-layout | 1979.852/1963.812 | 1559.148/1516.992 | 76144/75940 | -336；-484…+588 |
| unit-planner | 1978.199/2004.605 | 1519.219/1567.391 | 75888/76120 | +156；-96…+912 |

每批两小时保护预算、单命令20分钟、剩余磁盘≥8GiB、新targets≤10GiB、命令启动前MemAvailable≥1.5GiB。free有1秒watchdog；target总量只在命令边界检查，不能称逐秒硬峰值。无swap，命令非零/身份错误/资源不安全必须停止相关采样。

| 组 | 完整记录数 | 边界最大target（GiB） | 边界最低free（GiB） | 最大单命令（秒） |
|---|---:|---:|---:|---:|
| multifile-ownership | 78 | 2.4206 | 25.0473 | 16.421 |
| ownership-iteration | 78 | 2.5652 | 24.8192 | 19.531 |
| multifile-type | 78 | 2.4373 | 24.8642 | 17.717 |
| lsp | 90 | 3.4052 | 23.7077 | 23.415 |
| iteration-tests | 90 | 1.0541 | 25.9769 | 25.454 |
| iteration-production | 94 | 1.7925 | 25.1496 | 41.015 |
| receiver | 90 | 3.5864 | 22.4059 | 38.173 |
| plan-tests | 90 | 3.5990 | 22.3085 | 39.738 |
| runtime-layout | 90 | 3.6249 | 22.1901 | 36.984 |
| unit-planner | 90 | 3.6314 | 22.0900 | 38.517 |

计数包含校准、身份、首启、RSS等，不能混成一个cohort；原始LSP失败另存。仅探针自建targets在raw/source/命令/环境/二进制hash保存后按授权释放；target-retirement列精确路径与raw摘要。未删除frontend targets、用户缓存或旧证据，没有cargo clean。

## 6. 失败与中断，全部保留

- 原LSP before校准因offline缺bitflags1.3.2退出101，未产生正式配对；[失败outcome](run-20261005/lsp/outcome.json)保留。补齐同一锁定依赖后，在recovery新attempt继续，不覆写失败、不计下载为成本
- 第9组runtime-layout在第三次before校准重编中进程消失，仅有部分stdout/stderr，没有可靠退出码/耗时；[未完成raw](run-20261005-codegen/runtime-layout/raw/calibration-warm-2/stderr.log)原样保留。已完成6条校准样本不重复，缺少一条用-resumed名称补完，随后按原固定顺序采样
- [续跑记录](run-20261005-codegen/resumption-context.json)核两侧源码/源归档与冻结hash相同、工具链不变，重新独立计时器自检；原codegen两小时预算含中断继续，不重置。未补造中断退出值，跨中断校准连续性作为限制保留
- Python RSS污染的原始值不删除；[C校准](rss-observer-calibration/summary.json)与独立RSS补测另列，不用修改观察器把旧值改成通过

## 7. 身份、语义及下一步

十组完整Linux libtest名称集合与逐名映射相等；选定cohort每次实际执行均达到预定数量、0failed/ignored/measured。--list仅证明当前编译cfg下集合，不直接输出cfg/ignore属性；静态迁移块摘要及历史语义证据需联合使用，不能以数量相等替代全部语义保全。iteration production另独立运行两侧ownership_iteration184项；48项planner成本cohort不是全部codegen/native。

[语义/非默认覆盖审计](semantic-coverage-audit.md)按历史精确SHA、宿主、命令和真实证据区分覆盖与缺项。只读GitHub API另核当前main精确c5c4a8df的[CI37248672159](https://github.com/Halckon/Koven/actions/runs/37248672159)15/15jobs成功且tree匹配；Ubuntu的bounded composition、word-frequency、Linux sanitizer实际success，macOS前两项success、Linux专属sanitizer按设计skipped。这不是frontend全量，也不证明修复后分支；剩余历史覆盖限制和新head必需门禁按新Spec逐项记录。

本次交接完成的是可追溯的十组Linux成本证据。仍需：
1. 将已修复并云端验证的frontend补丁（见§9）纳入Mac新main派生Spec分支，核适用性并记录本地交付门禁；不改生产语义迎合测试
2. 对噪声/不确定阶段和成本预算取得明确接受，不能把调查线视作自动预算
3. 按语义审计补受影响的非默认/双宿主与精确head验证，保留未运行项
4. 纳入新Spec及文档索引后运行check_docs.py和git diff --check，实际验证发布版链接、脱敏与摘要；不在本报告中宣称已提交、已推送或PR/CI完成

## 8. 逐组证据入口

| 配对 | protocol / summary / identity / outcome | C child RSS |
|---|---|---|
| multifile-ownership | [protocol](run-20261005/multifile-ownership/protocol.json) · [summary](run-20261005/multifile-ownership/summary.json) · [identity](run-20261005/multifile-ownership/identities.json) · [outcome](run-20261005/multifile-ownership/outcome.json) | [RSS](run-20261005-rss-only/multifile-ownership/rss-summary.json) |
| ownership-iteration | [protocol](run-20261005/ownership-iteration/protocol.json) · [summary](run-20261005/ownership-iteration/summary.json) · [identity](run-20261005/ownership-iteration/identities.json) · [outcome](run-20261005/ownership-iteration/outcome.json) | [RSS](run-20261005-rss-only/ownership-iteration/rss-summary.json) |
| multifile-type | [protocol](run-20261005/multifile-type/protocol.json) · [summary](run-20261005/multifile-type/summary.json) · [identity](run-20261005/multifile-type/identities.json) · [outcome](run-20261005/multifile-type/outcome.json) | [RSS](run-20261005-rss-only/multifile-type/rss-summary.json) |
| lsp | [protocol](run-20261005-recovery/lsp/protocol.json) · [summary](run-20261005-recovery/lsp/summary.json) · [identity](run-20261005-recovery/lsp/identities.json) · [outcome](run-20261005-recovery/lsp/outcome.json) | [RSS](run-20261005-recovery/lsp/rss-summary.json) |
| iteration-tests | [protocol](run-20261005-recovery/iteration-tests/protocol.json) · [summary](run-20261005-recovery/iteration-tests/summary.json) · [identity](run-20261005-recovery/iteration-tests/identities.json) · [outcome](run-20261005-recovery/iteration-tests/outcome.json) | [RSS](run-20261005-recovery/iteration-tests/rss-summary.json) |
| iteration-production | [protocol](run-20261005-recovery/iteration-production/protocol.json) · [summary](run-20261005-recovery/iteration-production/summary.json) · [identity](run-20261005-recovery/iteration-production/identities.json) · [outcome](run-20261005-recovery/iteration-production/outcome.json) | [RSS](run-20261005-recovery/iteration-production/rss-summary.json) |
| receiver | [protocol](run-20261005-codegen/receiver/protocol.json) · [summary](run-20261005-codegen/receiver/summary.json) · [identity](run-20261005-codegen/receiver/identities.json) · [outcome](run-20261005-codegen/receiver/outcome.json) | [RSS](run-20261005-codegen/receiver/rss-summary.json) |
| plan-tests | [protocol](run-20261005-codegen/plan-tests/protocol.json) · [summary](run-20261005-codegen/plan-tests/summary.json) · [identity](run-20261005-codegen/plan-tests/identities.json) · [outcome](run-20261005-codegen/plan-tests/outcome.json) | [RSS](run-20261005-codegen/plan-tests/rss-summary.json) |
| runtime-layout | [protocol](run-20261005-codegen/runtime-layout/protocol.json) · [summary](run-20261005-codegen/runtime-layout/summary.json) · [identity](run-20261005-codegen/runtime-layout/identities.json) · [outcome](run-20261005-codegen/runtime-layout/outcome.json) | [RSS](run-20261005-codegen/runtime-layout/rss-summary.json) |
| unit-planner | [protocol](run-20261005-codegen/unit-planner/protocol.json) · [summary](run-20261005-codegen/unit-planner/summary.json) · [identity](run-20261005-codegen/unit-planner/identities.json) · [outcome](run-20261005-codegen/unit-planner/outcome.json) | [RSS](run-20261005-codegen/unit-planner/rss-summary.json) |

发布包仅携带完整text证据、原始与发布SHA256对应、源码归档/逐文件摘要和公开Git身份；源码完整快照仍在云端留存，接收方可用固定公开SHA重建。排除工具链/缓存/二进制/源码重复副本。已知私密路径替换明确token，JSON数值/布尔/null字段逐项保持不变；脚本的token需绑定实际路径，导入时不要自动重跑采样。转移/仓库纳入由接收任务另记结果。

## 9. 成本采样结束后的授权修复与移交

两处frontend陈旧测试预期已在独立云端分支修复，仅变更两份测试文件，未改生产实现/Guide/依赖。完整结果 **1704 passed、0 failed/ignored/measured/filtered**：202 lib +1490 integration +12 doctests，131个integration targets与Cargo metadata精确一致。新增合法长hex/bin正例，旧unsupported radix覆盖改为不支持的octal，并补合法进制非法尾部；关键字库存重新分类且扩充，未删除旧片段。

focused red原2失败保留；focused green与默认debuginfo green各5/5。fmt、frontend all-targets严格Clippy、Rust尺寸门禁、独立静态评审均通过。完整详情与profile边界见[修复报告](frontend-fix/frontend-fix-report.md)、[manifest](frontend-fix/fix-manifest.json)、[完整逐目标结果](frontend-fix/frontend-full-green-results.json)和[覆盖核验](frontend-fix/frontend-full-green-coverage.json)。其他crate/native/macOS/完整workspace未因该测试专属修复重跑，不把云端回归称为Mac验收。

补丁提交 `2aa75b0c86e9fe5cf4e2fc7600c657f7cc8c54c6`，base `c5c4a8df271858b23898e0bcf4b55d823c760bb9`；[format-patch](frontend-fix/frontend-test-expectations.patch) SHA256 `2895a1b040873abf34dad06b21ce41f6f9115a675cfd7f96c611aa467d971a96`。测试前diff与提交diff逐字节一致；在base临时index真正apply所得tree与提交tree `1de596258bdd5df1231c0039a0461666f6d08e05` 相等。云端未push/PR、未分配正式Spec编号；Mac接收任务按当前main/工作树和全局inventory纳入新Spec分支。

原始frontend失败、P2历史成本和修后功能回归各自分开；没有用修后结果重写基线，也没有重跑P2样本。接收步骤见[TRANSFER.md](TRANSFER.md)，新分支的文档/CI状态由后续交付另记。
