#!/usr/bin/env python3
"""Separate fixed codegen batch with the same cost method and C RSS supplement."""
import importlib.util
import json
import os
from pathlib import Path
import statistics
import sys
import time
import rss_support

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_p2',HERE/'probe-frozen-v1.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
p.RUN=HERE/'run-20261005-codegen';p.RUN.mkdir()
cfgs=p.CONFIGS[6:]
llvm=json.loads((HERE/'llvm-toolchain-verification.json').read_text())
if not llvm['passed'] or os.environ.get('LLVM_SYS_211_PREFIX')!=llvm['prefix']:
    raise RuntimeError('Verified LLVM prefix not loaded')
protocol=json.loads((HERE/'run-20261005/protocol-frontend.json').read_text())
protocol.update(batch='codegen',host_clock_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
    matrix=cfgs,driver_sha256=p.digest(Path(__file__)),llvm_prefix=llvm['prefix'],
    llvm_toolchain_verification_sha256=p.digest(HERE/'llvm-toolchain-verification.json'),
    script_sha256=p.digest(HERE/'probe-frozen-v1.py'),
    budget='Independent two-hour protective batch budget; not a deadline to declare unmeasured groups complete',
    changes='Same cold/warm/run method, with separately recorded validated C test-child RSS after each cost group; timer selftest includes supervisor thread',
    relevant_env={k:os.environ[k] for k in ['CARGO_HOME','RUSTUP_HOME','PATH','LLVM_SYS_211_PREFIX','LD_LIBRARY_PATH'] if k in os.environ})
p.save(p.RUN/'protocol-codegen.json',protocol)
rss_support.freeze(p,p.RUN,[c[0] for c in cfgs],'Four native-LLVM-dependent cost groups with independent child-RSS supplement')
for mode in ['rustc','link']:
    path=p.RUN/(mode+'-wrapper')
    path.write_text('#!/bin/sh\nexec '+sys.executable+' '+str(HERE/'probe-frozen-v1.py')+' '+mode+' "$@"\n')
    path.chmod(0o755)
timers=[]
for kind,command in [('empty',['/usr/bin/true']),('sleep-50ms',['/usr/bin/sleep','0.05'])]:
    for i in range(10):timers.append(dict(kind=kind,iteration=i,**p.run_wait(command,supervise=True)))
fast=[r['seconds'] for r in timers if r['kind']=='empty']
slow=[r['seconds'] for r in timers if r['kind']=='sleep-50ms']
passed=all(r['exit_code']==0 for r in timers) and statistics.median(fast)<.020 and .045<statistics.median(slow)<.080
p.save(p.RUN/'timer-selftest-supervised.json',{'passed':passed,'rows':timers,'scope':'Same supervisor=true branch used by measured commands; observed plumbing check, not a universal error bound'})
if not passed:raise RuntimeError('Supervised timer selftest failed')
original_cleanup=p.cleanup_targets
def cleanup(group):
    rss_support.supplement(p,group)
    original_cleanup(group)
p.cleanup_targets=cleanup
pairs={r['name']:{'before':r['before'],'after':r['after']} for r in json.loads((HERE/'static-review.json').read_text())['pairs']}
for cfg in cfgs:
    try:p.run_group(cfg,pairs)
    except Exception as ex:
        group=p.RUN/cfg[0]
        if (group/'samples.json').exists():p.summarize(group)
        p.save(group/'outcome.json',{'status':'stopped','reason':repr(ex),'elapsed_seconds':time.monotonic()-p.START})
        raise
p.save(p.RUN/'outcome-codegen.json',{'status':'measured','groups':[c[0] for c in cfgs],'seconds':time.monotonic()-p.START})
