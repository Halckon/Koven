# P2 汇总工具 v2 修复记录

## 已完成

独立 raw 审计发现冻结 summarize 仅对 cold/warm/run 生成调查标志，遗漏两类 first-launch。plan-tests 冷产物首启第2对为 0.161750947→0.218992066 秒，增长 0.057241119 秒（35.3884%），触发单对 execution 调查线；配对中位未触线。原发现保留于 [修复前独立审计](independent-audit-initial.json)。

在全部十组采样终止后，新增 [summarize-v2.py](summarize-v2.py)，从 raw/sample.json 重算14个组/attempt、917条记录，写各组 summary-v2.json；不改原 probe、summary、raw，不重跑样本。入口及派生文件hash见 [v2索引](summary-v2-index.json)。

## 覆盖与实际验证

- 两类首启、正式执行、补测墙时逐对和配对中位分别检查；pair key不符即拒绝配对
- 噪声诊断独立；单次校准预构建首启与3次重编首启分开；不因噪声扩样
- RSS仅取C内部wait4 child-rusage.json；排除预热，不回退Python launcher值；补测两种墙时不混入10对正式热执行
- 原LSP exit101与runtime中断raw均保留，未完成样本不补造时间/退出码
- 首轮16项回归全过；补入4项失败/边界回归后，最终20项全过、0失败/跳过，耗时0.004s，见 [最终测试日志](summary-v2-tests-final.log)和[测试源码](test_summarize_v2.py)
- 与独立实现的审计交叉比较462条指标序列、118项配对调查、12条噪声，完全一致
- 受控第二次派生时5099份原始小文件逐字节hash未变；14份v2输出确定性一致，见 [交叉验证日志](summary-v2-verification.log)、[完整hash记录](summary-v2-verification.json)和[验证脚本](verify-summary-v2.py)

实际结果仍为1处首启单对时间调查命中，0处构建/C child RSS调查命中。12条噪声按指标计数，其中RSS外层/child内层为同一补测事件。此修复纠正遗漏报告，不消除不确定性、不代表用户接受成本预算、不证明等价或关闭P2。

## 重现

在证据根目录依次运行 python summarize-v2.py、python test_summarize_v2.py、python verify-summary-v2.py。它们只读取小JSON/log并写v2派生证据/验证日志，不启动Cargo、benchmark或历史采样。独立审计另需匹配的Git对象，可用P2_AUDIT_BASE和P2_AUDIT_REPO指定路径后运行independent-audit.py。

本记录的机器可读验证与文件hash见 [summary-v2-validation.json](summary-v2-validation.json)。完整源归档/退休二进制未在此重哈希；历史macOS、原云端缺失raw、语义/CI与用户预算的限制仍保留。
