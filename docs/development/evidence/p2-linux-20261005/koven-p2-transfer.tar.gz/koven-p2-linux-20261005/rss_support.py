"""Independent, preregistered child-RSS supplement; cost v1 raw stays unchanged."""
import hashlib
import json
from pathlib import Path
import statistics

HERE=Path(__file__).resolve().parent


def freeze(probe, directory, groups, purpose):
    calibration=json.loads((HERE/'rss-observer-calibration/summary.json').read_text())
    if not calibration['passed']:raise RuntimeError('C observer has no successful calibration')
    probe.save(directory/'rss-protocol.json',{
        'method_version':'C child RSS v1','purpose':purpose,'groups':groups,
        'sampling':'one C-observer warmup per side, then five AB/BA alternating pairs; fixed count, no repeat-to-pass',
        'tool':str(HERE/'rss-observer'),'tool_sha256':probe.digest(HERE/'rss-observer'),
        'source_sha256':probe.digest(HERE/'rss-observer.c'),
        'support_script_sha256':probe.digest(Path(__file__)),
        'units':'Linux KiB','source_of_truth':'Only wait4 inside execed small C observer of its freshly forked test child; not Python wait4 of observer',
        'floor':'Observer child true calibration 384 KiB; low values can still include this measured sub-MiB startup floor',
        'calibration':calibration,'comparison':'retain every value; report paired median and max difference; investigate max(10%,64MiB), not accepted budget',
        'time':'Supplement wall time retained, never pooled into v1 hot-run or build performance estimates',
        'artifacts':'Reuse final binaries when retained; otherwise one no-run rebuild per side is preparation only, not new cold/warm comparison',
        'retention':'Keep all calibration/raw and pre-clean binary hashes; only newly created own targets retired',
    })


def supplement(probe,group):
    cfg=probe.group_config(group)
    rows=json.loads((group/'samples.json').read_text())
    latest={}
    for row in rows:
        for artifact in row['artifacts']:
            if artifact['name']==cfg['artifact_name'] and artifact['executable']:
                latest[row['side']]={'binary':artifact['executable'],'target':Path(row['target'])}
    if set(latest)!=set(['before','after']):raise RuntimeError('RSS supplement missing paired binaries')
    binaries={side:{'path':item['binary'],'sha256':probe.digest(Path(item['binary']))} for side,item in latest.items()}
    measured=[]
    def one(name,side,phase):
        target=latest[side]['target'];b=latest[side]['binary']
        output=group/'raw'/name/'child-rusage.json'
        command=[str(HERE/'rss-observer'),str(output),b,*([cfg['filter']] if cfg['filter'] else []),'--test-threads=1']
        row=probe.sample(group,name,side,phase,command,target,cfg['count'])
        child=json.loads(output.read_text())
        if child['exit_code']!=0:raise RuntimeError('C child failed')
        measured.append({'side':side,'phase':phase,'name':name,'child':child,'binary_sha256':binaries[side]['sha256'],
                         'python_launcher_rss_kib':row['max_reported_process_rss_kib']})
        probe.save(group/'rss-samples.json',measured)
    for side in ['before','after']:one('rss-warmup-'+side,side,'rss-warmup')
    for i in range(5):
        for side in (['before','after'] if i%2==0 else ['after','before']):one(f'rss-{i}-{side}',side,'rss-run')
    values={side:[r['child']['max_reported_process_rss_kib'] for r in measured if r['side']==side and r['phase']=='rss-run'] for side in ['before','after']}
    diffs=[b-a for a,b in zip(values['before'],values['after'])]
    probe.save(group/'rss-summary.json',{
        'binaries':binaries,'values_kib':values,
        'median_kib':{k:statistics.median(v) for k,v in values.items()},
        'paired_delta_kib':diffs,'paired_median_delta_kib':statistics.median(diffs),
        'investigation_pairs':[i for i,(a,b) in enumerate(zip(values['before'],values['after'])) if b-a>max(65536,.10*a)],
        'acceptance':'Not owner-accepted budget; actual test-child process peaks, not simultaneous process-tree memory',
    })
    outcome=group/'outcome.json'
    if outcome.exists():
        old=json.loads(outcome.read_text());old['cost_samples_before_rss_supplement']=old.get('samples')
        old['samples']=len(json.loads((group/'samples.json').read_text()));old['rss_samples']=len(measured)
        probe.save(outcome,old)
    print('C RSS SUPPLEMENT COMPLETE '+cfg['name'],flush=True)
