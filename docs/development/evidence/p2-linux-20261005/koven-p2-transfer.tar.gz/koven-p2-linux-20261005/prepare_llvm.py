#!/usr/bin/env python3
"""Extract verified official LLVM trixie packages only into this task workspace."""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import subprocess
import urllib.request

HERE=Path(__file__).resolve().parent
ROOT=HERE/'llvm-21-local'
DEBS=HERE/'llvm-debs'
metadata=json.loads((HERE/'llvm-package-metadata.json').read_text())
if metadata['signature_status']!='verified LLVM primary fingerprint, InRelease signature, and Packages.gz SHA256':
    raise RuntimeError('LLVM signed metadata not verified')
ROOT.mkdir();DEBS.mkdir()
def fetch(row):
    name=Path(row['Filename']).name
    destination=DEBS/name
    digest=hashlib.sha256();size=0
    url='https://apt.llvm.org/trixie/'+row['Filename']
    with urllib.request.urlopen(url,timeout=90) as response,destination.open('wb') as output:
        while True:
            chunk=response.read(1024*1024)
            if not chunk:break
            size+=len(chunk);digest.update(chunk);output.write(chunk)
    if size!=int(row['Size']) or digest.hexdigest()!=row['SHA256']:
        raise RuntimeError('LLVM package integrity mismatch: '+name)
    print('Verified '+name,flush=True)
    return {'package':row['Package'],'url':url,'path':str(destination),'bytes':size,'sha256':digest.hexdigest()}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
    downloads=list(executor.map(fetch,metadata['packages']))
(HERE/'llvm-download-verification.json').write_text(json.dumps(downloads,indent=2)+'\n')
for row in downloads:
    subprocess.run(['dpkg-deb','-x',row['path'],str(ROOT)],check=True)
prefix=ROOT/'usr/lib/llvm-21'
env=dict(os.environ)
env['LLVM_SYS_211_PREFIX']=str(prefix)
env['LD_LIBRARY_PATH']=str(ROOT/'usr/lib/x86_64-linux-gnu')+':'+str(prefix/'lib')
def command(*args):
    p=subprocess.run(list(args),env=env,text=True,capture_output=True)
    record={'argv':list(args),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    checks.append(record)
    if p.returncode:raise RuntimeError(record)
    return p.stdout
checks=[]
try:
    version=command(str(prefix/'bin/llvm-config'),'--version').strip()
    if version!='21.1.8':raise RuntimeError('wrong LLVM version '+version)
    targets=command(str(prefix/'bin/llvm-config'),'--targets-built').split()
    if not {'AArch64','X86'}.issubset(targets):raise RuntimeError('required LLVM backend absent')
    if 'clang version 21.1.8' not in command(str(prefix/'bin/clang'),'--version'):raise RuntimeError('Clang mismatch')
    if 'LLVM version 21.1.8' not in command(str(prefix/'bin/llvm-dwarfdump'),'--version'):raise RuntimeError('DWARF tool mismatch')
    command(str(prefix/'bin/llvm-config'),'--prefix','--libdir','--includedir','--link-shared','--libs','--system-libs')
    for binary in ['llvm-config','clang','llvm-dwarfdump']:
        text=command('ldd',str(prefix/'bin'/binary))
        if 'not found' in text:raise RuntimeError('LLVM loader dependency absent')
    sanity=ROOT/'sanity.c';sanity.write_text('int main(void) { return 0; }\n')
    command(str(prefix/'bin/clang'),str(sanity),'-o',str(ROOT/'sanity'))
    command(str(ROOT/'sanity'))
    ir=ROOT/'sanity.ll';ir.write_text('target triple = "x86_64-unknown-linux-gnu"\ndefine i32 @main() { ret i32 0 }\n')
    command(str(prefix/'bin/clang'),str(ir),'-o',str(ROOT/'sanity-ir'))
    command(str(ROOT/'sanity-ir'))
    (HERE/'llvm-env.sh').write_text('export LLVM_SYS_211_PREFIX='+str(prefix)+'\nexport LD_LIBRARY_PATH='+env['LD_LIBRARY_PATH']+'\n')
    result={'passed':True,'prefix':str(prefix),'checks':checks,
            'scope':'Matched compiler-development, Clang IR and DWARF tools execute with resolved dynamic loader dependencies; not all optional tools or distro package-manager dependencies tested',
            'os':'Debian13 trixie x86_64; package-manager metadata absent; no system apt/security settings changed',
            'signature_chain':'LLVM known primary fingerprint -> InRelease -> Packages.gz -> each deb SHA256',
            'version':version,'environment':{'LLVM_SYS_211_PREFIX':str(prefix),'LD_LIBRARY_PATH':env['LD_LIBRARY_PATH']}}
except Exception as ex:
    result={'passed':False,'checks':checks,'error':repr(ex)}
    raise
finally:
    (HERE/'llvm-toolchain-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('Official workspace-local LLVM21.1.8 ready',flush=True)
