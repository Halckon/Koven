#!/usr/bin/env python3
"""Post-measurement P2 summary correction. Never edits frozen inputs or reruns samples.

Input order is read from samples.json and every value from matching raw/sample.json.
All child-RSS values come exclusively from C observer child-rusage.json.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import statistics
from typing import Any

COST_BUILD = {'cold', 'warm'}
COST_EXECUTION = {'first-launch-cold', 'first-launch-warm', 'run'}
SUPPLEMENT_EXECUTION = {'rss-warmup', 'rss-run', 'semantic-run'}
COMPLETED = {'measured', 'measured-after-interruption', 'RSS measured'}


def read(path: Path) -> Any:
    return json.loads(path.read_text())


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stats(values: list[float], *, time_metric: bool = True) -> dict:
    if not values:
        raise ValueError('empty statistical series')
    median = statistics.median(values)
    mad = statistics.median(abs(v - median) for v in values)
    span = max(values) - min(values)
    scaled_mad_limit = max(.005, .10 * median)
    range_limit = max(.020, .30 * median)
    noise = (1.4826 * mad > scaled_mad_limit or span > range_limit) if time_metric and len(values) > 1 else None
    return {
        'values': values, 'n': len(values), 'median': median, 'mad': mad, 'range': span,
        'noise_flag': noise,
        'noise_thresholds': {'scaled_mad': scaled_mad_limit, 'range': range_limit} if time_metric else None,
        'noise_scope': 'Diagnostic only; singleton scatter unassessed; never a pass/acceptance or resampling rule' if time_metric else 'No frozen RSS scatter/noise gate',
    }


def investigation(before: list[float], after: list[float], rule: str) -> dict:
    if len(before) != len(after) or not before:
        raise ValueError('paired comparison needs matching nonempty counts')
    scale, floor = {'build': (.20, 1.), 'execution': (.30, .020), 'rss': (.10, 65536)}[rule]
    delta = [a - b for b, a in zip(before, after)]
    thresholds = [max(floor, scale * b) for b in before]
    paired_median = statistics.median(delta)
    median_threshold = max(floor, scale * statistics.median(before))
    return {
        'rule': rule, 'scale': scale, 'absolute_floor': floor,
        'before': before, 'after': after, 'paired_delta': delta,
        'paired_percent': [100 * d / b if b else None for b, d in zip(before, delta)],
        'paired_median_delta': paired_median,
        'paired_median_percent': statistics.median(100 * d / b for b, d in zip(before, delta)) if all(before) else None,
        'pair_thresholds': thresholds,
        'hit_pair_indices': [i for i, (d, t) in enumerate(zip(delta, thresholds)) if d > t],
        'paired_median_threshold': median_threshold,
        'paired_median_hit': paired_median > median_threshold,
        'acceptance': 'Investigation trigger only, not an accepted budget or equivalence test',
    }


def phase_key(row: dict) -> str:
    if row['phase'] == 'calibration-first-launch':
        return 'calibration-prebuild-first-launch' if row['name'] == 'calibration-first-launch' else 'calibration-rebuild-first-launch'
    return row['phase']


def pair_key(name: str, side: str) -> str:
    suffix = '-' + side
    if not name.endswith(suffix):
        raise ValueError(f'paired sample lacks explicit side suffix: {name}')
    return name[:-len(suffix)]


def pair_rows(rows: list[dict]) -> tuple[list[dict], list[dict], list[str]] | None:
    before = [r for r in rows if r['side'] == 'before']
    after = [r for r in rows if r['side'] == 'after']
    if not before or not after:
        return None
    keys_before = [pair_key(r['name'], 'before') for r in before]
    keys_after = [pair_key(r['name'], 'after') for r in after]
    if keys_before != keys_after:
        raise ValueError('paired sample keys/count/order differ')
    return before, after, keys_before


def child_record(group: Path, row: dict) -> dict:
    path = group / 'raw' / row['name'] / 'child-rusage.json'
    if not path.exists():
        raise ValueError(f'C child RSS missing; no Python launcher fallback: {path}')
    child = read(path)
    if child.get('kind') != 'test-child' or child.get('exit_code') != 0:
        raise ValueError(f'C child RSS invalid/failed: {path}')
    return child


def raw_rows(group: Path) -> list[dict]:
    index = read(group / 'samples.json')
    names = [r['name'] for r in index]
    if len(names) != len(set(names)):
        raise ValueError('duplicate sample names in index')
    rows = []
    for reference in index:
        directory = group / 'raw' / reference['name']
        raw = read(directory / 'sample.json')
        if raw != reference:
            raise ValueError(f'raw sample/index differ: {directory}')
        events = [read(p) for p in sorted(directory.glob('*.json')) if p.name != 'sample.json']
        rustcs = [e for e in events if e.get('kind') == 'rustc' and '--crate-name' in e['argv']]
        links = [e for e in events if e.get('kind') == 'link']
        auxiliary = [e for e in events if e.get('kind') == 'rustc' and e not in rustcs]
        if rustcs != raw['rustc_events'] or links != raw['link_events']:
            raise ValueError(f'raw process events/index differ: {directory}')
        raw = dict(raw)
        raw['rustc_nonlink_seconds_sum'] = sum(e['seconds'] - sum(l['seconds'] for l in links if l['rustc_id'] == e['id']) for e in rustcs)
        raw['linker_seconds_sum'] = sum(e['seconds'] for e in links)
        raw['auxiliary_rustc_seconds_sum'] = sum(e['seconds'] for e in auxiliary)
        raw['maximum_reported_process_rss_kib'] = max([raw['max_reported_process_rss_kib']] + [e['max_reported_process_rss_kib'] for e in events])
        if raw['phase'].startswith('rss-') and raw['phase'] in {'rss-run', 'rss-warmup'}:
            child = child_record(group, raw)
            raw['c_child_seconds'] = child['seconds']
        rows.append(raw)
    return rows


def summarize_phases(rows: list[dict]) -> dict:
    by_phase: dict[str, list[dict]] = {}
    for row in rows:
        by_phase.setdefault(phase_key(row), []).append(row)
    phases = {}
    for phase, rr in by_phase.items():
        sides = {side: [r for r in rr if r['side'] == side] for side in ('before', 'after')}
        metrics = ['seconds']
        if any(r['rustc_invocations'] for r in rr):
            metrics.extend(['rustc_nonlink_seconds_sum', 'linker_seconds_sum'])
        if any(r.get('auxiliary_rustc_seconds_sum', 0) for r in rr):
            metrics.append('auxiliary_rustc_seconds_sum')
        if all('c_child_seconds' in r for r in rr):
            metrics.append('c_child_seconds')
        result = {
            'sample_names': {side: [r['name'] for r in sr] for side, sr in sides.items() if sr},
            'time_metrics': {metric: {side: stats([r[metric] for r in sr]) for side, sr in sides.items() if sr} for metric in metrics},
            'cohort': 'formal cost' if phase in COST_BUILD | COST_EXECUTION else 'separate diagnostic/preparation/semantic phase',
        }
        pairs = pair_rows(rr)
        if pairs and phase in COST_BUILD | COST_EXECUTION | SUPPLEMENT_EXECUTION | {'noop', 'semantic-build', 'rss-preparation-build'}:
            br, ar, keys = pairs
            rule = 'build' if phase in COST_BUILD | {'noop', 'semantic-build', 'rss-preparation-build'} else 'execution'
            result['time_investigation'] = investigation([r['seconds'] for r in br], [r['seconds'] for r in ar], rule)
            result['time_investigation'].update(pair_keys=keys,scope='formal observed cost phase' if phase in COST_BUILD | COST_EXECUTION else 'separate diagnostic; not pooled with formal cost')
            if phase in {'rss-run', 'rss-warmup'}:
                result['c_child_time_investigation'] = investigation([r['c_child_seconds'] for r in br], [r['c_child_seconds'] for r in ar], 'execution')
                result['c_child_time_investigation'].update(pair_keys=keys,scope='separate C-observer inner time; not an extra independent sample or formal hot run')
        if phase in COST_BUILD:
            result['build_process_rss_kib'] = {side: stats([r['maximum_reported_process_rss_kib'] for r in sr], time_metric=False) for side, sr in sides.items() if sr}
            if pairs:
                br, ar, keys = pairs
                result['build_rss_investigation'] = investigation([r['maximum_reported_process_rss_kib'] for r in br], [r['maximum_reported_process_rss_kib'] for r in ar], 'rss')
                result['build_rss_investigation']['pair_keys'] = keys
        phases[phase] = result
    return phases


def summarize_rss(group: Path, rows: list[dict]) -> dict | None:
    rr = [r for r in rows if r['phase'] in {'rss-warmup', 'rss-run'}]
    if not rr:
        return None
    warmup = [r for r in rr if r['phase'] == 'rss-warmup']
    measured = [r for r in rr if r['phase'] == 'rss-run']
    if [r['side'] for r in warmup] != ['before', 'after']:
        raise ValueError('RSS requires exactly one separate warmup per side')
    expected = [f'rss-{i}-{s}' for i in range(5) for s in (['before', 'after'] if i % 2 == 0 else ['after', 'before'])]
    if [r['name'] for r in measured] != expected:
        raise ValueError('RSS requires exactly five AB/BA alternating pairs')
    pairs = pair_rows(measured)
    assert pairs is not None
    before, after, keys = pairs
    values = {side: [child_record(group, row)['max_reported_process_rss_kib'] for row in series] for side, series in [('before', before), ('after', after)]}
    result = {
        'source_group': str(group), 'source': 'raw/rss-*/child-rusage.json only; C internal wait4 of actual test child',
        'warmups_excluded': [r['name'] for r in warmup],
        'source_records': [str(group / 'raw' / r['name'] / 'child-rusage.json') for r in measured],
        'values_kib': values, 'statistics_kib': {side: stats(v, time_metric=False) for side, v in values.items()},
        'investigation': investigation(values['before'], values['after'], 'rss'),
        'supplemental_timing': summarize_phases(rr),
        'boundary': 'Python launcher RSS excluded. No frozen RSS MAD/range gate. Five fixed pairs; no acceptance or equivalence claim.',
    }
    result['investigation']['pair_keys'] = keys
    return result


def build_summary(group: Path, base: Path) -> dict:
    rows = raw_rows(group)
    outcome = read(group / 'outcome.json')
    phases = summarize_phases(rows)
    rss_group = group
    if outcome['status'] in COMPLETED and not any(r['phase'] == 'rss-run' for r in rows):
        supplement = base / 'run-20261005-rss-only' / group.name
        if supplement.exists():
            rss_group = supplement
    rss = summarize_rss(rss_group, rows if rss_group == group else raw_rows(rss_group))
    input_paths = [p for p in sorted((group / 'raw').rglob('*')) if p.is_file()]
    input_paths += [group / 'samples.json', group / 'protocol.json', group / 'outcome.json']
    if (group / 'summary.json').exists():
        input_paths.append(group / 'summary.json')
    source_hashes = {str(p.relative_to(group)): digest(p) for p in input_paths}
    return {
        'schema_version': 2, 'group': str(group.relative_to(base)), 'outcome': outcome,
        'sample_count': len(rows), 'phases': phases, 'c_child_rss': rss,
        'source_hashes': source_hashes,
        'method_changes': [
            'Time inquiry now includes both first-launch phases with independent per-pair and paired-median checks.',
            'Calibration prebuild first launch (n=1) is separate from three rebuild first launches, including -resumed suffix.',
            'All phase time scatter diagnostics remain separate from inquiry thresholds and cost acceptance.',
            'Test RSS uses only C child source, excluding independent warmups and Python launcher maxima.',
            'Supplement wall/inner time retained separately, never pooled into ten formal hot-run pairs.',
            'Original frozen raw/summary/protocol/probe are unchanged; auxiliary compiler records are diagnostic and excluded from frozen nonlink estimator.',
        ],
        'failures': [{'name': r['name'], 'exit_code': r['exit_code'], 'stop_reasons': r['stop_reasons'], 'validation_error': r.get('validation_error')} for r in rows if r['exit_code'] or r['stop_reasons'] or r.get('validation_error')],
        'uncompleted_raw_directories': sorted(p.name for p in (group / 'raw').iterdir() if p.is_dir() and p.name not in {r['name'] for r in rows}),
        'acceptance': 'Not owner accepted. Descriptive finite Linux observations only; no P2 closure or performance equivalence.',
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    results = []
    for group in sorted(p.parent for p in args.base.glob('run-*/*/samples.json')):
        if not (group / 'outcome.json').exists():
            raise ValueError(f'unfinished measurement group: {group}')
        result = build_summary(group, args.base)
        output = group / 'summary-v2.json'
        output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
        hits = [phase for phase, v in result['phases'].items() if 'time_investigation' in v and (v['time_investigation']['hit_pair_indices'] or v['time_investigation']['paired_median_hit'])]
        results.append({'group': result['group'], 'sample_count': result['sample_count'], 'outcome': result['outcome']['status'], 'summary_v2_sha256': digest(output), 'time_investigation_hit_phases': hits})
        print(json.dumps(results[-1]))
    record = {'schema_version': 2, 'tool_sha256': digest(Path(__file__)), 'groups': results, 'samples': sum(r['sample_count'] for r in results), 'note': 'Post-measurement derivation only. No original file overwritten; no sample executed or discarded.'}
    (args.base / 'summary-v2-index.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')


if __name__ == '__main__':
    main()
