import datetime, json, os, pathlib, shutil, signal, subprocess, sys, time
root=pathlib.Path('__CLOUD_WORKSPACE__'); logs=root/'frontend-fix-logs'; name=sys.argv[1]; cmd=sys.argv[2:]
env=os.environ.copy(); overrides=dict(CARGO_TARGET_DIR=str(root/'frontend-target'),CARGO_INCREMENTAL='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='2',CARGO_TERM_COLOR='never',RUST_BACKTRACE='1'); env.update(overrides)
rec={'command':cmd,'cwd':str(root/'koven'),'environment_overrides':overrides,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_sha':'c5c4a8df271858b23898e0bcf4b55d823c760bb9','head_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root/'koven',text=True).strip()}
start=time.monotonic(); stop_reason=None
with (logs/(name+'.log')).open('w') as f, (logs/(name+'-resources.jsonl')).open('w') as resources:
    proc=subprocess.Popen(cmd,cwd=root/'koven',env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
    while True:
        try:
            proc.wait(timeout=10)
            break
        except subprocess.TimeoutExpired:
            free=shutil.disk_usage(root).free
            result=subprocess.run(['du','-sb',str(root/'frontend-target')],capture_output=True,text=True)
            target_bytes=int(result.stdout.split()[0]) if result.returncode==0 else 0
            mem=dict(line.split(':',1) for line in pathlib.Path('/proc/meminfo').read_text().splitlines())
            state={'elapsed_seconds':time.monotonic()-start,'free_bytes':free,'target_bytes':target_bytes,'mem_available_kib':int(mem['MemAvailable'].split()[0])}
            resources.write(json.dumps(state)+'\n'); resources.flush(); print(json.dumps(state),flush=True)
            if free<8*1024**3 or target_bytes>10*1024**3:
                stop_reason='Resource guard: free disk <8 GiB or frontend target >10 GiB'
                os.killpg(proc.pid,signal.SIGTERM)
                try: proc.wait(timeout=15)
                except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL); proc.wait()
                break
rec.update(exit_code=proc.returncode,elapsed_seconds=time.monotonic()-start,stop_reason=stop_reason,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(logs/(name+'.json')).write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps(rec,indent=2),flush=True); print((logs/(name+'.log')).read_text()[-6000:],flush=True)
sys.exit(proc.returncode if proc.returncode>=0 else 128-proc.returncode)
