import collections, json, pathlib, re
root=pathlib.Path('__CLOUD_WORKSPACE__'); logs=root/'frontend-fix-logs'
pattern=re.compile(r'^test result: (\S+) (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([\d.]+)s$')
keys=['passed','failed','ignored','measured','filtered']
def summarize(name):
    rows=[]; target=None
    for line in (logs/(name+'.log')).read_text().splitlines():
        if re.match(r'\s+Running unittests ',line): target='lib'
        match=re.match(r'\s+Running tests/(.+)\.rs \(',line)
        if match: target=match[1]
        if re.match(r'\s+Doc-tests lang_frontend',line): target='doctests'
        match=pattern.match(line)
        if match:
            assert target is not None,(name,line)
            row={'target':target,'state':match[1],**dict(zip(keys,map(int,match.group(2,3,4,5,6)))),'runtime_seconds':float(match[7])}
            rows.append(row); target=None
    result={'target_count':len(rows),'totals':{k:sum(x[k] for x in rows) for k in keys},'failed_targets':[x for x in rows if x['failed']],'rows':rows}
    (logs/(name+'-results.json')).write_text(json.dumps(result,indent=2)+'\n'); print(name,result['totals'])
    return result
for name in ('focused-red','focused-green','focused-default-profile-green','frontend-full-green'):
    result=summarize(name)
    if name=='frontend-full-green':
        metadata=json.loads((logs/'cargo-metadata.json').read_text()); pkg=next(x for x in metadata['packages'] if x['name']=='lang-frontend')
        expected={t['name'] for t in pkg['targets'] if t['kind']==['test']}
        actual=[x['target'] for x in result['rows'] if x['target'] not in ('lib','doctests')]
        check={'expected_integration_targets':len(expected),'actual_integration_targets':len(actual),'missing':sorted(expected-set(actual)),'extra':sorted(set(actual)-expected),'duplicate_targets':sorted(k for k,n in collections.Counter(x['target'] for x in result['rows']).items() if n>1),'features':pkg['features'],'doctest_enabled':all(t['doctest'] for t in pkg['targets'] if t['kind']==['lib']),'lib_result_count':sum(x['target']=='lib' for x in result['rows']),'doctest_result_count':sum(x['target']=='doctests' for x in result['rows'])}
        (logs/'frontend-full-green-coverage.json').write_text(json.dumps(check,indent=2)+'\n')
        assert check['missing']==check['extra']==check['duplicate_targets']==[]
        assert check['lib_result_count']==check['doctest_result_count']==1
        assert len(actual)==len(expected)==131
        assert result['totals']['failed']==result['totals']['ignored']==result['totals']['measured']==result['totals']['filtered']==0
