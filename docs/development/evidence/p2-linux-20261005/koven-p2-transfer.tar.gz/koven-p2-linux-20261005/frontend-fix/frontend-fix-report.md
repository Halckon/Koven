# Frontend 过期测试预期修复与云端验收

## 结论

仅修复 Phase 1 Lexer/Parser 的两份测试，未改变生产实现、语言语义、Guide 或依赖。
修后完整 frontend 为 **1704 passed、0 failed、0 ignored、0 measured、0 filtered**。
131 个 integration targets 与 Cargo metadata 精确一致，并执行 lib 与 doctests。

- Base：`c5c4a8df271858b23898e0bcf4b55d823c760bb9`
- 本地提交：`2aa75b0c86e9fe5cf4e2fc7600c657f7cc8c54c6`
- 云端临时分支：`fix/frontend-test-expectations-cloud`
- Author / committer：halckon <halckon0@hotmail.com>
- 文件：`frontend-test-expectations.patch`
- Patch SHA-256：`2895a1b040873abf34dad06b21ce41f6f9115a675cfd7f96c611aa467d971a96`
- 未 push、未创建 PR、未分配 Spec 编号。正式 Spec / 分支由 Mac 最新 main 阶段承接。

## 独立核验与必要修改

### `crates/lang-frontend/tests/parser_long_invalid_number_boundaries.rs`

原用例把 `0x` 后 65,536 个 `A` 当作 unsupported radix，要求 L0008；现行 Guide 01 明确支持
hex/bin，Lexer/Parser 不执行数值溢出检查，scanner 与现有 lexer 正例均符合现行规范。

- 原三种 exponent / suffix 负例不变。
- 将过期负例改为规范明确不支持的 `0o` 加 65,536 个 `7`，保留 unsupported radix 覆盖。
- 新增 `0x` 加 65,536 个 `A` 再接 `G`、`0b` 加 65,536 个 `1` 再接 `2`，验证合法进制的非法尾部仍形成完整 maximal invalid region。
- 非法数字矩阵从 4 × 4 = 16 增至 6 × 4 = 24 组。所有组仍检查唯一 L0008、完整诊断 Span、Error 节点、真实 `+` 和 rhs、插值及两层 sentinel，block/file 仍保留后续声明。
- 新增合法长数表达式对照，覆盖 `0x` / `0X` / `0b` / `0B`：零诊断、Unsuffixed 整数字面量、完整字面量文本和 Span、Add 运算符及 rhs；保留共享 helper 的重复产物确定性检查。

### `crates/lang-frontend/tests/parser_token_inventory.rs`

原库存仍把 value / loop / own / borrow / inout / move 计为硬关键字，而 Guide 01 和 scanner
已将这些上下文词保留为 Identifier。

- 硬关键字准确分类为 36 个；六个上下文词移入显式 Identifier 库存，不删除旧片段。
- 补齐原先遗漏的 by / and / or / xor / shl / shr / ushr；全部上下文/软关键字与普通 name / `_` 共 17 个 Identifier。
- 每个 Identifier 明确检查单个 Identifier + EOF、无诊断。
- 原 120 个库存片段全部保留，扩大为 127 个唯一片段；仍覆盖 L0001–L0008 和全部既有 lexical families。
- 四入口重复解析矩阵从 480 增至 508 组；词法检查计数更新为 238。

两个文件由 504 / 380 行增至 579 / 396 行，均低于 1000 行软上限；仓库尺寸门禁报告的 45 个旧超限文件未改变。

## 实际验证

环境：Debian 13 x86_64 Linux、Rust/Cargo 1.96.0，工具链仅在工作区。
所有 Cargo 调用串行执行，单个 Cargo 编译使用 `-j 2`，libtest 保留默认并行。

功能回归环境：`CARGO_INCREMENTAL=0`、`CARGO_PROFILE_TEST_DEBUG=0`、
`CARGO_BUILD_JOBS=2`、`CARGO_TERM_COLOR=never`、`RUST_BACKTRACE=1`，复用独立 frontend target。
这是 unoptimized 功能回归，保留 debug assertions；不用于性能测量。

| 检查 | 命令 | 实际结果 |
|---|---|---|
| 修改前 focused red | `cargo test --locked -p lang-frontend --no-fail-fast -j 2 --test parser_long_invalid_number_boundaries --test parser_token_inventory` | 2 passed / 2 failed，exit 101 |
| 修改后相同选择 green | 同上 | 5 passed / 0 failed，exit 0 |
| 默认 debuginfo green | 同上，unset `CARGO_PROFILE_TEST_DEBUG`，复用 frontend-repro-target | 5 passed / 0 failed，exit 0；Cargo 明示 unoptimized + debuginfo |
| 全量 frontend | `cargo test --locked -p lang-frontend --no-fail-fast -j 2` | 1704 passed，exit 0 |
| 格式 | `cargo fmt --all -- --check` | exit 0 |
| 严格 Clippy | `cargo clippy --locked -p lang-frontend --all-targets -j 2 -- -D warnings` | exit 0 |
| 尺寸 | `python3 scripts/check_rust_sizes.py --base c5c4a8df271858b23898e0bcf4b55d823c760bb9` | exit 0 |
| Diff 与独立静态评审 | `git diff --check`，两个测试逐项审阅 | 通过，无阻断项 |

所有 red/green 测试均无 ignored / measured / filtered 项。全量结果分布：

- lib：202 passed
- 131 integration targets：1490 passed
- doctests：12 passed
- 总目标结果：133；missing / extra / duplicate targets 均为空

全量执行时间：2026-10-05 03:12:33.983Z 至 03:14:03.988Z，墙时约 90.004 秒。
每 10 秒记录资源，未触发空闲磁盘低于 8 GiB 或 frontend target 高于 10 GiB 的守卫。

## 提交与转移验证

所有测试在提交前的工作树运行；测试快照 `tested-working-tree.diff` 与最终 `committed.diff`
逐字节相同，二者 SHA-256 都是 `595c64a2b22df45fcdce7799139bed02d85f644c2091cd21af0cc070f1514d07`。

由 `git format-patch --binary -1 --stdout` 生成标准邮件 patch。已用独立临时 Git index 载入
base，执行 `git apply --cached --check` 和实际 apply，并核对得到的 tree 与提交 tree 完全相同：
`1de596258bdd5df1231c0039a0461666f6d08e05`。最终仓库工作树干净。

Mac 仍需基于最新 main 分配正式 Spec / 分支，检查 patch 是否仍可应用，再按实际变更完成本地交付门禁。
本轮没有在 Mac 实际应用 patch，不能把云端验证称为 Mac 验收。

## 证据与未运行范围

同目录保留完整原始测试日志、逐命令白名单环境/UTC 时间/退出码、逐目标计数与覆盖核验、资源记录、
Cargo metadata、独立评审、修复 manifest、提交 diff 与可转移 patch。`fix-manifest.json` 是机器可读入口。
原 `validation-logs` 中失败基线未改写；性能采样未重跑。

没有运行其他 crate/native/macOS 或完整 workspace 门禁；此为测试专属修复与 frontend 全量回归。
新增合法长数仅验证表达式入口的 Lexer/Parser 接受与保真，不验证后续类型或数值溢出行为。
