"""Regression coverage for the discovered first-launch omission and evidence boundaries."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('summary_v2', HERE / 'summarize-v2.py')
v2 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v2)


def sample(name, side, phase, seconds=.1):
    return {'name': name, 'side': side, 'phase': phase, 'seconds': seconds,
            'rustc_invocations': 0, 'linker_invocations': 0, 'auxiliary_rustc_seconds_sum': 0,
            'max_reported_process_rss_kib': 9_000_000, 'maximum_reported_process_rss_kib': 9_000_000}


class SummaryV2Regression(unittest.TestCase):
    def test_actual_cold_first_launch_single_pair_is_not_hidden_by_median(self):
        before = [.183736808, .161750947, .178143547]
        after = [.206223405, .218992066, .183239487]
        d = v2.investigation(before, after, 'execution')
        self.assertEqual(d['hit_pair_indices'], [1])
        self.assertFalse(d['paired_median_hit'])
        self.assertAlmostEqual(d['paired_delta'][1], .057241119)

    def test_both_first_launch_phases_get_execution_investigation(self):
        for phase in ['first-launch-cold', 'first-launch-warm']:
            rows = [sample('pair-0-before', 'before', phase), sample('pair-0-after', 'after', phase, .15)]
            d = v2.summarize_phases(rows)[phase]['time_investigation']
            self.assertEqual(d['rule'], 'execution')
            self.assertEqual(d['hit_pair_indices'], [0])
            self.assertTrue(d['paired_median_hit'])

    def test_formal_hot_run_still_gets_same_inquiry(self):
        rows = [sample('run-0-before', 'before', 'run'), sample('run-0-after', 'after', 'run', .15)]
        self.assertEqual(v2.summarize_phases(rows)['run']['time_investigation']['hit_pair_indices'], [0])

    def test_paired_median_is_not_difference_of_marginal_medians(self):
        d = v2.investigation([1., 2., 100.], [50., 3., 101.], 'execution')
        self.assertEqual(d['paired_median_delta'], 1.)
        self.assertNotEqual(d['paired_median_delta'], 48.)

    def test_paired_median_checked_independently(self):
        d = v2.investigation([1., 1., 1.], [2., 2., 2.], 'execution')
        self.assertTrue(d['paired_median_hit'])
        self.assertEqual(d['hit_pair_indices'], [0, 1, 2])

    def test_threshold_is_strict_and_keeps_absolute_floor(self):
        self.assertEqual(v2.investigation([100.], [130.], 'execution')['hit_pair_indices'], [])
        self.assertEqual(v2.investigation([0.001], [.011], 'execution')['hit_pair_indices'], [])
        self.assertEqual(v2.investigation([1.], [2.], 'build')['hit_pair_indices'], [])
        self.assertEqual(v2.investigation([1.], [2.1], 'build')['hit_pair_indices'], [0])

    def test_noise_does_not_mean_investigation_or_acceptance(self):
        values = [.1, .3, .1]
        self.assertTrue(v2.stats(values)['noise_flag'])
        d = v2.investigation(values, values, 'execution')
        self.assertFalse(d['paired_median_hit'])
        self.assertEqual(d['hit_pair_indices'], [])
        self.assertIn('not an accepted budget', d['acceptance'])

    def test_calibration_prebuild_and_resumed_rebuild_first_launch_separate(self):
        rows = [sample('calibration-first-launch', 'before', 'calibration-first-launch', 2.)]
        rows += [sample('calibration-first-launch-' + name, 'before', 'calibration-first-launch', x) for name, x in [('0', .1), ('1', .11), ('2-resumed', .12)]]
        phases = v2.summarize_phases(rows)
        self.assertEqual(phases['calibration-prebuild-first-launch']['time_metrics']['seconds']['before']['n'], 1)
        self.assertIsNone(phases['calibration-prebuild-first-launch']['time_metrics']['seconds']['before']['noise_flag'])
        self.assertEqual(phases['calibration-rebuild-first-launch']['time_metrics']['seconds']['before']['n'], 3)

    def test_mismatched_pair_keys_rejected_instead_of_positional_mispair(self):
        with self.assertRaises(ValueError):
            v2.pair_rows([sample('run-0-before', 'before', 'run'), sample('run-1-after', 'after', 'run')])

    def test_mismatched_pair_counts_rejected(self):
        with self.assertRaises(ValueError):
            v2.investigation([1., 2.], [1.], 'execution')

    def test_supplemental_time_explicitly_not_formal_cost(self):
        rows = [sample('rss-0-before', 'before', 'rss-run'), sample('rss-0-after', 'after', 'rss-run', .2)]
        for row in rows:
            row['c_child_seconds'] = row['seconds'] - .001
        result = v2.summarize_phases(rows)['rss-run']
        self.assertIn('not pooled', result['time_investigation']['scope'])
        self.assertIn('not an extra independent sample', result['c_child_time_investigation']['scope'])
        self.assertNotIn('build_process_rss_kib', result)

    def test_build_internal_noise_not_given_total_build_inquiry(self):
        rows = [sample('warm-0-before', 'before', 'warm'), sample('warm-0-after', 'after', 'warm')]
        for row in rows:
            row.update(rustc_invocations=1, rustc_nonlink_seconds_sum=.05, linker_seconds_sum=.04)
        result = v2.summarize_phases(rows)['warm']
        self.assertIn('linker_seconds_sum', result['time_metrics'])
        self.assertNotIn('linker_investigation', result)
        self.assertEqual(result['time_investigation']['rule'], 'build')

    def test_rss_threshold_is_kib_and_no_scatter_gate(self):
        self.assertEqual(v2.investigation([1000], [66536], 'rss')['hit_pair_indices'], [])
        self.assertEqual(v2.investigation([1000], [66537], 'rss')['hit_pair_indices'], [0])
        self.assertIsNone(v2.stats([1000, 900000], time_metric=False)['noise_flag'])

    def test_missing_c_child_has_no_launcher_fallback(self):
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaisesRegex(ValueError, 'no Python launcher fallback'):
                v2.child_record(Path(temp), sample('rss-0-before', 'before', 'rss-run'))

    def test_c_rss_uses_child_only_and_excludes_warmups(self):
        with tempfile.TemporaryDirectory() as temp:
            group = Path(temp)
            names = [('rss-warmup-before', 'before', 'rss-warmup'), ('rss-warmup-after', 'after', 'rss-warmup')]
            names += [(f'rss-{i}-{s}', s, 'rss-run') for i in range(5) for s in (['before', 'after'] if i % 2 == 0 else ['after', 'before'])]
            rows = []
            for name, side, phase in names:
                row = sample(name, side, phase)
                row['c_child_seconds'] = .099
                directory = group / 'raw' / name
                directory.mkdir(parents=True)
                rss = 800000 if phase == 'rss-warmup' else (1000 if side == 'before' else 1100)
                (directory / 'child-rusage.json').write_text(json.dumps({'kind': 'test-child', 'exit_code': 0, 'seconds': .099, 'max_reported_process_rss_kib': rss}))
                rows.append(row)
            original = copy.deepcopy(rows)
            result = v2.summarize_rss(group, rows)
            self.assertEqual(result['values_kib'], {'before': [1000] * 5, 'after': [1100] * 5})
            self.assertEqual(result['investigation']['paired_median_delta'], 100)
            self.assertEqual(result['investigation']['hit_pair_indices'], [])
            self.assertEqual(rows, original)

    def test_raw_index_mismatch_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            group = Path(temp)
            (group / 'raw' / 'run-0-before').mkdir(parents=True)
            (group / 'samples.json').write_text(json.dumps([{'name': 'run-0-before', 'seconds': .1}]))
            (group / 'raw' / 'run-0-before' / 'sample.json').write_text(json.dumps({'name': 'run-0-before', 'seconds': .2}))
            with self.assertRaisesRegex(ValueError, 'raw sample/index differ'):
                v2.raw_rows(group)

    def test_failed_c_child_is_not_accepted(self):
        with tempfile.TemporaryDirectory() as temp:
            group = Path(temp)
            directory = group / 'raw' / 'rss-0-before'
            directory.mkdir(parents=True)
            (directory / 'child-rusage.json').write_text(json.dumps({'kind': 'test-child', 'exit_code': 1}))
            with self.assertRaisesRegex(ValueError, 'invalid/failed'):
                v2.child_record(group, sample('rss-0-before', 'before', 'rss-run'))

    @unittest.skipUnless((HERE / 'run-20261005/lsp/summary-v2.json').exists(), 'real corpus not installed')
    def test_existing_failed_attempt_remains_failed(self):
        result = json.loads((HERE / 'run-20261005/lsp/summary-v2.json').read_text())
        self.assertEqual(result['outcome']['status'], 'stopped')
        self.assertEqual(result['failures'][0]['exit_code'], 101)
        self.assertIsNone(result['c_child_rss'])

    @unittest.skipUnless((HERE / 'run-20261005-codegen/runtime-layout/summary-v2.json').exists(), 'real corpus not installed')
    def test_existing_interrupted_raw_not_invented_as_a_sample(self):
        result = json.loads((HERE / 'run-20261005-codegen/runtime-layout/summary-v2.json').read_text())
        self.assertEqual(result['uncompleted_raw_directories'], ['calibration-warm-2'])
        self.assertEqual(result['sample_count'], 90)
        names = result['phases']['calibration-warm']['sample_names']['before']
        self.assertEqual(names, ['calibration-warm-0', 'calibration-warm-1', 'calibration-warm-2-resumed'])

    def test_zero_denominator_keeps_absolute_comparison(self):
        d = v2.investigation([0.], [1.], 'execution')
        self.assertEqual(d['paired_percent'], [None])
        self.assertIsNone(d['paired_median_percent'])
        self.assertEqual(d['hit_pair_indices'], [0])


if __name__ == '__main__':
    unittest.main(verbosity=2)
