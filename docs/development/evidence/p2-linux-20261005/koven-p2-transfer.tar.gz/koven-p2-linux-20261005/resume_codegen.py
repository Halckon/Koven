#!/usr/bin/env python3
"""Resume only uncompleted samples, preserving the interrupted raw directory."""
import datetime, importlib.util, json, os, statistics, time
from pathlib import Path
import rss_support
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('p2',HERE/'probe-frozen-v1.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
p.RUN=HERE/'run-20261005-codegen'
protocol=json.loads((p.RUN/'protocol-codegen.json').read_text())
# Retain the original two-hour whole-batch deadline, including the interruption.
elapsed_wall=time.time()-datetime.datetime.fromisoformat(protocol['host_clock_utc'].replace('Z','+00:00')).timestamp()
p.START=time.monotonic()-elapsed_wall
assert p.digest(HERE/'probe-frozen-v1.py')==protocol['script_sha256']
assert os.environ['LLVM_SYS_211_PREFIX']==protocol['llvm_prefix']
assert p.get('git','rev-parse','HEAD',cwd=p.REPO)==protocol['main']
assert p.get('rustc','-vV')==protocol['rustc']
group=p.RUN/'runtime-layout';cfg=p.group_config(group)
rows=json.loads((group/'samples.json').read_text())
assert [r['name'] for r in rows]==['calibration-build','calibration-first-launch','calibration-warm-0','calibration-first-launch-0','calibration-warm-1','calibration-first-launch-1']
assert not (group/'raw/calibration-warm-2/sample.json').exists()
inputs=json.loads((group/'source-inputs.json').read_text())
for side,entry in inputs.items():
    assert p.digest(group/(side+'-source.tar'))==entry['source_archive_sha256']
    for file,digest in entry['files'].items():assert p.digest(group/'sources'/side/file)==digest,file
p.save(p.RUN/'resumption-context.json',{
 'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'script_sha256':p.digest(Path(__file__)), 'probe_sha256':p.digest(HERE/'probe-frozen-v1.py'),
 'interruption':'Worker disappeared; no cargo/rustc/probe remained. No exit status or elapsed time invented for incomplete calibration-warm-2.',
 'retained_completed_groups':['receiver','plan-tests'],
 'retained_runtime_completed_samples':[r['name'] for r in rows],
 'incomplete_raw':'runtime-layout/raw/calibration-warm-2',
 'incomplete_raw_sha256':{f.name:p.digest(f) for f in (group/'raw/calibration-warm-2').iterdir() if f.is_file()},
 'resume':'Only missing third calibration rebuild runs with suffix -resumed; first-launch and remaining frozen samples follow original fixed order; no completed sample repeated or deleted.',
 'original_batch_elapsed_wall_seconds_at_resume':elapsed_wall,
 'deadline':'Original two-hour budget retained, including interruption; monotonic anchor reconstructed conservatively from original UTC protocol timestamp (one-second precision).',
 'source_hash_recheck':'Both exported sources and archives match source-inputs exactly',
 'environment':p.environment(),
})
# New plumbing check kept separately, never included in cost cohorts.
timers=[]
for kind,command in [('empty',['/usr/bin/true']),('sleep-50ms',['/usr/bin/sleep','0.05'])]:
 for i in range(10):timers.append(dict(kind=kind,iteration=i,**p.run_wait(command,supervise=True)))
passed=all(r['exit_code']==0 for r in timers) and statistics.median(r['seconds'] for r in timers if r['kind']=='empty')<.020 and .045<statistics.median(r['seconds'] for r in timers if r['kind']=='sleep-50ms')<.080
p.save(p.RUN/'timer-selftest-resumed.json',{'passed':passed,'rows':timers})
assert passed
original_cleanup=p.cleanup_targets
def cleanup(g):
 rss_support.supplement(p,g);original_cleanup(g)
p.cleanup_targets=cleanup
command=['cargo','test','--locked','--offline','-j','2','-p',cfg['package'],*cfg['selection'],'--no-run','--message-format=json']
def execute(label,side,phase,b,target):
 return p.sample(group,label,side,phase,[b,cfg['filter'],'--test-threads=1'],target,cfg['count'])
try:
 caltarget=group/'targets/calibration-before';calbin=p.binary(rows[0])
 (group/'sources/before'/cfg['touch']).touch()
 p.sample(group,'calibration-warm-2-resumed','before','calibration-warm',command,caltarget)
 execute('calibration-first-launch-2-resumed','before','calibration-first-launch',calbin,caltarget)
 for i in range(10):execute(f'calibration-run-{i}','before','calibration-run',calbin,caltarget)
 latest={}
 for i in range(3):
  for side in (['before','after'] if i%2==0 else ['after','before']):
   target=group/'targets'/f'cold-{i}-{side}';assert not target.exists()
   row=p.sample(group,f'cold-{i}-{side}',side,'cold',command,target)
   b=p.binary(row);latest[side]={'binary':b,'target':target}
   execute(f'cold-first-launch-{i}-{side}',side,'first-launch-cold',b,target)
 p.identity(group,cfg,latest)
 for i in range(5):
  for side in (['before','after'] if i%2==0 else ['after','before']):
   (group/'sources'/side/cfg['touch']).touch()
   p.sample(group,f'warm-{i}-{side}',side,'warm',command,latest[side]['target'])
   execute(f'warm-first-launch-{i}-{side}',side,'first-launch-warm',latest[side]['binary'],latest[side]['target'])
 for i in range(10):
  for side in (['before','after'] if i%2==0 else ['after','before']):
   execute(f'run-{i}-{side}',side,'run',latest[side]['binary'],latest[side]['target'])
 for i in range(3):
  for side in (['after','before'] if i%2==0 else ['before','after']):
   p.sample(group,f'noop-{i}-{side}',side,'noop',command,latest[side]['target'])
 p.summarize(group)
 p.save(group/'outcome.json',{'status':'measured-after-interruption','samples':len(json.loads((group/'samples.json').read_text())),'acceptance':'not approved','duration_from_batch_start_seconds':time.monotonic()-p.START,'incomplete_attempt_preserved':'raw/calibration-warm-2','resumption_context':'../resumption-context.json'})
 cleanup(group)
 print('GROUP COMPLETE runtime-layout',flush=True)
 pairs={r['name']:{'before':r['before'],'after':r['after']} for r in json.loads((HERE/'static-review.json').read_text())['pairs']}
 p.run_group(p.CONFIGS[9],pairs)
 p.save(p.RUN/'outcome-codegen.json',{'status':'measured-after-interruption','groups':[c[0] for c in p.CONFIGS[6:]],'seconds':time.monotonic()-p.START,'resumption_context':'resumption-context.json'})
except Exception as ex:
 p.save(p.RUN/'resumption-outcome.json',{'status':'stopped','reason':repr(ex),'elapsed_seconds':time.monotonic()-p.START})
 raise
