#define _GNU_SOURCE
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static unsigned long long now_ns(void) {
    struct timespec value;
    if (clock_gettime(CLOCK_MONOTONIC, &value) != 0) { perror("clock_gettime"); exit(125); }
    return (unsigned long long)value.tv_sec * 1000000000ULL + (unsigned long long)value.tv_nsec;
}

int main(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr, "usage: observer output.json command [args...]\n"); return 125; }
    unsigned long long started = now_ns();
    pid_t pid = fork();
    if (pid == -1) { perror("fork"); return 125; }
    if (pid == 0) {
        execvp(argv[2], argv + 2);
        perror("execvp");
        _exit(127);
    }
    struct rusage usage;
    int status;
    pid_t waited;
    do { waited = wait4(pid, &status, 0, &usage); } while (waited == -1 && errno == EINTR);
    unsigned long long ended = now_ns();
    if (waited != pid) { perror("wait4"); return 125; }
    int code = WIFEXITED(status) ? WEXITSTATUS(status) : 128 + WTERMSIG(status);
    FILE *output = fopen(argv[1], "w");
    if (!output) { perror("fopen"); return 125; }
    fprintf(output,
        "{\"kind\":\"test-child\",\"pid\":%ld,\"exit_code\":%d,"
        "\"start_ns\":%llu,\"end_ns\":%llu,\"seconds\":%.9f,"
        "\"max_reported_process_rss_kib\":%ld,\"user_seconds\":%.6f,\"system_seconds\":%.6f,"
        "\"minor_faults\":%ld,\"major_faults\":%ld,"
        "\"voluntary_context_switches\":%ld,\"involuntary_context_switches\":%ld}\n",
        (long)pid, code, started, ended, (double)(ended - started) / 1e9, usage.ru_maxrss,
        (double)usage.ru_utime.tv_sec + (double)usage.ru_utime.tv_usec / 1e6,
        (double)usage.ru_stime.tv_sec + (double)usage.ru_stime.tv_usec / 1e6,
        usage.ru_minflt, usage.ru_majflt, usage.ru_nvcsw, usage.ru_nivcsw);
    if (fclose(output) != 0) { perror("fclose"); return 125; }
    return code;
}
