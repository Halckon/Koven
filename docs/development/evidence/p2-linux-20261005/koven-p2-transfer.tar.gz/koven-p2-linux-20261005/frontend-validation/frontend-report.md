# Koven 云端 frontend 全量测试报告

## 结论

全量测试已执行，未全绿：1701 passed、2 failed，0 ignored / 0 filtered / 0 measured。
失败在默认 test profile（包含调试符号）复跑中完全复现。未修改源码、测试预期或仓库配置，未 push 或创建 PR。

## 版本与环境

- main 固定 SHA：c5c4a8df271858b23898e0bcf4b55d823c760bb9（PR #52 merge）
- checkout：__KOVEN_REPO__；完成时 git status --short 为空、git diff --check 成功
- 宿主：Debian 13.6 x86_64 Linux，内存约9.7GiB，无swap；GCC14.2.0
- Rust1.96.0 ac68faa20、Cargo1.96.0；官方工具链仅安装在本工作区，无全局PATH修改
- frontend不依赖LLVM；Cargo metadata确认仅1 lib、131 integration targets，无feature、bench、example或binary target；lib doctest启用
- 本轮未执行macOS、其他crate/native、Clippy或完整工作区门禁，不将frontend结果扩大为整个编译器验收

## 完整执行范围

命令：cargo test --locked -p lang-frontend --no-fail-fast -j 2

环境：CARGO_INCREMENTAL=0、CARGO_PROFILE_TEST_DEBUG=0、CARGO_BUILD_JOBS=2、RUST_BACKTRACE=1、独立CARGO_TARGET_DIR=frontend-target。

为了控制131份integration二进制的空间，全量功能回归关闭调试符号；仍为未优化test profile，debug assertions保留。libtest默认并行未限制。此设置仅用于功能回归，不用于P2性能对照。

开始2026-10-05T01:00:26Z，资源观察器在01:02:56Z记录结束（墙时约150.05秒，含轮询尾部等待），Cargo构建报告51.69秒。

- lib：202 passed / 0 failed
- 131 integration targets：1487 passed / 2 failed
- doctests：12 passed / 0 failed
- 所有目标：0 ignored / 0 filtered / 0 measured
- Cargo最终退出码101；--no-fail-fast保证两失败没有阻止其余目标或doctests执行
- 逐目标实际执行清单与Cargo metadata目标集合严格相等，missing/extra均为空

## 两处失败与只读诊断

### parser_long_invalid_number_boundaries

失败用例：every_public_entry_preserves_each_long_invalid_number_before_a_real_operator

crates/lang-frontend/tests/parser_long_invalid_number_boundaries.rs:134–135把0x加65536个A标记为“unsupported radix prefix tail”；第167行要求一个L0008诊断，实际为0。

现行docs/guide/01-lexical.md:161–173已支持0x/0X十六进制，lexer只保留/分类字面量、不在此阶段做数值溢出检查。scanner.rs:243–253按hex扫描A。因此这项断言仍基于旧的“hex未支持”预期。

### parser_token_inventory

失败用例：inventory_is_unique_and_covers_every_public_lexical_family

crates/lang-frontend/tests/parser_token_inventory.rs:19–63仍声明42个硬关键字，包括value、loop、borrow、inout、move、own；第128行要求每项都是Keyword，第一次不匹配为value。

现行docs/guide/01-lexical.md:70–82明确这六项在lexer中是普通Identifier，只在特定Parser上下文解释。scanner.rs:703–743的实际硬关键字为36项。测试库存需要按现行合同重新分类，不能将生产实现改回旧语义取得通过。

## 默认profile复现

命令：CARGO_TARGET_DIR=frontend-repro-target CARGO_INCREMENTAL=0 cargo test --locked -p lang-frontend --no-fail-fast -j2 --test parser_long_invalid_number_boundaries --test parser_token_inventory

未设置CARGO_PROFILE_TEST_DEBUG，Cargo明确报告[unoptimized + debuginfo]，构建20.68秒；两项失败内容与全量完全一致，另2项passed。退出101。该复跑排除了关闭调试符号导致失败的解释。

## 资源与原始证据

全量target约1.1GiB，复现target约454MiB，workspace-local工具链约659MiB；结束空闲约28GiB。每15秒资源记录未触>=8GiB空闲、target<=10GiB守卫。未清理缓存或用户数据。

同目录保留：frontend-full.log、frontend-default-profile-repro.log、frontend-results.json（逐目标计数）、frontend-coverage-check.json、frontend-command.json、frontend-outcome.json、frontend-resources.jsonl、cargo-metadata.json、frontend-package.json、environment.log、clone.log、rust-toolchain-install.log。

后续P2需使用独立冻结profile和target，不能使用本轮功能回归的debug符号设置或将功能失败误报为性能结论。此报告不表示P2完成。
