# P2 十组结构迁移：语义与非默认 CI 覆盖审计

审计日期：2026-10-05。仅只读核查，无构建、测试、benchmark、下载或大规模 hash。完整 SHA、tree、job/step、各条来源见 `semantic-coverage-audit.json`；本轮 API 原始选择结果见 `semantic-ci-metadata.json`。

## 先说结论

- 当前 main `c5c4a8df271858b23898e0bcf4b55d823c760bb9` 确有独立 push [CI 37248672159](https://github.com/Halckon/Koven/actions/runs/37248672159)：15/15 jobs success，tree `b1fe579482fab2aff6449b4b501747856eff6826` 与本地 HEAD 完全相同。这是本轮查到的当前精确 head 证据，不是套用历史绿灯。
- Ubuntu/macOS bounded composition、word-frequency、preview producer/consumer 均实际 success；Ubuntu Linux native sanitizer success，macOS Linux 专属 sanitizer 明确 skipped。当前逐测试计数/动态原始产物未在本轮下载复核。
- 十个 pure-move after 都是对应历史 PR head 的祖先，迁移涉及的全部路径从 after 到该 PR head 均无 diff。本轮用轻量 Git 关系/路径 diff 核实，见 `semantic-source-relations.json`。
- 历史完整 codegen/native 证据存在；本轮 46/48 项成本选择只说明固定 cohort。P2 成本预算接受、旧 Mac 噪声、旧 cloud raw 缺失及整个 P0–P5 收口仍开放。

## 十组覆盖（计数均按来源所属版本，不代表本轮重跑）

| 顺序/配对 | 历史 Linux 定向/完整语义 | 双宿主、非默认与 native 证据 |
|---|---|---|
| 1. multifile ownership `f28359f→422786e` | 旧Linux迁移前后完整72；4条新exact各1；组合里程碑另含完整72。 | [PR36 run 37136658091](https://github.com/Halckon/Koven/actions/runs/37136658091)；PR36双宿主core/iteration/stage/Guide步骤成功；PR37已有raw本轮重读，双宿主完整72且逐身份等于迁移映射。 本片本地未重跑codegen；组合里程碑Linux完整770+2+4与真实native。 |
| 2. ownership iteration integration `e30f9af→5b53bf6` | 旧Linux前后184；frontend lib187；迁移后exact1。 | [PR27 run 37038919150](https://github.com/Halckon/Koven/actions/runs/37038919150)；PR27双宿主各184/0 failed/0 ignored/0 filtered；逐名已在PR评论核验，本轮API重核该独立步骤success。 本地未跑完整codegen/native；PR core步骤实际成功，不由此推断frontend全量。 |
| 3. multifile type `b36d504→25f8977` | 旧Linux前后107；frontend lib187；两条新exact各1。 | [PR28 run 37043194763](https://github.com/Halckon/Koven/actions/runs/37043194763)；PR28双宿主107/0 failed/0 ignored/0 filtered，全部107逐名已在评论核验；本轮API重核stage success。 本地未跑完整codegen/native；PR core步骤实际成功，测试数不在本轮新增推算。 |
| 4. LSP server `3418904→1f3991b` | 旧Linux server11+完整LSP26；其他15身份不变。 | [PR16 run 36991173937](https://github.com/Halckon/Koven/actions/runs/36991173937)；PR16双宿主完整LSP26/0，迁移11逐名核验；本轮API重核core/stage/Guide success。 本片本地无LLVM/native行为测试；LSP测试结构不改变native实现。 |
| 5. iteration private tests `9f9ee52→1df4df1` | 旧Linux迁移40；独立instance_replay53；ownership_iteration184。 | [PR26 run 37035184560](https://github.com/Halckon/Koven/actions/runs/37035184560)；PR26双宿主frontend lib187含40+53；当时CI没有选择184，不能倒填。后继PR27已补双宿主184。 PR26 Ubuntu codegen730，macOS729+既有LLDB ignored1；各4 doctests，历史PR正文计数。 |
| 6. iteration production `14612da→1b24f45` | 旧Linux前后93=40+53；前184与后统一184；最终34完整targets1743 passed。 | [PR36 run 37136658091](https://github.com/Halckon/Koven/actions/runs/37136658091)；PR36双宿主各core/iteration/stage/Guide实际success；PR37已有raw本轮核40+53及完整184。 组合里程碑Linux codegen770+native compile2+doc4，CLI82，LSP45；真实object/link/run与drop/alloc/free。 |
| 7. receiver tests `7318d53→7e542a5` | 旧Linux前后各三轮46；lib清单679，非完整lib执行。 | [PR19 run 37001669457](https://github.com/Halckon/Koven/actions/runs/37001669457)；PR19两宿主迁移46各逐名ok；完整codegen Ubuntu679，macOS678+既有LLDB ignored1。 历史PR core执行完整codegen/native；本地仅46 filter，workspace check不算测试。 |
| 8. planner tests `5e9a295→7720ea9` | 旧Linux前后48；完整lib清单730，非完整lib执行。 | [PR25 run 37030494761](https://github.com/Halckon/Koven/actions/runs/37030494761)；PR25两宿主planner48逐名ok；完整codegen Ubuntu730，macOS729+既有LLDB ignored1；各4 docs。 本地未跑完整codegen/native；历史PR core完整执行，成本48只对应窄cohort。 |
| 9. runtime layout production `f329efa→61e6816` | 旧Linux前后planner48；完整codegen748 lib+2 integration+4 doc均0 failed/ignored/filtered。 | [PR35 run 37123982795](https://github.com/Halckon/Koven/actions/runs/37123982795)；PR35两宿主planner48、const资源60逐名ok；codegen Ubuntu748，macOS747+LLDB ignored1；各2 integration+4 docs。 native::unit_tests::dependent_class_inherited_owner_recipe_value_roundtrip_links_and_runs真实link/run；core/stage/Guide成功。 |
| 10. unit planner production `1b24f45→fa277de` | 旧Linux前后planner48；完整codegen770+2+4；组合34 targets1743项。 | [PR36 run 37136658091](https://github.com/Halckon/Koven/actions/runs/37136658091)；PR36双宿主core/iteration/stage/Guide实际success；PR37已有raw本轮核planner48、完整codegen788/787+1 ignore。 完整native object/link/run、资源drop/alloc/free、ELF/DWARF、输出原子性为组合历史证据；48项成本不替代它。 |

所有上述历史 run 的 head/tree、完成状态、两宿主相关步骤本轮已用 GitHub API 重新核实；历史逐名计数分层来源如下，不能把 API step success 写成新做过逐名 raw 审计：

- PR16/19/25/26：各 PR 正文及 migration 记录的历史逐名验收；PR27 [184 项精确评论](https://github.com/Halckon/Koven/pull/27#issuecomment-5957641883)、PR28 [107 项精确评论](https://github.com/Halckon/Koven/pull/28#issuecomment-5958238050)
- PR35：`docs/archive/specs/0254-const-owned-unit-borrowed-handoff.md` §6，97 个执行批次；Ubuntu2446 passed，Mac2444 passed+LLDB ignored1。core 含 frontend187、codegen748/747+1、2 integration、4 docs、CLI82/81、LSP45；iteration184、stage993、Guide201。CLI差额是Linux专属非UTF8测试
- PR36：本轮新核到 head `855a1b978a4745089de1546e6b06c3fd9eb1992f` 的 run37136658091，9/9 jobs及两host core/iteration/stage/Guide真实成功。原组合本地计数来自 `docs/development/evidence/ownership-planning-milestone.json`，未冒称本轮重新下载PR36双raw
- 补强保留 raw：仓库 `docs/development/evidence/pr37-ci/{ubuntu,macos}-tests.log.gz` 属精确 `385bb23e1123c3a4ba00ec9fe5d964ebc95f1493`、run37185473350。本轮只读重解析两份已有raw：三个integration184/72/107逐身份与迁移映射完全相等，receiver46、planner48、iteration40+replay53均ok，native inherited-owner roundtrip两host真实ok。结果见 `semantic-pr37-retained-raw.json`。此证据只属PR37历史版本

## Sanitizer 的版本与平台界线

- 原十组迁移先于 SPEC0266 动态检测接线，没有对应原 SHA 的 sanitizer 实跑证据；这不是后来套件可以倒填的通过项
- SPEC0266 精确 head `1285e11b655898b2ee549f8486d57a201b8c4f6c`、[run37201621453](https://github.com/Halckon/Koven/actions/runs/37201621453) 的历史逐项账本记录：36组命令，8组ASan/4组LSan对照；ASan三错误exit86，LSan漏4字节/1对象exit87，正常与关闭对照exit0，独立counter1 alloc/1 free；codegen Linux798/Mac797+1 LLDB ignore，两项普通sanitizer模块测试两host通过。原始证据 [artifact11303346793](https://github.com/Halckon/Koven/actions/runs/37201621453/artifacts/11303346793)
- 当前精确 head 的 Ubuntu [job111572025292](https://github.com/Halckon/Koven/actions/runs/37248672159/job/111572025292) Linux sanitizer实际success，证据 [artifact11319789551](https://github.com/Halckon/Koven/actions/runs/37248672159/artifacts/11319789551) 本轮只核元数据且未过期；未读取其内容，不给当前动态case数
- Mac动态ASan/LSan、Koven IR UBSan仍未覆盖；普通sanitizer模块通过不等于Mac动态检测通过，不宣称完整内存安全

## 剩余项与推荐收口边界

- P2成本的正式噪声与退化预算仍需用户明确接受；调查触发线不是接受记录。
- 旧Mac LSP首启混杂与multifile ownership三次尝试/重测失败必须保留：第三次after冷与两侧热构建噪声超线；第四次before13条后因热运行range53.58ms>40ms停止，未采after。新Linux不能消除或重写它。
- 旧cloud原始成本raw与部分原本地对象（如6cc87fe...）仍缺；有历史JSON摘要/hash及公开等价tree不等于恢复原raw。
- 本轮48项固定成本执行不是当前或历史完整codegen/native/sanitizer；新Linux不等于重测Mac。
- 当前head已有真实15/15 CI，因此不再把当前配置双宿主required CI列为未运行；但当前逐名大日志/动态产物本轮未复核。
- macOS既有LLDB ignore不算执行通过；Mac动态sanitizer/IR UBSan属明确未覆盖，不擅自扩大本P2实验。
- 当前独立全量frontend验证结果由主任务报告；bounded CI success不证明全量frontend通过。
- 整个P0–P5与用户后置外部审计不因十组成本采完自动关闭。

下一步：先完成已有十组Linux样本的汇总和证据归档；如需当前逐名确认，在计时窗口结束后只读现成CI raw/产物即可，优先不再构建。将用户是否接受噪声/退化预算单列决定；旧 Mac 与旧 cloud 缺项继续原样保留。

原始依据：`docs/development/engineering-governance-plan.md` P2 §192；`testing.md` 双宿主与分层验收；各 migration 页；`ownership-planning-milestone.md`；`governance-local-continuation.md`；`p2-frontend-cost-followup.md`；归档SPEC0254/0266。
