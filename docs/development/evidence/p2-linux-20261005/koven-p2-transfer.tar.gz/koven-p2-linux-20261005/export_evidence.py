#!/usr/bin/env python3
"""Publish text-only evidence without mutating original samples or source snapshots."""
import hashlib,json,re,tarfile,io,os
from pathlib import Path
HERE=Path(__file__).resolve().parent
OUT=Path('__CLOUD_SHARED__/koven-p2-transfer')
FRONTEND=Path('__CLOUD_WORKSPACE__/validation-logs')
FIX=Path('__CLOUD_WORKSPACE__/frontend-fix-logs')
replacements=[
(str(HERE),'__P2_EVIDENCE_DIR__'),
('__KOVEN_REPO__','__KOVEN_REPO__'),
('__CLOUD_WORKSPACE__','__CLOUD_WORKSPACE__'),
('__CLOUD_SHARED__','__CLOUD_SHARED__'),
('__AGENT_HOME__','__AGENT_HOME__'),
('__ROOT_HOME__','__ROOT_HOME__'),
]
def sha(b):return hashlib.sha256(b).hexdigest()
def redact(text):
 for source,token in replacements:text=text.replace(source,token)
 return text
def scalars(obj,path=()):
 if isinstance(obj,dict):
  for key,val in obj.items():yield from scalars(val,path+(redact(key),))
 elif isinstance(obj,list):
  for i,val in enumerate(obj):yield from scalars(val,path+(i,))
 elif obj is None or isinstance(obj,(bool,int,float)):yield path,obj

def main():
 if not (HERE/'run-20261005-codegen/outcome-codegen.json').exists():raise RuntimeError('Measurements incomplete')
 if OUT.exists():raise RuntimeError('Do not overwrite prior export')
 OUT.mkdir()
 selected={}
 for f in sorted(HERE.rglob('*')):
  if not f.is_file():continue
  rel=f.relative_to(HERE)
  if any(x in rel.parts for x in ['targets','sources','__pycache__','llvm-21-local','llvm-debs','signature-home','static-codegen-after']):continue
  if f.name=='report-draft.md':continue # Superseded draft retained in cloud, not the authoritative handoff
  if f.suffix in ['.tar','.gz','.gpg'] or f.name in ['rss-observer','rss-calibration-child']:continue
  selected[str(rel)]=f
 for f in sorted(FRONTEND.rglob('*')):
  if f.is_file():selected['frontend-validation/'+str(f.relative_to(FRONTEND))]=f
 for f in sorted(FIX.rglob('*')):
  if f.is_file() and f.suffix not in ['.index','.pyc'] and '__pycache__' not in f.parts:
   selected['frontend-fix/'+str(f.relative_to(FIX))]=f
 originals={};published={};jsons=0;json_lines=0;scan=[]
 for name,f in selected.items():
  raw=f.read_bytes();text=raw.decode('utf-8');after=redact(text)
  if f.suffix=='.json':
   orig=json.loads(text);pub=json.loads(after)
   if list(scalars(orig))!=list(scalars(pub)):raise RuntimeError('Numeric/bool/null drift: '+name)
   jsons+=1
  elif f.suffix in ['.jsonl','.log']:
   for before_line,after_line in zip(text.splitlines(),after.splitlines()):
    try:orig=json.loads(before_line);pub=json.loads(after_line)
    except json.JSONDecodeError:continue
    if list(scalars(orig))!=list(scalars(pub)):raise RuntimeError('JSON-lines numeric/bool/null drift: '+name)
    json_lines+=1
  if re.search(r'/(?:Users|home|root|workspace)/',after):scan.append({'file':name,'kind':'private_absolute_path'})
  if re.search(r'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[A-Z0-9]{16}|sk-[A-Za-z0-9]{24,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)',after):scan.append({'file':name,'kind':'credential_pattern'})
  b=after.encode();dest=OUT/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
  originals[name]=sha(raw);published[name]=sha(b)
 if scan:raise RuntimeError('Publication scan findings: '+json.dumps(scan))
 (OUT/'original-sha256.json').write_text(json.dumps(originals,indent=2)+'\n')
 (OUT/'published-sha256.json').write_text(json.dumps(published,indent=2)+'\n')
 (OUT/'redaction.json').write_text(json.dumps({'text_files':len(selected),'json_numeric_boolean_null_invariance_files':jsons,'json_lines_numeric_boolean_null_invariance_records':json_lines,'path_tokens':[b for a,b in replacements],'scan_findings':scan,'scan_scope':'UTF-8 payloads; known private path roots and common credential patterns only; not a universal secret detector','source_archives':'Original git-archive source snapshots retained in cloud evidence; transfer includes per-file and archive hashes and complete public commit/tree IDs, not duplicate source archives','excluded':'No toolchain binaries, downloaded packages, Cargo caches/targets, compiled executables, source tree copies, Python bytecode or signing-home state','raw_preservation':'Original evidence was read only; every published text payload has separate original and publication hashes. Raw phase/count/value records preserved, including failures, noise, and incomplete calibration attempt.','reproduction':'Path tokens in archived scripts require binding to explicit local paths before execution; do not rerun measurements as part of import.'},ensure_ascii=False,indent=2)+'\n')
 archive=OUT.with_suffix('.tar.gz')
 with tarfile.open(archive,'w:gz') as tar:
  for f in sorted(OUT.rglob('*')):
   if not f.is_file():continue
   data=f.read_bytes();member=tarfile.TarInfo('koven-p2-linux-20261005/'+str(f.relative_to(OUT)));member.size=len(data);member.mtime=0;member.mode=0o644
   tar.addfile(member,io.BytesIO(data))
 # Verify archive members and exact published bytes, not just successful compression.
 with tarfile.open(archive,'r:gz') as tar:
  for member in tar.getmembers():
   relative=str(Path(member.name).relative_to('koven-p2-linux-20261005'))
   assert tar.extractfile(member).read()==(OUT/relative).read_bytes(),relative
 info={'archive':str(archive),'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'payload_files':len(selected),'numeric_json_verified':jsons,'numeric_json_line_records_verified':json_lines,'archive_member_verification':'passed'}
 (OUT.parent/'koven-p2-transfer-manifest.json').write_text(json.dumps(info,indent=2)+'\n')
 print(json.dumps(info,indent=2))
if __name__=='__main__':main()
