from pathlib import Path
import json, statistics as st, hashlib, subprocess, re, collections, datetime, math, os
B=Path(os.environ.get('P2_AUDIT_BASE','__P2_EVIDENCE_DIR__')); R=Path(os.environ.get('P2_AUDIT_REPO','__KOVEN_REPO__'))
def load(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def stats(v,time=True):
 m=st.median(v); mad=st.median(abs(x-m) for x in v); ran=max(v)-min(v)
 return dict(values=v,median=m,mad=mad,range=ran,noise_flag=(1.4826*mad>max(.005,.1*m) or ran>max(.020,.3*m)) if time else None)
def check_tree(expected,actual,prefix,errors):
 if isinstance(expected,dict):
  if not isinstance(actual,dict): errors.append(prefix+': type mismatch');return
  for k,v in expected.items():
   if k not in actual:errors.append(prefix+'.'+k+': missing')
   else:check_tree(v,actual[k],prefix+'.'+k,errors)
 elif isinstance(expected,list):
  if not isinstance(actual,list) or len(expected)!=len(actual):errors.append(prefix+': length/type mismatch');return
  for i,(a,b) in enumerate(zip(expected,actual)):check_tree(a,b,prefix+'['+str(i)+']',errors)
 elif isinstance(expected,(float,int)) and not isinstance(expected,bool):
  if not isinstance(actual,(float,int)) or not math.isclose(expected,actual,rel_tol=1e-12,abs_tol=1e-9):errors.append(prefix+': value mismatch')
 elif expected!=actual:errors.append(prefix+': value mismatch')
def paired_order(prefix,n,flip=False):
 return [f'{prefix}-{i}-{s}' for i in range(n) for s in (['before','after'] if (i%2==0)^flip else ['after','before'])]
static=load(B/'static-review.json'); pairs={x['name']:x for x in static['pairs']}
A=dict(audit_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Read-only small JSON/log audit. No build, benchmark, rerun, source-archive/binary rehash, compression, repository write or deletion.',main=static['main'],observed_checkout_head=git('rev-parse','HEAD'),main_scope='Frozen experiment main from static/protocol manifest; the mutable checkout may move for separately authorized frontend fixes',static={},batches={},groups={},limitations=[
'Current Linux libtest --list enumerates complete enabled names, not cfg/ignore metadata for every possible platform/feature. Selected executions separately establish ignored=0 for their cohort.',
'Source-inputs SHA256 inventories and existing source archive/binary retirement digests are cross-checked as records. Large source archives, all source files and retired binaries are not independently rehashed in this audit.',
'Retirement binary hashes identify the last retained executable at each path, not an independent per-launch binary snapshot; warm recompilations reuse paths.',
'Frozen rustc_nonlink_seconds_sum excludes auxiliary wrapper records whose crate name uses --crate-name=... rather than the parsed --crate-name argument. Those raw probes, elapsed times and expected nonzero exits are retained separately; the estimator is not all rustc work.',
'Peak RSS is maximum reported waited-process value, not simultaneous process-tree RSS. C RSS source is child-rusage.json, not Python launcher wait4.',
'Resource rows are command-boundary observations. Disk has one-second watchdog; targets and MemAvailable do not have continuous in-sample peak enforcement.',
'Frozen inquiry thresholds are diagnostic, not accepted budgets; finite observations do not prove equivalence, performance improvement or P2 closure.',
'No historical macOS outcomes, missing older cloud raw, main frontend failures, required CI/native/sanitizer obligations or user cost acceptance are superseded.'])
for name,p in pairs.items():
 e=[]
 for side in ['before','after']:
  if git('rev-parse',p[side])!=p[side]:e.append(side+' SHA mismatch')
  if git('rev-parse',p[side]+'^{tree}')!=p[side+'_tree']:e.append(side+' tree mismatch')
 paths=git('diff-tree','--no-commit-id','--name-only','-r',p['before'],p['after']).splitlines()
 if sorted(paths)!=sorted(p['changed_paths']):e.append('changed paths mismatch')
 inputs=[x for x in paths if Path(x).name in ['Cargo.toml','Cargo.lock','rust-toolchain','rust-toolchain.toml'] or '.cargo' in Path(x).parts]
 if inputs!=p['changed_cargo_toolchain_inputs']:e.append('Cargo/toolchain/config inputs mismatch')
 A['static'][name]=dict(**p,independent_git_errors=e)
A['static_record_scope']=dict(block_comparisons=len(static['block_comparisons']),all_block_record_matches=all(x['matched'] for x in static['block_comparisons']),production_files=len(static['production_files']),all_production_record_matches=all(x['matched'] for x in static['production_files']),note='Previous block/source checks are corroborating records, not repeated whole-source computation here')
A['rss_observer_calibration']={'errors':[]}
cal=load(B/'rss-observer-calibration/summary.json');ce=A['rss_observer_calibration']['errors'];cm=collections.defaultdict(list)
for row in cal['rows']:
 path=B/'rss-observer-calibration'/f"{row['parent_inflated_128mib']}-{row['label']}-{row['iteration']}.json"
 raw=load(path)
 check_tree(raw,row,'rss calibration '+path.name,ce)
 if raw['kind']!='test-child' or raw['exit_code']!=0:ce.append(path.name+': child failure')
 cm[f"{row['parent_inflated_128mib']}-{row['label']}"].append(raw['max_reported_process_rss_kib'])
if len(cal['rows'])!=18 or any(len(v)!=3 for v in cm.values()):ce.append('18-case fixed calibration matrix mismatch')
if cal['observer_sha256']!=sha(B/'rss-observer'):ce.append('observer executable digest mismatch')
for inflated in [False,True]:
 for label,expected in [('true',384),('64mib',66048),('128mib',131584)]:
  if cm[f'{inflated}-{label}']!=[expected]*3:ce.append('calibration documented values mismatch')
A['rss_observer_calibration'].update(rows=18,values_kib=dict(cm),source_sha256=sha(B/'rss-observer.c'),observer_sha256=sha(B/'rss-observer'),child_source_sha256=sha(B/'rss-calibration-child.c'),python_launcher_max_kib=max(r['python_observed_launcher_rss_kib'] for r in cal['rows']),passed=cal['passed'])
resumep=B/'run-20261005-codegen/resumption-context.json'
if resumep.exists():
 ctx=load(resumep);errors=[]
 if ctx['script_sha256']!=sha(B/'resume_codegen.py'):errors.append('resumption script hash mismatch')
 if ctx['probe_sha256']!=sha(B/'probe-frozen-v1.py'):errors.append('resumption frozen-probe hash mismatch')
 for f,h in ctx['incomplete_raw_sha256'].items():
  if sha(resumep.parent/ctx['incomplete_raw']/f)!=h:errors.append('abandoned raw hash mismatch: '+f)
 if (resumep.parent/ctx['incomplete_raw']/'sample.json').exists():errors.append('abandoned raw unexpectedly contains sample')
 A['resumption']={'context':ctx,'errors':errors,'audit_note':'Only two missing calibration samples renamed -resumed; fixed phases/order preserved. Abandoned attempt has no invented timing or exit. Resumption source rehash is an existing worker record, not independently repeated here.'}
for run in sorted(B.glob('run-*')):
 bat={};A['batches'][run.name]=bat
 for p in sorted(run.glob('*protocol*.json')):
  d=load(p);e=[]
  for key,file in [('script_sha256','probe-frozen-v1.py'),('support_script_sha256','rss_support.py'),('source_sha256','rss-observer.c')]:
   if key in d and sha(B/file)!=d[key]:e.append(key+' mismatch')
  if 'driver_sha256' in d and sha(B/'run_codegen.py')!=d['driver_sha256']:e.append('driver hash mismatch')
  if d.get('method_version')=='C child RSS v1' and d['calibration']!=cal:e.append('embedded RSS calibration differs raw calibration summary')
  if 'tool_sha256' in d and d['tool_sha256']!=sha(B/'rss-observer'):e.append('RSS observer tool hash mismatch')
  bat[p.name]=dict(sha256=sha(p),errors=e,script_sha256=d.get('script_sha256'),host_clock_utc=d.get('host_clock_utc'),limits=d.get('limits'),method_version=d.get('method_version'),main=d.get('main'))
 for p in sorted(run.glob('timer-selftest*.json')):
  d=load(p); rows=d['rows']; modes=collections.defaultdict(list)
  for r in rows:modes[r.get('mode',r.get('kind'))].append(r['seconds'])
  med={k:st.median(v) for k,v in modes.items()};independent=all(r['exit_code']==0 and not r['stop_reasons'] for r in rows) and len(rows)==20 and med.get('empty',1)<.02 and .045<med.get('sleep-50ms',0)<.08
  bat[p.name]=dict(sha256=sha(p),reported_passed=d['passed'],independent_passed=independent,medians_seconds=med)
 for group in sorted(run.iterdir()):
  if not group.is_dir() or not (group/'samples.json').exists():continue
  key=str(group.relative_to(B)); cfg=load(group/'protocol.json');rows=load(group/'samples.json');out=load(group/'outcome.json') if (group/'outcome.json').exists() else {'status':'incomplete'}
  complete=out['status'] in ['measured','measured-after-interruption','RSS measured']; rssonly=out['status']=='RSS measured' or 'rss-only' in run.name
  G=dict(status=out['status'],outcome=out,rows=len(rows),errors=[],warnings=[],phase_counts={},identity={},source_inputs={},noise=[],investigations={},all_phase_statistics={},resources={},auxiliary_rustc_records=[],observed_should_panic_names={},raw_files=0,raw_bytes=0,event_count=0,retirement={});A['groups'][key]=G;e=G['errors']
  G['non_sample_raw_directories']={p.name:{f.name:sha(f) for f in p.iterdir() if f.is_file()} for p in (group/'raw').iterdir() if p.is_dir() and p.name not in {r['name'] for r in rows}}
  if complete and any(n!='calibration-warm-2' or cfg['name']!='runtime-layout' for n in G['non_sample_raw_directories']):e.append('unexplained raw directory outside recorded samples')
  if cfg['commits']!={s:pairs[cfg['name']][s] for s in ['before','after']}:e.append('protocol commit pair mismatch')
  if len({r['name'] for r in rows})!=len(rows):e.append('duplicate sample name')
  if out.get('samples') is not None and out['samples']!=len(rows):e.append('outcome samples count mismatch')
  if (group/'source-inputs.json').exists():
   src=load(group/'source-inputs.json');fs={s:src[s]['files'] for s in ['before','after']}
   diffs=sorted(k for k in set(fs['before'])|set(fs['after']) if fs['before'].get(k)!=fs['after'].get(k))
   if diffs!=sorted(pairs[cfg['name']]['changed_paths']):e.append('source-inputs difference set differs Git changed-path set')
   inputs=[k for k in set(fs['before'])|set(fs['after']) if Path(k).name in ['Cargo.toml','Cargo.lock','rust-toolchain','rust-toolchain.toml'] or '.cargo' in Path(k).parts]
   if any(fs['before'].get(k)!=fs['after'].get(k) for k in inputs):e.append('source-inputs Cargo/toolchain/config unequal')
   for s in ['before','after']:
    if any(not re.fullmatch('[0-9a-f]{64}',v) for v in fs[s].values()):e.append(s+' source-input digest format invalid')
   G['source_inputs']=dict(file_counts={s:len(fs[s]) for s in fs},changed_paths=diffs,cargo_toolchain_config_paths=sorted(inputs),source_archive_sha256={s:src[s]['source_archive_sha256'] for s in src},archives_present={s:(group/(s+'-source.tar')).exists() for s in src},large_files_not_rehashed=True)
  else:
   orig=Path(cfg.get('original_cost_group','/nonexistent'))
   if rssonly and orig.exists() and (group/'sources').is_symlink() and (group/'sources').resolve()==(orig/'sources').resolve() and sha(orig/'source-inputs.json')==cfg.get('source_manifest_sha256'):
    G['source_inputs']={'reuses_original_cost_group':str(orig),'source_manifest_sha256':cfg['source_manifest_sha256'],'source_symlink_verified':True}
   else:G['warnings'].append('No source-inputs file or verified supplement link')
  ids=load(group/'identities.json') if (group/'identities.json').exists() else None
  if ids:
   if sorted(ids['mapping'].get(n,n) for n in ids['all']['before'])!=sorted(ids['all']['after']):e.append('complete libtest full-name mapping mismatch')
   if len(ids['mapping'].values())!=len(set(ids['mapping'].values())):e.append('mapping not one-to-one')
   for s in ['before','after']:
    if len(ids['all'][s])!=len(set(ids['all'][s])):e.append(s+' duplicate identity')
    selected=[n for n in ids['all'][s] if cfg['filter'] in n]
    if selected!=ids['selected'][s] or len(selected)!=cfg['count']:e.append(s+' selected identity mismatch')
    ir=next((r for r in rows if r['name']=='identity-'+s),None)
    raw_names=[l[:-6] for l in (group/'raw'/('identity-'+s)/'stdout.log').read_text().splitlines() if l.endswith(': test')]
    if raw_names!=ids['all'][s]:e.append(s+' identity raw mismatch')
    if ir is None or ir['argv'][1:]!=['--list']:e.append(s+' identity argv invalid')
   G['identity']=dict(package=cfg['package'],artifact_name=cfg['artifact_name'],selection=cfg['selection'],all_counts={s:len(ids['all'][s]) for s in ids['all']},selected_counts={s:len(ids['selected'][s]) for s in ids['selected']},mapping_count=len(ids['mapping']),raw_full_name_mapping_checked=True,selected_ignored_checked_from_every_execution=True,cfg_boundary='Only current compiled Linux/default-feature configuration; no cross-platform cfg equivalence claim')
   if cfg['mapping_file']:
    md=load(R/'docs/development/evidence'/cfg['mapping_file']);m=md['mapping'];attr=[x for x in m if 'attributes' in x]
    G['identity']['historical_mapping_attributes']=dict(file=cfg['mapping_file'],records=len(m),explicit_attributes=len(attr),ignored_false=sum(x.get('ignored') is False for x in m),explicit_empty_platform_cfg=sum(x.get('platform_cfg')==[] for x in m),boundary='Historical mapping attrs supplement raw --list; absent fields are not assumed false/empty')
  elif complete:e.append('completed group lacks identities')
  expected=['calibration-build','calibration-first-launch']+[n for i in range(3) for n in [f'calibration-warm-{i}',f'calibration-first-launch-{i}']]+[f'calibration-run-{i}' for i in range(10)]
  expected += [x for n in paired_order('cold',3) for x in [n,n.replace('cold-','cold-first-launch-',1)]]+['identity-before','identity-after']
  expected += [x for n in paired_order('warm',5) for x in [n,n.replace('warm-','warm-first-launch-',1)]]+paired_order('run',10)+paired_order('noop',3,True)
  if cfg['name']=='iteration-production':expected += [x for s in ['before','after'] for x in ['semantic-integration-build-'+s,'semantic-integration-run-'+s]]
  if not rssonly:
   actual=[r['name'].removesuffix('-resumed') for r in rows if not r['phase'].startswith('rss-')]
   if actual!=expected[:len(actual)] or (complete and len(actual)!=len(expected)):e.append('fixed phase count/order mismatch')
   G['fixed_cost_order_checked']=dict(expected=len(expected),observed=len(actual),complete=complete,cold='AB/BA/AB',warm='AB/BA/AB/BA/AB',hot_run='AB/BA repeated 5 times',noop='BA/AB/BA')
  if any(b['start_ns']<a['end_ns'] for a,b in zip(rows,rows[1:])):e.append('main measured command intervals overlap or out of order')
  sums={};environments=[];maxcmd=0;targetcfg=collections.defaultdict(set)
  for row in rows:
   name=row['name'];d=group/'raw'/name
   if load(d/'sample.json')!=row:e.append(name+': samples/raw sample mismatch')
   raw=list(d.iterdir());G['raw_files']+=sum(x.is_file() for x in raw);G['raw_bytes']+=sum(x.stat().st_size for x in raw if x.is_file())
   if row['end_ns']<row['spawn_end_ns'] or row['spawn_end_ns']<row['start_ns']:e.append(name+': invalid timer chronology')
   if abs((row['end_ns']-row['start_ns'])/1e9-row['seconds'])>1e-9:e.append(name+': elapsed mismatch')
   if abs((row['spawn_end_ns']-row['start_ns'])/1e9-row['spawn_seconds'])>1e-9:e.append(name+': spawn mismatch')
   if complete and (row['exit_code']!=0 or row['stop_reasons'] or row.get('validation_error')):e.append(name+': failed measured command')
   ev=[load(p) for p in sorted(d.glob('*.json')) if p.name!='sample.json']
   rc=[x for x in ev if x.get('kind')=='rustc' and '--crate-name' in x['argv']];links=[x for x in ev if x.get('kind')=='link']; G['event_count']+=len(ev)
   if rc!=row['rustc_events'] or links!=row['link_events']:e.append(name+': embedded events mismatch')
   if len(rc)!=row['rustc_invocations'] or len(links)!=row['linker_invocations']:e.append(name+': process count mismatch')
   rids={x['id']:x for x in rc}
   for event in ev:
    if event['start_ns']<row['start_ns'] or event['end_ns']>row['end_ns']:e.append(name+': child event not nested in outer interval')
    if abs((event['end_ns']-event['start_ns'])/1e9-event['seconds'])>1e-8:e.append(name+': process elapsed mismatch')
    if event.get('kind') in ['rustc','link'] and str(event['pid'])==event['id']:e.append(name+': wrapper and child PID equal')
    if event.get('kind')=='rustc' and event not in rc:
     G['auxiliary_rustc_records'].append({'sample':name,'side':row['side'],'phase':row['phase'],'id':event['id'],'exit_code':event['exit_code'],'seconds':event['seconds'],'argv':event['argv'],'excluded_from_frozen_nonlink_sum':True,'purpose':'build-capability-probe' if any('/probe' in a for a in event['argv']) else 'compiler-metadata-query'})
    if complete and event['exit_code']!=0 and not (event.get('kind')=='rustc' and event not in rc and event['exit_code']==1 and any('/probe' in a for a in event['argv']) and any(a in ['--crate-name=proc_macro2','--crate-name=anyhow','--crate-name=thiserror'] for a in event['argv'])):e.append(name+': non-probe event exit nonzero')
   for link in links:
    parent=rids.get(link['rustc_id'])
    if not parent:e.append(name+': linker lacks rustc parent')
    elif link['start_ns']<parent['start_ns'] or link['end_ns']>parent['end_ns']:e.append(name+': linker interval not inside rustc')
    if link['argv'][0]!='/usr/bin/cc':e.append(name+': linker driver differs')
   for rustc in rc:
    if rustc['rustc_id']!=rustc['id']:e.append(name+': rustc wrapper self ID mismatch')
    if rustc['argv'][rustc['argv'].index('--crate-name')+1]==cfg['artifact_name'] and '--test' in rustc['argv']:
     args=rustc['argv'];flags=[args[i+1] for i,x in enumerate(args[:-1]) if x in ['--cfg','-C']];targetcfg[row['side']].add(tuple(flags))
   row['auxiliary_rustc_seconds_sum']=sum(x['seconds'] for x in ev if x.get('kind')=='rustc' and x not in rc)
   childtime=[x['seconds'] for x in ev if x.get('kind')=='test-child']
   if childtime:row['c_child_seconds']=childtime[0]
   derived={'linker_seconds_sum':sum(x['seconds'] for x in links),'rustc_nonlink_seconds_sum':sum(x['seconds']-sum(l['seconds'] for l in links if l['rustc_id']==x['id']) for x in rc),'maximum_reported_process_rss_kib':max([row['max_reported_process_rss_kib']]+[x['max_reported_process_rss_kib'] for x in ev])}
   check_tree(derived,row,name,e)
   stdout=(d/'stdout.log').read_text();art=[];buildfinish=[]
   for line in stdout.splitlines():
    try:x=json.loads(line)
    except json.JSONDecodeError:continue
    if isinstance(x,dict) and x.get('reason')=='compiler-artifact':art.append({'name':x['target']['name'],'kind':x['target']['kind'],'profile_test':x['profile']['test'],'fresh':x['fresh'],'executable':x.get('executable')})
    if isinstance(x,dict) and x.get('reason')=='build-finished':buildfinish.append(x['success'])
   if art!=row['artifacts']:e.append(name+': Cargo artifacts raw mismatch')
   if row['argv'][0]=='cargo':
    expectedargv=['cargo','test','--locked','--offline','-j','2','-p',cfg['package'],*cfg['selection'],'--no-run','--message-format=json']
    if row['phase']=='semantic-build':expectedargv=['cargo','test','--locked','--offline','-j','2','-p','lang-frontend','--test','ownership_iteration','--no-run','--message-format=json']
    if row['argv']!=expectedargv:e.append(name+': Cargo argv mismatch')
    if complete and buildfinish!=[True]:e.append(name+': missing successful Cargo build-finished')
   if row['phase'] in ['warm','calibration-warm']:
    nf=[x for x in art if not x['fresh']]
    if len(nf)!=1 or nf[0]['name']!=cfg['artifact_name'] or not nf[0]['profile_test']:e.append(name+': warm not only intended target nonfresh')
   if row['phase']=='noop' and (not art or any(not x['fresh'] for x in art) or rc or links):e.append(name+': invalid all-fresh noop')
   if 'test_summaries' in row:
    summary=[list(x) for x in re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s',stdout)]
    if summary!=row['test_summaries']:e.append(name+': test summary differs stdout')
    n=184 if row['phase']=='semantic-run' else cfg['count']
    if complete and (len(summary)!=1 or summary[0][0]!='ok' or int(summary[0][1])!=n or any(int(x) for x in summary[0][2:5])):e.append(name+': actual test count/failure/ignore unexpected')
    testlines=re.findall(r'^test (.+?) (?:- should panic )?\.\.\. (ok|ignored|FAILED)$',stdout,re.M)
    panics=re.findall(r'^test (.+) - should panic \.\.\. ok$',stdout,re.M)
    if row['phase']!='semantic-run':
     observed=G['observed_should_panic_names'].setdefault(row['side'],sorted(panics))
     if observed!=sorted(panics):e.append(name+': should-panic annotation varies between executions')
    if ids and row['phase']!='semantic-run':
     if sorted(x[0] for x in testlines)!=sorted(ids['selected'][row['side']]):e.append(name+': executed full names differ selected identity')
     if int(summary[0][5])!=len(ids['all'][row['side']])-n:e.append(name+': filtered-out count differs full identity')
    if row['argv'][-1]!='--test-threads=1':e.append(name+': test threads not one')
   phase=row['phase']
   if phase=='calibration-first-launch':phase='calibration-prebuild-first-launch' if name=='calibration-first-launch' else 'calibration-rebuild-first-launch'
   sums.setdefault(phase,{}).setdefault(row['side'],[]).append(row)
   environments += [row['environment_before'],row['environment_after']];maxcmd=max(maxcmd,row['seconds'])
  G['target_rustc_cfg_and_codegen_options']={s:[list(v) for v in sorted(vv)] for s,vv in targetcfg.items()}
  if set(targetcfg)=={'before','after'} and targetcfg['before']!=targetcfg['after']:e.append('target rustc cfg/codegen options differ by side')
  G['phase_counts']={p:{s:len(v) for s,v in sides.items()} for p,sides in sums.items()}
  for phase,sides in sums.items():
   metrics=['seconds']
   if any(r['rustc_invocations'] for rr in sides.values() for r in rr):metrics+=['rustc_nonlink_seconds_sum','linker_seconds_sum']
   if any(r.get('auxiliary_rustc_seconds_sum',0)>0 for rr in sides.values() for r in rr):metrics+=['auxiliary_rustc_seconds_sum']
   if all('c_child_seconds' in r for rr in sides.values() for r in rr):metrics+=['c_child_seconds']
   dst={};G['all_phase_statistics'][phase]=dst
   for metric in metrics:
    dst[metric]={s:stats([r[metric] for r in rr]) for s,rr in sides.items()}
    for s,d in dst[metric].items():
     if d['noise_flag'] and len(d['values'])>1:G['noise'].append(dict(phase=phase,metric=metric,side=s,**d,scaled_mad=1.4826*d['mad'],mad_threshold=max(.005,.1*d['median']),range_threshold=max(.020,.3*d['median'])))
   if set(sides)=={'before','after'} and len(sides['before'])==len(sides['after']):
    br,ar=sides['before'],sides['after'];scale,floor=(.20,1.) if phase in ['cold','warm','noop','semantic-build','rss-preparation-build'] else (.30,.020)
    times=[b['seconds']-a['seconds'] for a,b in zip(br,ar)];rss=[b['maximum_reported_process_rss_kib']-a['maximum_reported_process_rss_kib'] for a,b in zip(br,ar)]
    G['investigations'][phase]=dict(frozen_gate=phase in ['cold','warm','run'],paired_delta_seconds=times,paired_delta_percent=[100*(b['seconds']-a['seconds'])/a['seconds'] for a,b in zip(br,ar)],paired_median_delta_seconds=st.median(times),paired_median_delta_percent=st.median(100*(b['seconds']-a['seconds'])/a['seconds'] for a,b in zip(br,ar)),time_pairs=[i for i,(a,b) in enumerate(zip(br,ar)) if b['seconds']-a['seconds']>max(floor,scale*a['seconds'])],time_paired_median=st.median(times)>max(floor,scale*st.median(r['seconds'] for r in br)),paired_delta_reported_rss_kib=rss,rss_pairs=[i for i,(a,b) in enumerate(zip(br,ar)) if b['maximum_reported_process_rss_kib']-a['maximum_reported_process_rss_kib']>max(65536,.1*a['maximum_reported_process_rss_kib'])],rss_paired_median=st.median(rss)>max(65536,.1*st.median(r['maximum_reported_process_rss_kib'] for r in br)),rss_acceptance_source=phase in ['cold','warm'])
  if ids and set(G['observed_should_panic_names'])=={'before','after'}:
   if sorted(ids['mapping'].get(n,n) for n in G['observed_should_panic_names']['before'])!=G['observed_should_panic_names']['after']:e.append('mapped should-panic test annotations differ by side')
  if (group/'semantic-integration-identities.json').exists():
   sem=load(group/'semantic-integration-identities.json');semnames={side:re.findall(r'^test (.+?) (?:- should panic )?\.\.\. ok$',(group/'raw'/('semantic-integration-run-'+side)/'stdout.log').read_text(),re.M) for side in ['before','after']}
   if semnames!=sem['executed_full_names'] or semnames['before']!=semnames['after'] or len(semnames['before'])!=184:e.append('semantic integration full-name record mismatch')
   G['semantic_integration']={'verified_count':184,'raw_full_names_equal':semnames['before']==semnames['after'],'separate_from_93_cost_tests':True}
  if (group/'summary.json').exists():
   summary=load(group/'summary.json')['phases'];rec={}
   for phase in ['cold','warm','first-launch-cold','first-launch-warm','run','noop','calibration-warm','calibration-run']:
    sides={s:[r for r in rows if r['side']==s and r['phase']==phase] for s in ['before','after']};rec[phase]={s:stats([r['seconds'] for r in rr]) for s,rr in sides.items() if rr}
    if all(sides.values()) and len(sides['before'])==len(sides['after']):
     i=G['investigations'][phase];v=rec[phase];v.update(paired_delta_seconds=i['paired_delta_seconds'],paired_delta_median_seconds=i['paired_median_delta_seconds'],paired_delta_rss_kib=i['paired_delta_reported_rss_kib'],process_rss_kib={s:stats([r['maximum_reported_process_rss_kib'] for r in rr],False) for s,rr in sides.items()})
     if phase in ['cold','warm']:v['overlapping_process_stage_seconds']={m:{s:stats([r[m] for r in rr]) for s,rr in sides.items()} for m in ['rustc_nonlink_seconds_sum','linker_seconds_sum']}
     if phase in ['cold','warm','run']:v.update(time_investigation_pairs=i['time_pairs'],rss_investigation_pairs=i['rss_pairs'],time_investigation_paired_median=i['time_paired_median'],rss_investigation_paired_median=i['rss_paired_median'])
   check_tree(rec,summary,'summary',e);G['summary_recomputed_from_raw']=True
  if (group/'rss-summary.json').exists():
   rs=load(group/'rss-summary.json');rrows=load(group/'rss-samples.json');vals={s:[] for s in ['before','after']}
   expectedrss=['rss-warmup-before','rss-warmup-after']+paired_order('rss',5)
   if [r['name'] for r in rrows]!=expectedrss:e.append('C RSS count/order mismatch')
   for r in rrows:
    child=load(group/'raw'/r['name']/'child-rusage.json');sample=next(x for x in rows if x['name']==r['name'])
    if r['child']!=child:e.append(r['name']+': RSS child raw mismatch')
    if child['kind']!='test-child' or child['exit_code'] or child['pid']==sample['pid']:e.append(r['name']+': RSS child source/PID invalid')
    if sample['argv'][0]!=str(B/'rss-observer') or sample['argv'][1]!=str(group/'raw'/r['name']/'child-rusage.json') or sample['argv'][2]!=rs['binaries'][r['side']]['path']:e.append(r['name']+': RSS observer argv mismatch')
    if r['binary_sha256']!=rs['binaries'][r['side']]['sha256']:e.append(r['name']+': RSS binary hash mismatch')
    if r['python_launcher_rss_kib']!=sample['max_reported_process_rss_kib']:e.append(r['name']+': RSS launcher record mismatch')
    if r['phase']=='rss-run':vals[r['side']].append(child['max_reported_process_rss_kib'])
   delta=[a-b for b,a in zip(vals['before'],vals['after'])];rd=dict(values_kib=vals,median_kib={s:st.median(v) for s,v in vals.items()},paired_delta_kib=delta,paired_median_delta_kib=st.median(delta),investigation_pairs=[i for i,(b,a) in enumerate(zip(vals['before'],vals['after'])) if a-b>max(65536,.1*b)])
   check_tree(rd,rs,'rss-summary',e);rd['investigation_paired_median']=st.median(delta)>max(65536,.1*st.median(vals['before']));rd['binaries']=rs['binaries'];G['c_child_rss']=rd
  if (group/'target-retirement.json').exists():
   retire=load(group/'target-retirement.json');hashes=retire['raw_files_sha256'];actual={str(p.relative_to(group)):sha(p) for p in sorted((group/'raw').rglob('*')) if p.is_file()}
   missing=sorted(set(actual)-set(hashes));stale=sorted(set(hashes)-set(actual));mismatch=[k for k in hashes if k in actual and hashes[k]!=actual[k]]
   if missing or stale or mismatch:e.append('retirement raw inventory/digest mismatch')
   expected_target=str((group/'targets').resolve())
   if retire['target_path']!=expected_target:e.append('retirement target path wrong')
   if (group/'targets').exists():G['warnings'].append('Retirement file exists but target directory currently exists')
   bins={b['path']:b for b in retire['binaries']};expectedbins={a['executable'] for row in rows for a in row['artifacts'] if a['executable']}
   if set(bins)!=expectedbins:e.append('retirement executable path coverage mismatch')
   if 'c_child_rss' in G:
    for side,b in G['c_child_rss']['binaries'].items():
     if b['path'] not in bins or bins[b['path']]['sha256']!=b['sha256']:e.append(side+' retirement/C RSS binary hash mismatch')
   G['retirement']=dict(raw_hashes_checked=len(hashes),raw_hash_missing=missing,raw_hash_extra=stale,raw_hash_mismatch=mismatch,artifact_bytes=retire['artifact_bytes'],binary_count=len(bins),target_absent=not (group/'targets').exists(),large_binary_hashes_not_recomputed=True)
  elif complete:e.append('completed group missing retirement')
  G['resources']=dict(max_command_seconds=maxcmd,max_boundary_target_bytes=max(r['target_bytes'] for r in rows),min_boundary_free_bytes=min(x['free_bytes'] for x in environments),min_boundary_mem_available_kib=min(x['mem_available_kib'] for x in environments),resource_stop_reasons=[dict(name=r['name'],reasons=r['stop_reasons']) for r in rows if r['stop_reasons']],nonzero_exits=[dict(name=r['name'],exit=r['exit_code']) for r in rows if r['exit_code']])
  for row in rows:
   if row['environment_before']['free_bytes']<8*1024**3 or row['environment_before']['mem_available_kib']<1.5*1024**2:e.append(row['name']+': pre-command resource limit violated')
   if row['target_bytes']>10*1024**3:G['warnings'].append(row['name']+': post-command target boundary exceeds 10GiB')
  for phase,i in G['investigations'].items():
   if i['time_pairs'] or i['time_paired_median'] or (i['rss_acceptance_source'] and (i['rss_pairs'] or i['rss_paired_median'])):G['warnings'].append('Investigation threshold hit: '+phase)
A['noise_flags']=[dict(group=k,**n) for k,g in A['groups'].items() for n in g['noise']]
A['time_investigation_hits']=[dict(group=k,phase=p,**i) for k,g in A['groups'].items() for p,i in g['investigations'].items() if i['time_pairs'] or i['time_paired_median']]
A['rss_investigation_hits']=[dict(group=k,phase=p,**i) for k,g in A['groups'].items() for p,i in g['investigations'].items() if i['rss_acceptance_source'] and (i['rss_pairs'] or i['rss_paired_median'])]+[dict(group=k,phase='c-child-rss',**g['c_child_rss']) for k,g in A['groups'].items() if 'c_child_rss' in g and (g['c_child_rss']['investigation_pairs'] or g['c_child_rss']['investigation_paired_median'])]
A['errors']=[dict(group=k,error=x) for k,g in A['groups'].items() for x in g['errors']]+[dict(pair=k,error=x) for k,g in A['static'].items() for x in g['independent_git_errors']]+[dict(batch=k,record=p,error=x) for k,g in A['batches'].items() for p,r in g.items() for x in r.get('errors',[])]
A['errors'] += [dict(record='rss_observer_calibration',error=x) for x in A['rss_observer_calibration']['errors']]+[dict(record='resumption',error=x) for x in A.get('resumption',{}).get('errors',[])]
A['totals']=dict(groups=len(A['groups']),completed_cost_groups=sum(g['status'] in ['measured','measured-after-interruption'] for g in A['groups'].values()),completed_rss_only_groups=sum(g['status']=='RSS measured' for g in A['groups'].values()),rows=sum(g['rows'] for g in A['groups'].values()),errors=len(A['errors']),noise_flags=sum(len(g['noise']) for g in A['groups'].values()))
A['original_findings']=[{'finding':'Frozen summarize() omits paired first-launch time investigation checks while the plan defines an execution inquiry threshold. Independent raw review found a plan-tests cold-first-launch single-pair hit.','group':'run-20261005-codegen/plan-tests','phase':'first-launch-cold','pair_index':1,'before_seconds':0.161750947,'after_seconds':0.218992066,'delta_seconds':0.057241119,'delta_percent':35.3884289777914,'threshold_seconds':0.0485252841,'paired_median_not_hit':True,'raw_diagnostics':{'before_cpu_user_plus_sys_seconds':0.066837,'after_cpu_user_plus_sys_seconds':0.108116,'before_involuntary_context_switches':4,'after_involuntary_context_switches':21,'before_major_faults':0,'after_major_faults':0,'attribution':'CPU and scheduler differences coexist; raw does not identify their cause or establish a module-relocation effect'},'disposition':'Original finding required a separately versioned correction after measurement completion; final disposition is recorded separately in summary-v2-validation.json when present.'}]
A['audit_script_sha256']=sha(Path(__file__))
A['audit_rerun']='P2_AUDIT_BASE=<evidence-dir> P2_AUDIT_REPO=<matching-repo> python independent-audit.py'
A['aggregate']=A['totals']
A['aggregate']['raw_files_hashed']=sum(g['retirement'].get('raw_hashes_checked',0) for g in A['groups'].values())
A['aggregate']['auxiliary_rustc_records']=sum(len(g['auxiliary_rustc_records']) for g in A['groups'].values())
A['aggregate']['auxiliary_rustc_nonzero_exits']=sum(p['exit_code']!=0 for g in A['groups'].values() for p in g['auxiliary_rustc_records'])
A['aggregate']['time_investigation_hits']=len(A['time_investigation_hits'])
A['aggregate']['rss_investigation_hits']=len(A['rss_investigation_hits'])
(B/'independent-audit.json').write_text(json.dumps(A,ensure_ascii=False,indent=2)+'\n')
lines=['# Koven P2 Linux 独立只读 raw 审计', '', '审计 UTC：'+A['audit_utc'], '', '仅查小 JSON/log、Git 对象元数据与已登记摘要；未构建、执行 benchmark、重哈希源码 tar/大型二进制、压缩、修改仓库或清理 targets。', '', '## 当前结果', '', f"完整成本组 {A['totals']['completed_cost_groups']}；独立 RSS 补测组 {A['totals']['completed_rss_only_groups']}；所读样本 {A['totals']['rows']}；一致性错误 {A['totals']['errors']}。", '', '十对完整 SHA、tree 与 changed paths 独立 Git 核对一致。源输入清单差集对照 Git diff；Cargo/lock/toolchain/.cargo 两侧相等。原有400块/九生产文件重核是佐证记录，本次未重新 hash 巨型源码。', '', '## 每组核对', '']
for k,g in A['groups'].items():
 lines += [f"### {k}",f"状态：{g['status']}；样本 {g['rows']}；raw 小文件 {g['raw_files']}；事件 {g['event_count']}；retirement raw hash 核对 {g['retirement'].get('raw_hashes_checked',0)}。",f"一致性错误：{'; '.join(g['errors']) or '无'}",f"警示：{'; '.join(g['warnings']) or '无'}"]
 for n in g['noise']:lines.append(f"- 噪声：{n['phase']} / {n['metric']} / {n['side']}；median={n['median']:.9f}s，MAD={n['mad']:.9f}s，range={n['range']:.9f}s")
 lines.append('')
lines+=['## 原始调查遗漏与解释','','plan-tests 冷产物首启第二对（BA，第1号索引）：0.161750947→0.218992066s，+0.057241119s / +35.3884%，超过 execution max(30%,20ms) 单对调查线；配对中位未触线。冻结 summarize() 只对cold/warm/run做调查标志，遗漏首启。这不是删除或重跑该样本的理由。独立诊断保留，原冻结脚本/summary不改。后续工具修复另见 summary-v2-repair.md，不改本审计的原始发现。','','依赖 build-capability probes 和 compiler metadata queries 全部保留为 auxiliary_rustc_records。预期能力探测非零不是目标构建失败；冻结非link总和不含 --crate-name=... 形式，不能称全部 rustc 工作。RSS补测 outer/child墙时另列为诊断，不并入热运行成本cohort。','','## 证据边界','',*[f'- {x}' for x in A['limitations']],'','完整逐阶段原值、paired delta/percent、调查线、资源数、原始记录校验详情见 independent-audit.json。所有失败及噪声原样保留。此审计不代表用户预算接受、不关闭 P2、不证明性能等价。']
(B/'independent-audit.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(A['totals']))
for k,g in A['groups'].items():
 print(k,'ERRORS',g['errors'],'WARN',g['warnings'])
 for n in g['noise']:print(' NOISE',n['phase'],n['metric'],n['side'],n['median'],n['mad'],n['range'])
