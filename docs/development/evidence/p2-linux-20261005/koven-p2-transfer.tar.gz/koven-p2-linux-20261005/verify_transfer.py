#!/usr/bin/env python3
"""Verify a received text-only evidence directory. Does not run any archived sample."""
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else __file__).resolve()
if root.is_file():root=root.parent
manifest=json.loads((root/'published-sha256.json').read_text())
allowed_extra={'original-sha256.json','published-sha256.json','redaction.json'}
actual={str(f.relative_to(root)) for f in root.rglob('*') if f.is_file()}
if actual!=set(manifest)|allowed_extra:raise SystemExit('Unexpected/missing file set')
for name,expected in manifest.items():
    path=Path(name)
    if path.is_absolute() or '..' in path.parts:raise SystemExit('Unsafe member path')
    f=root/path
    if f.is_symlink() or not f.is_file():raise SystemExit('Invalid file: '+name)
    if hashlib.sha256(f.read_bytes()).hexdigest()!=expected:raise SystemExit('Hash mismatch: '+name)
original=json.loads((root/'original-sha256.json').read_text())
if set(original)!=set(manifest):raise SystemExit('Original/published manifest member mismatch')
redaction=json.loads((root/'redaction.json').read_text())
if redaction['scan_findings']:raise SystemExit('Publisher reported scan findings')
print(json.dumps({'status':'verified','files':len(manifest),'path_safety':'passed','source_and_published_keys':'equal','sample_execution':'none'},indent=2))
