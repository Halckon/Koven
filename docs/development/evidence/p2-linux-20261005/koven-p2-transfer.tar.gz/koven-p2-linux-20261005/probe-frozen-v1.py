#!/usr/bin/env python3
"""Frozen bounded Linux P2 probe. Writes only its dedicated run directory."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import statistics
import subprocess
import sys
import threading
import time

HERE = Path(__file__).resolve().parent
REPO = Path('__KOVEN_REPO__')
RUN = HERE / 'run-20261005'
START = time.monotonic()
GiB = 1024**3
JOBS = 2
CONFIGS = [
    ('multifile-ownership', 'lang-frontend', ['--test','multifile_ownership_checking'], '', 72,
     'crates/lang-frontend/tests/multifile_ownership_checking.rs','multifile-ownership-test-migration.json'),
    ('ownership-iteration', 'lang-frontend', ['--test','ownership_iteration'], '', 184,
     'crates/lang-frontend/tests/ownership_iteration.rs','ownership-iteration-test-migration.json'),
    ('multifile-type', 'lang-frontend', ['--test','multifile_type_checking'], '', 107,
     'crates/lang-frontend/tests/multifile_type_checking.rs','multifile-type-test-migration.json'),
    ('lsp','lang-lsp',['--bin','lang-lsp'],'server::tests',11,
     'crates/lang-lsp/src/server.rs',None),
    ('iteration-tests','lang-frontend',['--lib'],
     'ownership_checking::checker::drop_planner::iteration::tests',40,
     'crates/lang-frontend/src/ownership_checking/checker/drop_planner/iteration.rs',
     'drop-iteration-test-migration.json'),
    ('iteration-production','lang-frontend',['--lib'],
     'ownership_checking::checker::drop_planner::iteration',93,
     'crates/lang-frontend/src/ownership_checking/checker/drop_planner/iteration.rs',None),
    ('receiver','lang-codegen',['--lib'],'unit_lower_receiver_tests',46,
     'crates/lang-codegen/src/ssa/unit_lower_receiver_tests.rs',None),
    ('plan-tests','lang-codegen',['--lib'],'unit_plan_tests',48,
     'crates/lang-codegen/src/ssa/unit_plan_tests.rs',None),
    ('runtime-layout','lang-codegen',['--lib'],'unit_plan_tests',48,
     'crates/lang-codegen/src/ssa/unit_plan.rs',None),
    ('unit-planner','lang-codegen',['--lib'],'unit_plan_tests',48,
     'crates/lang-codegen/src/ssa/unit_plan.rs',None),
]


def save(path, obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
    temp.replace(path)


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def get(*args,cwd=None):
    return subprocess.check_output(list(args),cwd=cwd,text=True).strip()


def environment():
    mem={l.split(':')[0]:l.split(':')[1].strip() for l in Path('/proc/meminfo').read_text().splitlines()}
    return {'loadavg':Path('/proc/loadavg').read_text().strip(),
            'mem_available_kib':int(mem['MemAvailable'].split()[0]),
            'free_bytes':shutil.disk_usage(RUN).free,
            'pressure':{k:(Path('/proc/pressure')/k).read_text() for k in ['cpu','memory','io'] if (Path('/proc/pressure')/k).exists()}}


def target_size():
    targets=list(RUN.glob('*/targets'))
    if not targets:return 0
    return sum(int(get('du','-sk',str(p)).split()[0])*1024 for p in targets)


def limits():
    e=environment()
    if time.monotonic()-START>7200:raise RuntimeError('two-hour measurement limit')
    if e['free_bytes']<8*GiB:raise RuntimeError('free space below 8 GiB')
    if e['mem_available_kib']<int(1.5*1024**2):raise RuntimeError('MemAvailable below 1.5 GiB')
    if target_size()>10*GiB:raise RuntimeError('new target allocation exceeded 10 GiB')
    return e


def run_wait(command, cwd=None, env=None, out=None, err=None, supervise=False):
    """Blocking wait4, no polling-based elapsed estimate; rusage is never a tree sum."""
    start=time.perf_counter_ns()
    proc=subprocess.Popen(command,cwd=cwd,env=env,stdout=out,stderr=err,
                          start_new_session=supervise)
    launched=time.perf_counter_ns()
    done=threading.Event()
    reasons=[]
    def watch():
        while not done.wait(1):
            reason=None
            if (time.perf_counter_ns()-start)/1e9>1200:reason='command exceeded 20 minutes'
            elif time.monotonic()-START>7200:reason='global measurement time limit'
            elif shutil.disk_usage(RUN).free<8*GiB:reason='disk free below 8 GiB'
            if reason:
                reasons.append(reason)
                try:os.killpg(proc.pid,signal.SIGTERM)
                except ProcessLookupError:pass
                if not done.wait(10):
                    try:os.killpg(proc.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                break
    thread=threading.Thread(target=watch,daemon=True) if supervise else None
    if thread:thread.start()
    pid,status,usage=os.wait4(proc.pid,0)
    end=time.perf_counter_ns()
    proc.returncode=os.waitstatus_to_exitcode(status)
    done.set()
    if thread:thread.join()
    return dict(argv=command,pid=pid,start_ns=start,spawn_end_ns=launched,end_ns=end,
                seconds=(end-start)/1e9,spawn_seconds=(launched-start)/1e9,
                exit_code=proc.returncode,stop_reasons=reasons,
                user_seconds=usage.ru_utime,system_seconds=usage.ru_stime,
                max_reported_process_rss_kib=usage.ru_maxrss,
                minor_faults=usage.ru_minflt,major_faults=usage.ru_majflt,
                voluntary_context_switches=usage.ru_nvcsw,
                involuntary_context_switches=usage.ru_nivcsw)


def wrapper(mode):
    env=dict(os.environ)
    ident=str(os.getpid())
    if mode=='rustc':
        env['P2_RUSTC_ID']=ident
        cmd=sys.argv[2:]
    else:cmd=['/usr/bin/cc',*sys.argv[2:]]
    row=run_wait(cmd,env=env)
    row.update(kind=mode,id=ident,rustc_id=env.get('P2_RUSTC_ID'))
    save(Path(env['P2_EVENTS'])/(mode+'-'+ident+'.json'),row)
    sys.exit(row['exit_code'] if row['exit_code']>=0 else 128-row['exit_code'])


def timer_selftest():
    RUN.mkdir(exist_ok=True)
    path=RUN/'timer-selftest.json'
    rows=[]
    for mode,cmd in [('empty',['/usr/bin/true']),('sleep-50ms',['/usr/bin/sleep','0.05'])]:
        for i in range(10):rows.append(dict(mode=mode,iteration=i,**run_wait(cmd)))
    fast=[r['seconds'] for r in rows if r['mode']=='empty']
    slow=[r['seconds'] for r in rows if r['mode']=='sleep-50ms']
    passed=(all(r['exit_code']==0 for r in rows) and statistics.median(fast)<.02
            and .045<statistics.median(slow)<.08)
    save(path,{'rows':rows,'passed':passed,'note':'timer plumbing check, not a test-result performance calibration'})
    if not passed:raise RuntimeError('timer selftest failed')
    print('Timer selftest passed',flush=True)


def sample(group,name,side,phase,command,target,expected_count=None):
    before=limits()
    directory=group/'raw'/name
    directory.mkdir(parents=True)
    env=dict(os.environ)
    for key in list(env):
        if key.startswith('CARGO_PROFILE_') or key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']:
            del env[key]
    env.update(CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(target),
               RUSTC_WRAPPER=str(RUN/'rustc-wrapper'),
               RUSTFLAGS='-C linker='+str(RUN/'link-wrapper'),
               P2_EVENTS=str(directory))
    with (directory/'stdout.log').open('wb') as out,(directory/'stderr.log').open('wb') as err:
        row=run_wait(command,cwd=group/'sources'/side,env=env,out=out,err=err,supervise=True)
    row.update(name=name,side=side,phase=phase,target=str(target),environment_before=before,
               environment_after=environment(),target_bytes=target_size())
    events=[json.loads(p.read_text()) for p in sorted(directory.glob('*.json'))]
    rustcs=[e for e in events if e['kind']=='rustc' and '--crate-name' in e['argv']]
    links=[e for e in events if e['kind']=='link']
    row['rustc_events']=rustcs
    row['link_events']=links
    row['rustc_invocations']=len(rustcs)
    row['linker_invocations']=len(links)
    row['linker_seconds_sum']=sum(e['seconds'] for e in links)
    row['rustc_nonlink_seconds_sum']=sum(e['seconds']-sum(l['seconds'] for l in links if l['rustc_id']==e['id']) for e in rustcs)
    row['maximum_reported_process_rss_kib']=max([row['max_reported_process_rss_kib']]+[e['max_reported_process_rss_kib'] for e in events])
    row['artifacts']=[]
    for line in (directory/'stdout.log').read_text().splitlines():
        try:obj=json.loads(line)
        except json.JSONDecodeError:continue
        if isinstance(obj,dict) and obj.get('reason')=='compiler-artifact':
            row['artifacts'].append({'name':obj['target']['name'],'kind':obj['target']['kind'],
                                     'profile_test':obj['profile']['test'],'fresh':obj['fresh'],
                                     'executable':obj.get('executable')})
    if expected_count is not None:
        summary=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s',
                           (directory/'stdout.log').read_text())
        row['test_summaries']=summary
        if len(summary)!=1 or summary[0][0]!='ok' or int(summary[0][1])!=expected_count or any(int(v) for v in summary[0][2:5]):
            row['validation_error']='unexpected test summary'
    if phase in ['warm','calibration-warm']:
        rebuilt=[a for a in row['artifacts'] if not a['fresh']]
        if len(rebuilt)!=1 or rebuilt[0]['name']!=group_config(group)['artifact_name'] or not rebuilt[0]['profile_test']:
            row['validation_error']='warm artifact freshness mismatch'
    if phase=='noop' and (any(not a['fresh'] for a in row['artifacts']) or rustcs or links):
        row['validation_error']='no-op rebuilt'
    save(directory/'sample.json',row)
    samples=group/'samples.json'
    previous=json.loads(samples.read_text()) if samples.exists() else []
    previous.append(row);save(samples,previous)
    print(json.dumps({k:row[k] for k in ['name','seconds','exit_code','target_bytes']}),flush=True)
    if row['exit_code'] or row['stop_reasons'] or row.get('validation_error'):
        raise RuntimeError(name+': '+str(row.get('validation_error') or row['stop_reasons'] or row['exit_code']))
    return row


def group_config(group):
    return json.loads((group/'protocol.json').read_text())


def binary(row):
    bins=[a['executable'] for a in row['artifacts'] if a['executable']]
    if len(bins)!=1:raise RuntimeError('expected exactly one test executable')
    return bins[0]


def names(row,group):
    return [line[:-6] for line in (group/'raw'/row['name']/'stdout.log').read_text().splitlines() if line.endswith(': test')]


def identity(group,cfg,latest):
    allnames={}
    selected={}
    for side in ['before','after']:
        row=sample(group,'identity-'+side,side,'identity',[latest[side]['binary'],'--list'],latest[side]['target'])
        allnames[side]=names(row,group)
        selected[side]=[n for n in allnames[side] if cfg['filter'] in n]
        if len(selected[side])!=cfg['count']:raise RuntimeError('identity count mismatch')
    mapping={}
    if cfg['mapping_file']:
        doc=json.loads((REPO/'docs/development/evidence'/cfg['mapping_file']).read_text())
        for row in doc['mapping']:
            if 'old_name' in row:mapping[row['old_name']]=row['new_name']
            elif row.get('test'):
                prefix='ownership_checking::checker::drop_planner::iteration::tests::'
                mapping[prefix+row['name']]=prefix+row['module']+'::'+row['name']
    elif cfg['name'] in ['iteration-production','runtime-layout','unit-planner']:
        mapping={n:n for n in selected['before']}
    else:
        for n in selected['before']:
            matches=[a for a in selected['after'] if a.rsplit('::',1)[-1]==n.rsplit('::',1)[-1]]
            if len(matches)!=1:raise RuntimeError('ambiguous domain mapping')
            new=matches[0]
            if new.rsplit('::',2)[0]!=n.rsplit('::',1)[0]:raise RuntimeError('not exactly one added domain')
            mapping[n]=new
    mapped=[mapping.get(n,n) for n in allnames['before']]
    if sorted(mapped)!=sorted(allnames['after']):raise RuntimeError('complete identity mapping mismatch')
    save(group/'identities.json',{'all':allnames,'selected':selected,'mapping':mapping,
                                'complete_mapping_equal':True,'count':cfg['count']})


def stats(values,is_time=True):
    m=statistics.median(values);mad=statistics.median(abs(x-m) for x in values)
    return {'values':values,'median':m,'mad':mad,'range':max(values)-min(values),
            'noise_flag':(1.4826*mad>max(.005,.10*m) or max(values)-min(values)>max(.020,.30*m)) if is_time else None}


def summarize(group):
    rows=json.loads((group/'samples.json').read_text())
    result={}
    for phase in ['cold','warm','first-launch-cold','first-launch-warm','run','noop','calibration-warm','calibration-run']:
        sides={side:[r for r in rows if r['side']==side and r['phase']==phase] for side in ['before','after']}
        result[phase]={side:stats([r['seconds'] for r in rr]) for side,rr in sides.items() if rr}
        if all(sides.values()) and len(sides['before'])==len(sides['after']):
            diffs=[b['seconds']-a['seconds'] for a,b in zip(sides['before'],sides['after'])]
            rss=[b['maximum_reported_process_rss_kib']-a['maximum_reported_process_rss_kib'] for a,b in zip(sides['before'],sides['after'])]
            result[phase]['paired_delta_seconds']=diffs
            result[phase]['paired_delta_median_seconds']=statistics.median(diffs)
            result[phase]['paired_delta_rss_kib']=rss
            result[phase]['process_rss_kib']={side:stats([r['maximum_reported_process_rss_kib'] for r in rr],False) for side,rr in sides.items()}
            if phase in ['cold','warm']:
                result[phase]['overlapping_process_stage_seconds']={metric:{side:stats([r[metric] for r in rr]) for side,rr in sides.items()} for metric in ['rustc_nonlink_seconds_sum','linker_seconds_sum']}
            if phase in ['cold','warm','run']:
                scale,floor=(.30,.020) if phase=='run' else (.20,1.)
                result[phase]['time_investigation_pairs']=[i for i,(a,b) in enumerate(zip(sides['before'],sides['after'])) if b['seconds']-a['seconds']>max(floor,scale*a['seconds'])]
                result[phase]['rss_investigation_pairs']=[i for i,(a,b) in enumerate(zip(sides['before'],sides['after'])) if b['maximum_reported_process_rss_kib']-a['maximum_reported_process_rss_kib']>max(65536,.10*a['maximum_reported_process_rss_kib'])]
                result[phase]['time_investigation_paired_median']=statistics.median(diffs)>max(floor,scale*statistics.median(r['seconds'] for r in sides['before']))
                result[phase]['rss_investigation_paired_median']=statistics.median(rss)>max(65536,.10*statistics.median(r['maximum_reported_process_rss_kib'] for r in sides['before']))
    save(group/'summary.json',{'phases':result,'acceptance':'Not an owner-accepted budget; fixed sample descriptive evidence only; noise flags do not authorize reruns'})


def cleanup_targets(group):
    target=(group/'targets').resolve()
    if target.parent!=group.resolve() or target.name!='targets' or group.parent.resolve()!=RUN.resolve():raise RuntimeError('cleanup path guard')
    binaries=[]
    for row in json.loads((group/'samples.json').read_text()):
        for artifact in row['artifacts']:
            p=Path(artifact['executable']) if artifact['executable'] else None
            if p and p.exists() and str(p) not in [r['path'] for r in binaries]:
                binaries.append({'path':str(p),'sha256':digest(p),'size':p.stat().st_size})
    save(group/'target-retirement.json',{'target_path':str(target),'artifact_bytes':int(get('du','-sk',str(target)).split()[0])*1024,
        'binaries':binaries,'reason':'Authorized removal of this probe newly generated reproducible artifacts only; sources/raw/protocol remain',
        'raw_files_sha256':{str(p.relative_to(group)):digest(p) for p in sorted((group/'raw').rglob('*')) if p.is_file()}})
    shutil.rmtree(target)


def run_group(config,pairs):
    name,package,select,filt,count,touch,mapping=config
    group=RUN/name
    group.mkdir()
    (group/'targets').mkdir()
    cfg=dict(name=name,package=package,selection=select,filter=filt,count=count,touch=touch,mapping_file=mapping,
             artifact_name=select[1] if len(select)>1 else package.replace('-','_'),commits=pairs[name])
    save(group/'protocol.json',cfg)
    for side in ['before','after']:
        dest=group/'sources'/side;dest.mkdir(parents=True)
        with (group/(side+'-source.tar')).open('wb') as f:
            subprocess.run(['git','archive',pairs[name][side]],cwd=REPO,stdout=f,check=True)
        subprocess.run(['tar','-xf',str(group/(side+'-source.tar')),'-C',str(dest)],check=True)
    save(group/'source-inputs.json',{side:{'source_archive_sha256':digest(group/(side+'-source.tar')),
        'files':{str(p.relative_to(group/'sources'/side)):digest(p) for p in (group/'sources'/side).rglob('*') if p.is_file()}}
        for side in ['before','after']})
    command=['cargo','test','--locked','--offline','-j',str(JOBS),'-p',package,*select,'--no-run','--message-format=json']
    def execute(label,side,phase,b,target):
        return sample(group,label,side,phase,[b,*([filt] if filt else []),'--test-threads=1'],target,count)
    caltarget=group/'targets'/'calibration-before'
    cal=sample(group,'calibration-build','before','calibration-build',command,caltarget)
    calbin=binary(cal)
    execute('calibration-first-launch','before','calibration-first-launch',calbin,caltarget)
    for i in range(3):
        (group/'sources'/'before'/touch).touch()
        sample(group,f'calibration-warm-{i}','before','calibration-warm',command,caltarget)
        execute(f'calibration-first-launch-{i}','before','calibration-first-launch',calbin,caltarget)
    for i in range(10):execute(f'calibration-run-{i}','before','calibration-run',calbin,caltarget)
    latest={}
    for i in range(3):
        for side in (['before','after'] if i%2==0 else ['after','before']):
            target=group/'targets'/f'cold-{i}-{side}'
            if target.exists():raise RuntimeError('cold target already exists')
            row=sample(group,f'cold-{i}-{side}',side,'cold',command,target)
            b=binary(row);latest[side]={'binary':b,'target':target}
            execute(f'cold-first-launch-{i}-{side}',side,'first-launch-cold',b,target)
    identity(group,cfg,latest)
    for i in range(5):
        for side in (['before','after'] if i%2==0 else ['after','before']):
            (group/'sources'/side/touch).touch()
            sample(group,f'warm-{i}-{side}',side,'warm',command,latest[side]['target'])
            execute(f'warm-first-launch-{i}-{side}',side,'first-launch-warm',latest[side]['binary'],latest[side]['target'])
    for i in range(10):
        for side in (['before','after'] if i%2==0 else ['after','before']):
            execute(f'run-{i}-{side}',side,'run',latest[side]['binary'],latest[side]['target'])
    for i in range(3):
        for side in (['after','before'] if i%2==0 else ['before','after']):
            sample(group,f'noop-{i}-{side}',side,'noop',command,latest[side]['target'])
    if name=='iteration-production':
        for side in ['before','after']:
            row=sample(group,'semantic-integration-build-'+side,side,'semantic-build',
                ['cargo','test','--locked','--offline','-j','2','-p','lang-frontend','--test','ownership_iteration','--no-run','--message-format=json'],latest[side]['target'])
            sample(group,'semantic-integration-run-'+side,side,'semantic-run',[binary(row),'--test-threads=1'],latest[side]['target'],184)
    summarize(group)
    save(group/'outcome.json',{'status':'measured','samples':len(json.loads((group/'samples.json').read_text())),
                            'acceptance':'not approved','duration_from_batch_start_seconds':time.monotonic()-START})
    cleanup_targets(group)
    print('GROUP COMPLETE '+name,flush=True)


def main():
    mode=sys.argv[1] if len(sys.argv)>1 else 'frontend'
    if mode in ['rustc','link']:return wrapper(mode)
    if mode=='selftest':return timer_selftest()
    RUN.mkdir(exist_ok=True)
    data=json.loads((HERE/'static-review.json').read_text())
    pairs={r['name']:{'before':r['before'],'after':r['after']} for r in data['pairs']}
    for wrapper_mode in ['rustc','link']:
        path=RUN/(wrapper_mode+'-wrapper')
        path.write_text('#!/bin/sh\nexec '+sys.executable+' '+str(Path(__file__).resolve())+' '+wrapper_mode+' "$@"\n')
        path.chmod(0o755)
    selected=CONFIGS[:6] if mode=='frontend' else [c for c in CONFIGS if c[0]==mode]
    if not selected:raise RuntimeError('unknown selection')
    protocol={
        'version':1,'host_clock_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
        'main':get('git','rev-parse','HEAD',cwd=REPO),'rustc':get('rustc','-vV'),'cargo':get('cargo','-V'),
        'host':get('uname','-a'),'os_release':Path('/etc/os-release').read_text(),
        'cc':get('/usr/bin/cc','--version'),'python':sys.version,'jobs':JOBS,'incremental':0,
        'profile':'default debug; all inherited CARGO_PROFILE_* removed','test_threads':1,
        'limits':{'seconds':7200,'command_seconds':1200,'free_bytes':8*GiB,'new_targets_bytes':10*GiB,'start_min_mem_available_gib':1.5},
        'method':(HERE/'plan.md').read_text(), 'script_sha256':digest(Path(__file__)),
        'matrix':selected,'pairs':pairs,'samples':{'cold_pairs':3,'warm_pairs':5,'warm_run_pairs':10,'noop_pairs':3},
        'calibration':{'before_prebuild':1,'before_warm':3,'before_runs':10,'first_launch_separate_after_every_build':True},
        'noise':{'scaled_mad':'1.4826*MAD > max(5ms,10% median)','range':'range > max(20ms,30% median)','scope':'diagnostic, does not discard or retry'},
        'investigation':{'build':'max(20%,1s)','rss':'max(10%,64MiB)','run':'max(30%,20ms)'},
        'acceptance':'not owner accepted; descriptive finite samples, no equivalence claim',
        'cleanup':'Only this probe newly created group/targets after all raw/source/command/environment and binary hashes saved',
        'llvm_prefix':os.environ.get('LLVM_SYS_211_PREFIX'),
        'relevant_env':{k:os.environ[k] for k in ['CARGO_HOME','RUSTUP_HOME','PATH','LLVM_SYS_211_PREFIX','LD_LIBRARY_PATH'] if k in os.environ},
    }
    protocol_path=RUN/('protocol-'+mode+'.json')
    if protocol_path.exists():raise RuntimeError('protocol/run already exists; no silent retry')
    save(protocol_path,protocol)
    timer_selftest()
    for cfg in selected:
        try:run_group(cfg,pairs)
        except Exception as ex:
            group=RUN/cfg[0]
            if (group/'samples.json').exists():summarize(group)
            save(group/'outcome.json',{'status':'stopped','reason':repr(ex),'elapsed_seconds':time.monotonic()-START})
            raise
    save(RUN/('outcome-'+mode+'.json'),{'status':'measured','groups':[c[0] for c in selected],'seconds':time.monotonic()-START})


if __name__=='__main__':main()
