# Koven P2 Linux 证据移交

> **性质**：本批移交说明 · **状态**：证据交接，Spec/分支纳入由接收任务完成 · **读取时机**：将云端验证移交 Mac 时 · **唯一真源**：本说明只规定包的读取与导入边界，验收结论见 report-final.md

## 入口

- `report-final.md`：十组成本结果、失败/中断、方法口径和剩余接受事项
- `independent-audit.md/.json`：从 raw 独立重算的身份、顺序、噪声/调查线与资源核验
- `semantic-coverage-audit.md/.json`：历史迁移、非默认套件与当前精确 head CI 的覆盖边界
- `frontend-validation/frontend-report.md`：基线 main 全量 1701 passed / 2 failed；失败不可覆盖
- `frontend-fix/frontend-fix-report.md` 与 format-patch：修后全量 1704 passed；两测试文件补丁及应用树校验
- `run-*/.../samples.json` 与 `raw/`：原始成本记录；原 summary.json 和冻结探针不修改
- `summary-v2.json`、汇总修正版与回归测试：如已生成，以 final 报告所记为准；只重新计算，不新增成本样本
- `original-sha256.json`、`published-sha256.json`、`redaction.json`：发布字节、原始字节摘要对应与脱敏范围

## 接收步骤

1. 先核父任务提供的压缩包 SHA256；安全解包到新的临时目录，逐项核 published-sha256（可在审阅后仅运行 python3 verify_transfer.py <解包目录>，此工具不执行任何样本）。不要直接运行包里的采样脚本
2. 核 Mac 仓库当前分支、未提交改动与 main 关系；保留用户改动，不 reset，不切走正在进行的工作
3. 按仓库当前 AGENTS 和文档生命周期，从 main 新建 feature/spec-<新编号> 或 fix/spec-<新编号>；编号需查当前全局 inventory，不能照本云端历史猜测
4. 建议将本包放入新证据目录 `docs/development/evidence/p2-linux-20261005/`。在 live development 索引、治理账本与新 Spec 链接该目录中的 report-final.md，不机械导入旧 draft
5. 将已授权完成的frontend两测试补丁和汇总v2修复纳入新Spec/分支，先核patch对Mac当前main的适用性。保持现行 Guide 语义，不改生产实现迎合旧测试；测量工具修复只能重算保留 raw，不覆盖冻结探针/原 summary/旧失败
6. 纳入后运行文档门禁、whitespace 检查及修复相关实际验收；记录命令、profile、精确 SHA、通过/失败/未运行状态。后续分支的 CI 与本包 current-main CI 分列
7. 由用户明确决定可接受噪声与退化预算。未经此决定，不能将“十组采样完成”“未触某调查线”“历史 CI 成功”简写为 P2 完成

## 数据边界

本包携带 text-only 证据、失败/中断 raw、命令/环境白名单、身份、统计、工具源代码及摘要。不包含 Cargo target、工具链二进制、下载包、凭据、用户缓存或大量重复源快照。每对 git archive 和逐文件原始 SHA256 仍在 source-inputs.json；完整源码快照在云端留存，公开固定 SHA 可重建。

所有已知私密工作区路径用明确 token 替换，不改变 JSON 的数值/布尔/null字段。 archived 脚本中的 token 需先绑定本机真实路径；其保留目的是方法复现，不是导入时自动重测。原始哈希与发布哈希不同是有记录的路径脱敏，不应拿原始 hash 直接验证发布内容。

旧 Mac 的噪声失败与缺失旧 cloud raw 不在本包中被补造或覆盖。旧原始证据继续由原仓库历史记录保存。这个包不宣称已在 Mac 落盘、已创建新 Spec、已提交/推送/PR/合并。
