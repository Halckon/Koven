#!/usr/bin/env python3
import importlib.util
from pathlib import Path
import sys
import rss_support

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_p2',HERE/'probe-frozen-v1.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
p.RUN=HERE/'run-20261005-recovery'
p.RUN.mkdir()
p.CONFIGS=p.CONFIGS[3:6]
p.save(p.RUN/'attempt-context.json',{
    'reason':'Original LSP calibration build stopped with missing offline bitflags1.3.2 before Rust compilation; official cargo fetch now completed',
    'preserved_attempt':str(HERE/'run-20261005/lsp'),
    'unchanged_cost_protocol':str(HERE/'run-20261005/protocol-frontend.json'),
    'change':'Add independent validated C RSS supplement after each group cost samples, before retiring its targets',
    'driver_sha256':p.digest(Path(__file__)),
})
rss_support.freeze(p,p.RUN,[c[0] for c in p.CONFIGS],'Resume remaining frontend/LSP cost groups and append separate test-child RSS evidence')
original_cleanup=p.cleanup_targets
def cleanup(group):
    rss_support.supplement(p,group)
    original_cleanup(group)
p.cleanup_targets=cleanup
sys.argv=[p.__file__,'frontend']
p.main()
