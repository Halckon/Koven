#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc != 2) { return 2; }
    size_t bytes = strtoul(argv[1], NULL, 10) * 1024 * 1024;
    volatile unsigned char *memory = malloc(bytes);
    if (!memory) { return 3; }
    for (size_t i = 0; i < bytes; i += 4096) { memory[i] = 1; }
    fprintf(stderr, "Touched %zu bytes\n", bytes);
    free((void *)memory);
    return 0;
}
