# Koven P2 Linux 独立只读 raw 审计

审计 UTC：2026-10-05T03:19:16.428301+00:00

仅查小 JSON/log、Git 对象元数据与已登记摘要；未构建、执行 benchmark、重哈希源码 tar/大型二进制、压缩、修改仓库或清理 targets。

## 当前结果

完整成本组 10；独立 RSS 补测组 3；所读样本 917；一致性错误 0。

十对完整 SHA、tree 与 changed paths 独立 Git 核对一致。源输入清单差集对照 Git diff；Cargo/lock/toolchain/.cargo 两侧相等。原有400块/九生产文件重核是佐证记录，本次未重新 hash 巨型源码。

## 每组核对

### run-20261005/lsp
状态：stopped；样本 1；raw 小文件 5；事件 2；retirement raw hash 核对 0。
一致性错误：无
警示：无

### run-20261005/multifile-ownership
状态：measured；样本 78；raw 小文件 302；事件 68；retirement raw hash 核对 302。
一致性错误：无
警示：无

### run-20261005/multifile-type
状态：measured；样本 78；raw 小文件 302；事件 68；retirement raw hash 核对 302。
一致性错误：无
警示：无
- 噪声：cold / linker_seconds_sum / after；median=0.219382378s，MAD=0.009963388s，range=0.129608140s

### run-20261005/ownership-iteration
状态：measured；样本 78；raw 小文件 302；事件 68；retirement raw hash 核对 302。
一致性错误：无
警示：无

### run-20261005-codegen/plan-tests
状态：measured；样本 90；raw 小文件 630；事件 360；retirement raw hash 核对 630。
一致性错误：无
警示：Investigation threshold hit: first-launch-cold
- 噪声：cold / auxiliary_rustc_seconds_sum / before；median=0.104526788s，MAD=0.009131419s，range=0.018468023s

### run-20261005-codegen/receiver
状态：measured；样本 90；raw 小文件 630；事件 360；retirement raw hash 核对 630。
一致性错误：无
警示：无
- 噪声：warm / linker_seconds_sum / after；median=0.461963850s，MAD=0.033579850s，range=0.121411809s

### run-20261005-codegen/runtime-layout
状态：measured-after-interruption；样本 90；raw 小文件 630；事件 360；retirement raw hash 核对 632。
一致性错误：无
警示：无
- 噪声：warm / linker_seconds_sum / before；median=0.457401899s，MAD=0.064849373s，range=0.135333287s
- 噪声：rss-run / seconds / after；median=0.191118024s，MAD=0.015574850s，range=0.051658549s
- 噪声：rss-run / c_child_seconds / after；median=0.189613810s，MAD=0.015367349s，range=0.051453251s

### run-20261005-codegen/unit-planner
状态：measured；样本 90；raw 小文件 630；事件 360；retirement raw hash 核对 630。
一致性错误：无
警示：无

### run-20261005-recovery/iteration-production
状态：measured；样本 94；raw 小文件 361；事件 79；retirement raw hash 核对 361。
一致性错误：无
警示：无
- 噪声：warm / linker_seconds_sum / before；median=0.269356181s，MAD=0.019535865s，range=0.071582122s
- 噪声：noop / seconds / before；median=0.038728896s，MAD=0.003634302s，range=0.026967725s

### run-20261005-recovery/iteration-tests
状态：measured；样本 90；raw 小文件 343；事件 73；retirement raw hash 核对 343。
一致性错误：无
警示：无
- 噪声：calibration-rebuild-first-launch / seconds / before；median=0.154692119s，MAD=0.013438036s，range=0.037010882s
- 噪声：calibration-run / seconds / before；median=0.158596517s，MAD=0.002889585s，range=0.048050630s
- 噪声：cold / linker_seconds_sum / after；median=0.323064368s，MAD=0.050245479s，range=0.102040621s
- 噪声：warm / linker_seconds_sum / before；median=0.262857947s，MAD=0.022714207s，range=0.089477220s

### run-20261005-recovery/lsp
状态：measured；样本 90；raw 小文件 616；事件 346；retirement raw hash 核对 616。
一致性错误：无
警示：无

### run-20261005-rss-only/multifile-ownership
状态：RSS measured；样本 16；raw 小文件 72；事件 24；retirement raw hash 核对 72。
一致性错误：无
警示：无

### run-20261005-rss-only/multifile-type
状态：RSS measured；样本 16；raw 小文件 72；事件 24；retirement raw hash 核对 72。
一致性错误：无
警示：无

### run-20261005-rss-only/ownership-iteration
状态：RSS measured；样本 16；raw 小文件 72；事件 24；retirement raw hash 核对 72。
一致性错误：无
警示：无

## 原始调查遗漏与解释

plan-tests 冷产物首启第二对（BA，第1号索引）：0.161750947→0.218992066s，+0.057241119s / +35.3884%，超过 execution max(30%,20ms) 单对调查线；配对中位未触线。冻结 summarize() 只对cold/warm/run做调查标志，遗漏首启。这不是删除或重跑该样本的理由。独立诊断保留，原冻结脚本/summary不改。后续工具修复另见 summary-v2-repair.md，不改本审计的原始发现。

依赖 build-capability probes 和 compiler metadata queries 全部保留为 auxiliary_rustc_records。预期能力探测非零不是目标构建失败；冻结非link总和不含 --crate-name=... 形式，不能称全部 rustc 工作。RSS补测 outer/child墙时另列为诊断，不并入热运行成本cohort。

## 证据边界

- Current Linux libtest --list enumerates complete enabled names, not cfg/ignore metadata for every possible platform/feature. Selected executions separately establish ignored=0 for their cohort.
- Source-inputs SHA256 inventories and existing source archive/binary retirement digests are cross-checked as records. Large source archives, all source files and retired binaries are not independently rehashed in this audit.
- Retirement binary hashes identify the last retained executable at each path, not an independent per-launch binary snapshot; warm recompilations reuse paths.
- Frozen rustc_nonlink_seconds_sum excludes auxiliary wrapper records whose crate name uses --crate-name=... rather than the parsed --crate-name argument. Those raw probes, elapsed times and expected nonzero exits are retained separately; the estimator is not all rustc work.
- Peak RSS is maximum reported waited-process value, not simultaneous process-tree RSS. C RSS source is child-rusage.json, not Python launcher wait4.
- Resource rows are command-boundary observations. Disk has one-second watchdog; targets and MemAvailable do not have continuous in-sample peak enforcement.
- Frozen inquiry thresholds are diagnostic, not accepted budgets; finite observations do not prove equivalence, performance improvement or P2 closure.
- No historical macOS outcomes, missing older cloud raw, main frontend failures, required CI/native/sanitizer obligations or user cost acceptance are superseded.

完整逐阶段原值、paired delta/percent、调查线、资源数、原始记录校验详情见 independent-audit.json。所有失败及噪声原样保留。此审计不代表用户预算接受、不关闭 P2、不证明性能等价。
