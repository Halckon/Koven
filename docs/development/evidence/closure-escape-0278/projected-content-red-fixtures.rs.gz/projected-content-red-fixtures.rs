use super::*;
use crate::ssa::model::PlaceId;

#[derive(Clone, Copy, Debug)]
enum RootWrite {
    ClearInline,
    TaintInline,
    ReplaceSharedHandle,
}

fn append_place(
    function: &mut Function,
    block: BlockId,
    operation: Operation,
    ty: SsaTypeId,
    at: &Origin,
) -> PlaceId {
    let EntityId::Place(place) = function
        .append_instruction(block, operation, vec![EntityType::Place(ty)], at.clone())
        .expect("place operation must have its declared projection type")
        .1[0]
    else {
        panic!("projection must produce a place");
    };
    place
}

fn precreated_field_after_root_write(write: RootWrite) -> (Program, VerifyLocation, Origin) {
    let formation = origin();
    let delivery = delivery_origin("return wrapper");
    let mut program = Program::default();
    let module_id = program.add_module("precreated-field-current-content");
    let module = program.module_mut(module_id).expect("module");
    let (_, _, closure) = shared_closure_type(module);
    let list = module
        .add_sequential_container_type(SequentialContainerKind::List, closure)
        .expect("List retains its possible borrowed closure element type");
    let inner = module.declare_shared_owner("Inner").expect("inner owner");
    module
        .define_shared_owner(inner, list)
        .expect("inner payload");
    let aggregate = module
        .add_aggregate_type("Fields", vec![inner])
        .expect("inline aggregate contains the shared owner field");
    let outer = if matches!(write, RootWrite::ReplaceSharedHandle) {
        let owner = module.declare_shared_owner("Outer").expect("outer owner");
        module
            .define_shared_owner(owner, aggregate)
            .expect("outer allocation holds the aggregate payload");
        Some(owner)
    } else {
        None
    };
    let root_type = outer.unwrap_or(aggregate);
    let (id, entry, parameters) = add_function(
        module,
        "overwrite_then_retain_field",
        &[root_type],
        vec![inner],
        &formation,
    );
    let function = module.function_mut(id).expect("function");
    let empty = append_values(
        function,
        entry,
        Operation::ContainerConstruct {
            container: list,
            elements: vec![],
        },
        &[list],
        &formation,
    )[0];
    let clean_inner = append_values(
        function,
        entry,
        Operation::SharedAllocate {
            owner: inner,
            payload: empty,
        },
        &[inner],
        &formation,
    )[0];
    // Dirty aggregate contents arrive directly as an entry owner, never through a
    // forbidden AggregateConstruct of unknown borrowed-closure storage.
    let clean_aggregate = append_values(
        function,
        entry,
        Operation::AggregateConstruct {
            aggregate,
            fields: vec![clean_inner],
        },
        &[aggregate],
        &formation,
    )[0];
    let owner = if matches!(write, RootWrite::TaintInline) {
        clean_aggregate
    } else {
        parameters[0]
    };
    let root = append_place(
        function,
        entry,
        Operation::RootPlace { owner },
        root_type,
        &formation,
    );
    let (field_base, retained_outer) = if let Some(outer) = outer {
        // Keep the old allocation alive independently of replacing the original
        // handle. Its existing payload/field projections still address old contents.
        let retained = append_values(
            function,
            entry,
            Operation::SharedRetain {
                owner: EntityId::Value(owner),
            },
            &[outer],
            &formation,
        )[0];
        let payload = append_place(
            function,
            entry,
            Operation::SharedPayloadPlace {
                owner: EntityId::Value(owner),
            },
            aggregate,
            &formation,
        );
        (payload, Some(retained))
    } else {
        (root, None)
    };
    let field = append_place(
        function,
        entry,
        Operation::FieldPlace {
            base: field_base,
            field: 0,
        },
        inner,
        &formation,
    );
    let replacement = match write {
        RootWrite::ClearInline => clean_aggregate,
        RootWrite::TaintInline => parameters[0],
        RootWrite::ReplaceSharedHandle => append_values(
            function,
            entry,
            Operation::SharedAllocate {
                owner: outer.expect("shared handle case has an outer owner type"),
                payload: clean_aggregate,
            },
            &[root_type],
            &formation,
        )[0],
    };
    append_values(
        function,
        entry,
        Operation::Mutate {
            place: root,
            value: replacement,
        },
        &[],
        &formation,
    );
    // No loan existed during the whole-root write. The pre-created field place
    // is borrowed only after the replacement has committed.
    let EntityId::Loan(loan) = function
        .append_instruction(
            entry,
            Operation::BorrowBegin {
                place: field,
                kind: LoanKind::Shared,
            },
            vec![EntityType::Loan {
                kind: LoanKind::Shared,
                target: inner,
            }],
            formation.clone(),
        )
        .expect("field loan must borrow the complete inner shared owner")
        .1[0]
    else {
        panic!("field borrow must produce a loan");
    };
    let retained_inner = append_values(
        function,
        entry,
        Operation::SharedRetain {
            owner: EntityId::Loan(loan),
        },
        &[inner],
        &formation,
    )[0];
    append_values(
        function,
        entry,
        Operation::BorrowEnd { loan },
        &[],
        &formation,
    );
    append_values(function, entry, Operation::Drop { owner }, &[], &formation);
    if let Some(owner) = retained_outer {
        append_values(function, entry, Operation::Drop { owner }, &[], &formation);
    }
    function
        .set_terminator(
            entry,
            TerminatorKind::Return {
                values: vec![retained_inner],
            },
            delivery.clone(),
        )
        .expect("Return delivers only the independently retained inner owner");
    (program, VerifyLocation::Terminator(entry), delivery)
}

#[test]
fn borrowed_closure_projected_content_allows_inline_field_after_whole_root_clear() {
    verify_program(&precreated_field_after_root_write(RootWrite::ClearInline).0)
        .expect("existing inline field projection must see the new clean root contents");
}

#[test]
fn borrowed_closure_projected_content_rejects_inline_field_after_whole_root_taint() {
    assert_owned_escape_rejected(precreated_field_after_root_write(RootWrite::TaintInline));
}

#[test]
fn borrowed_closure_projected_content_rejects_old_shared_payload_after_handle_clear() {
    assert_owned_escape_rejected(precreated_field_after_root_write(
        RootWrite::ReplaceSharedHandle,
    ));
}
