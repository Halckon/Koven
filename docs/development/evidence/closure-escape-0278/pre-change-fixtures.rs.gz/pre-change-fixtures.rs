use super::*;
use crate::ssa::{
    model::SequentialContainerKind,
    verify::{VerifyError, VerifyLocation},
};

const ESCAPE_REASON: &str = "borrowed closure cannot escape through owned value delivery";

fn delivery_origin(fragment: &str) -> Origin {
    let text = "val closure = { value }\nreturn closure\nconsume(closure)\nreturn wrapper\n";
    let mut sources = SourceMap::default();
    let source = sources
        .add_source("closure-escape-ssa.ko", text)
        .expect("test source must be unique");
    let start = text.find(fragment).expect("delivery must occur in source");
    Origin::Source(
        sources
            .span(source, start, start + fragment.len())
            .expect("delivery span must be valid"),
    )
}

fn shared_closure_type(module: &mut Module) -> (SsaTypeId, SsaTypeId, SsaTypeId) {
    let integer = module.intern_type(SsaTypeKind::Integer {
        bits: 64,
        signed: true,
    });
    let reference = module
        .add_shared_reference_type(integer)
        .expect("shared Int reference must be valid");
    let environment = module
        .add_aggregate_type("BorrowedEnv", vec![reference])
        .expect("shared capture environment must be valid");
    let closure = module
        .add_concrete_closure_type(
            "BorrowedClosure",
            vec![],
            vec![],
            environment,
            vec![ClosureCaptureType {
                mode: ClosureCaptureMode::Shared,
                ty: integer,
            }],
        )
        .expect("shared capture descriptor must match environment storage");
    (integer, environment, closure)
}

fn borrowed_factory_return() -> (Program, VerifyLocation, Origin) {
    let formation = origin();
    let delivery = delivery_origin("return closure");
    let mut program = Program::default();
    let module_id = program.add_module("borrowed-factory-escape");
    let module = program.module_mut(module_id).expect("module must exist");
    let (integer, environment, closure) = shared_closure_type(module);
    let (thunk, thunk_entry, _) = add_thunk(module, "thunk", environment, &[], vec![], &formation);
    module
        .function_mut(thunk)
        .expect("thunk must exist")
        .set_terminator(
            thunk_entry,
            TerminatorKind::Return { values: vec![] },
            formation.clone(),
        )
        .expect("thunk must terminate without consuming its borrowed environment");

    let factory = module
        .add_function("factory", vec![closure], formation.clone())
        .expect("factory signature must return the concrete closure");
    let function = module.function_mut(factory).expect("factory must exist");
    let entry = function
        .add_block(
            vec![EntityType::Loan {
                kind: LoanKind::Shared,
                target: integer,
            }],
            formation.clone(),
        )
        .expect("Borrow Int entry must be valid");
    let EntityId::Loan(loan) = function.block(entry).expect("entry must exist").parameters[0]
    else {
        panic!("factory parameter must remain a shared loan");
    };
    let captured = append_values(
        function,
        entry,
        Operation::ClosureConstruct {
            closure,
            thunk,
            captures: vec![ClosureCaptureOperand::Shared(loan)],
        },
        &[closure],
        &formation,
    )[0];
    function
        .set_terminator(
            entry,
            TerminatorKind::Return {
                values: vec![captured],
            },
            delivery.clone(),
        )
        .expect("Return must deliver the well-typed closure");
    (program, VerifyLocation::Terminator(entry), delivery)
}

fn entry_closure_value_call() -> (Program, VerifyLocation, Origin) {
    let formation = origin();
    let delivery = delivery_origin("consume(closure)");
    let mut program = Program::default();
    let module_id = program.add_module("entry-closure-value-call");
    let module = program.module_mut(module_id).expect("module must exist");
    let (_, _, closure) = shared_closure_type(module);
    let (callee, callee_entry, parameters) =
        add_function(module, "consume", &[closure], vec![], &formation);
    let function = module.function_mut(callee).expect("callee must exist");
    append_values(
        function,
        callee_entry,
        Operation::Drop {
            owner: parameters[0],
        },
        &[],
        &formation,
    );
    function
        .set_terminator(
            callee_entry,
            TerminatorKind::Return { values: vec![] },
            formation.clone(),
        )
        .expect("callee must discharge its entry owner before returning");
    let (caller, entry, parameters) =
        add_function(module, "forward", &[closure], vec![], &formation);
    let function = module.function_mut(caller).expect("caller must exist");
    let (call, results) = function
        .append_instruction(
            entry,
            Operation::DirectCall {
                callee,
                receiver: None,
                arguments: vec![EntityId::Value(parameters[0])],
            },
            vec![],
            delivery.clone(),
        )
        .expect("Value call signature and result arity must be valid");
    assert!(results.is_empty());
    function
        .set_terminator(entry, TerminatorKind::Return { values: vec![] }, formation)
        .expect("caller must return after delivering its entry owner once");
    (program, VerifyLocation::Instruction(call), delivery)
}

fn entry_container_return() -> (Program, VerifyLocation, Origin) {
    let formation = origin();
    let delivery = delivery_origin("return wrapper");
    let mut program = Program::default();
    let module_id = program.add_module("entry-container-closure-escape");
    let module = program.module_mut(module_id).expect("module must exist");
    let (_, _, closure) = shared_closure_type(module);
    let wrapper = module
        .add_sequential_container_type(SequentialContainerKind::List, closure)
        .expect("List storage must retain its concrete closure element type");
    let (function_id, entry, parameters) =
        add_function(module, "forward", &[wrapper], vec![wrapper], &formation);
    module
        .function_mut(function_id)
        .expect("function must exist")
        .set_terminator(
            entry,
            TerminatorKind::Return {
                values: vec![parameters[0]],
            },
            delivery.clone(),
        )
        .expect("Return must match the List signature and consume its entry owner once");
    (program, VerifyLocation::Terminator(entry), delivery)
}

fn assert_owned_escape_rejected((program, location, origin): (Program, VerifyLocation, Origin)) {
    let errors = verify_program(&program)
        .expect_err("well-typed owned delivery must reject the borrowed closure escape");
    // A different type/loan/ownership error cannot stand in for the escape defense.
    assert_eq!(
        errors.errors,
        vec![VerifyError {
            kind: VerifyErrorKind::OperationContract {
                reason: ESCAPE_REASON,
            },
            location,
            origin: Some(origin),
        }]
    );
}

#[test]
fn borrowed_closure_escape_rejects_factory_return_at_delivery_origin() {
    assert_owned_escape_rejected(borrowed_factory_return());
}

#[test]
fn borrowed_closure_escape_rejects_entry_value_call_at_delivery_origin() {
    assert_owned_escape_rejected(entry_closure_value_call());
}

#[test]
fn borrowed_closure_escape_rejects_entry_container_return_at_delivery_origin() {
    assert_owned_escape_rejected(entry_container_return());
}

// Temporary pre-change evidence: remove after the root records old-verifier acceptance
// and the three formal rejection tests fail, before installing the new verifier defense.
#[test]
fn borrowed_closure_escape_old_verifier_accepts_all_three_fixtures() {
    for (name, fixture) in [
        ("Borrow Int factory Return", borrowed_factory_return()),
        ("entry closure Value call", entry_closure_value_call()),
        (
            "entry List<borrowed closure> Return",
            entry_container_return(),
        ),
    ] {
        verify_program(&fixture.0).unwrap_or_else(|errors| {
            panic!("baseline fixture {name} must already verify: {errors:?}")
        });
    }
}
