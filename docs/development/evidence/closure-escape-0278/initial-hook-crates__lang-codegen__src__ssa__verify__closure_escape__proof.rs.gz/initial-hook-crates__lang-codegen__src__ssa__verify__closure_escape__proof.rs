//! Program-point content proofs. These facts never replace capture-loan lifetime checks.

use std::collections::{BTreeMap, VecDeque};

use super::TypeCaptures;
use crate::ssa::{
    model::{ClosureCaptureOperand, EntityId, Function, Instruction, Operation, PlaceId, ValueId},
    verify_ownership::{AliasRoots, edges, root_exchange},
};

pub(super) type State = Vec<bool>;

pub(super) struct ValueProof<'a> {
    function: &'a Function,
    defaults: State,
    projected: Vec<bool>,
    affected: BTreeMap<EntityId, Vec<(usize, bool)>>,
}

impl<'a> ValueProof<'a> {
    pub(super) fn new(function: &'a Function, types: &TypeCaptures) -> Self {
        let defaults = function
            .values
            .iter()
            .map(|entity| types.contains(entity.ty.semantic_type()))
            .collect::<Vec<_>>();
        let aliases = AliasRoots::compute(function);
        let mut affected = BTreeMap::new();
        for instruction in &function.instructions {
            let access = match instruction.operation {
                Operation::Mutate { place, .. } => EntityId::Place(place),
                Operation::HeapFieldReplace { receiver, .. }
                | Operation::InlineFieldReplace { receiver, .. } => EntityId::Loan(receiver),
                Operation::HeapFieldExchange { owner, .. }
                | Operation::ContainerReplace { owner, .. } => EntityId::Value(owner),
                _ => continue,
            };
            affected.entry(access).or_insert_with(|| {
                function
                    .values
                    .iter()
                    .enumerate()
                    .filter_map(|(index, _)| {
                        let owner = ValueId {
                            function: function.id,
                            index,
                        };
                        if !defaults[index] || !aliases.overlap(access, EntityId::Value(owner)) {
                            return None;
                        }
                        let exact = match access {
                            EntityId::Place(place) => {
                                root_exchange::exact_place(function, owner, place, &aliases)
                            }
                            _ => false,
                        };
                        Some((index, exact))
                    })
                    .collect()
            });
        }
        Self {
            function,
            defaults,
            projected: projected_places(function, &aliases),
            affected,
        }
    }

    pub(super) fn is_projected(&self, place: PlaceId) -> bool {
        self.projected[place.index()]
    }

    /// OR joins preserve proofs only when every incoming execution is known clean.
    pub(super) fn block_entries(&self) -> Vec<State> {
        let function = self.function;
        let mut reachable = vec![false; function.blocks.len()];
        let mut pending = VecDeque::from([0]);
        reachable[0] = true;
        while let Some(index) = pending.pop_front() {
            for edge in edges(
                &function.blocks[index]
                    .terminator
                    .as_ref()
                    .expect("verified terminator")
                    .kind,
            ) {
                if !reachable[edge.target.index()] {
                    reachable[edge.target.index()] = true;
                    pending.push_back(edge.target.index());
                }
            }
        }
        let mut entries = vec![None; function.blocks.len()];
        let mut queued = vec![false; function.blocks.len()];
        for index in 0..function.blocks.len() {
            // Unreachable components have no caller proof, including closed CFG cycles.
            if index == 0 || !reachable[index] {
                entries[index] = Some(self.defaults.clone());
                queued[index] = true;
                pending.push_back(index);
            }
        }
        while let Some(index) = pending.pop_front() {
            queued[index] = false;
            let mut state = entries[index]
                .as_ref()
                .expect("queued entry exists")
                .clone();
            let block = &function.blocks[index];
            for id in &block.instructions {
                self.apply(
                    function.instruction(*id).expect("verified instruction"),
                    &mut state,
                );
            }
            for edge in edges(&block.terminator.as_ref().expect("verified terminator").kind) {
                let target = function.block(edge.target).expect("verified target");
                let rebound = edge
                    .arguments
                    .iter()
                    .zip(&target.parameters)
                    .filter_map(|(argument, parameter)| match (argument, parameter) {
                        (EntityId::Value(argument), EntityId::Value(parameter)) => {
                            Some((parameter.index(), state[argument.index()]))
                        }
                        _ => None,
                    })
                    .collect::<Vec<_>>();
                let mut incoming = state.clone();
                for (parameter, may_capture) in rebound {
                    incoming[parameter] = may_capture;
                }
                let changed = match &mut entries[edge.target.index()] {
                    None => {
                        entries[edge.target.index()] = Some(incoming);
                        true
                    }
                    Some(previous) => {
                        let mut changed = false;
                        for (previous, incoming) in previous.iter_mut().zip(incoming) {
                            if incoming && !*previous {
                                *previous = true;
                                changed = true;
                            }
                        }
                        changed
                    }
                };
                if changed && !queued[edge.target.index()] {
                    queued[edge.target.index()] = true;
                    pending.push_back(edge.target.index());
                }
            }
        }
        entries
            .into_iter()
            .map(|entry| entry.expect("all components were seeded"))
            .collect()
    }

    pub(super) fn apply(&self, instruction: &Instruction, state: &mut State) {
        let may = |value: ValueId| state[value.index()];
        let results = instruction
            .results
            .iter()
            .filter_map(|entity| match entity {
                EntityId::Value(value) => Some(*value),
                _ => None,
            })
            .collect::<Vec<_>>();
        let proof = match &instruction.operation {
            Operation::FunctionAddress { .. } | Operation::NullableNull { .. } => Some(false),
            Operation::ClosureConstruct { captures, .. } => {
                Some(captures.iter().any(|capture| match capture {
                    ClosureCaptureOperand::Shared(_) => true,
                    ClosureCaptureOperand::Owned(value) => may(*value),
                }))
            }
            Operation::AggregateConstruct { fields, .. } => Some(fields.iter().copied().any(may)),
            Operation::ContainerConstruct { elements, .. } => {
                Some(elements.iter().copied().any(may))
            }
            Operation::TaggedConstruct { payload, .. }
            | Operation::HeapAllocate { payload, .. }
            | Operation::SharedAllocate { payload, .. } => Some(may(*payload)),
            Operation::NullableWrap { owner, .. }
            | Operation::NullableTake { owner, .. }
            | Operation::RootPlaceTake { owner, .. } => Some(may(*owner)),
            Operation::Copy { source } => Some(may(*source)),
            Operation::SharedRetain {
                owner: EntityId::Value(owner),
            } => Some(may(*owner)),
            Operation::AggregateProject { aggregate, .. }
            | Operation::AggregateExplode { aggregate }
            | Operation::AggregateCopyExplode { aggregate }
                if !may(*aggregate) =>
            {
                Some(false)
            }
            Operation::RootReplace {
                owner, replacement, ..
            } => {
                let old = may(*owner);
                let replacement = may(*replacement);
                state[results[0].index()] = replacement;
                state[results[1].index()] = old;
                return;
            }
            Operation::RootSwap { owners, .. } => {
                let left = may(owners[0]);
                let right = may(owners[1]);
                state[results[0].index()] = right;
                state[results[1].index()] = left;
                return;
            }
            Operation::HeapFieldExchange { owner, .. } if !may(*owner) => Some(false),
            _ => None,
        };
        let write = match instruction.operation {
            Operation::Mutate { place, value } => Some((
                EntityId::Place(place),
                may(value),
                !self.is_projected(place),
            )),
            Operation::HeapFieldReplace {
                receiver, value, ..
            }
            | Operation::InlineFieldReplace {
                receiver, value, ..
            } => Some((EntityId::Loan(receiver), may(value), false)),
            Operation::HeapFieldExchange {
                owner, replacement, ..
            } => Some((EntityId::Value(owner), may(replacement), false)),
            Operation::ContainerReplace { owner, value, .. } => {
                Some((EntityId::Value(owner), may(value), false))
            }
            _ => None,
        };
        if let Some((access, replacement, whole_root)) = write {
            for (owner, exact) in &self.affected[&access] {
                // Equal overlap sets alone do not prove owner/place pairing across CFG joins.
                if whole_root && *exact {
                    state[*owner] = replacement;
                } else {
                    state[*owner] |= replacement;
                }
            }
        }
        for result in results {
            state[result.index()] = self.defaults[result.index()] && proof.unwrap_or(true);
        }
    }
}

/// A mixed root/projected CFG join is a possible storage write, never a proven local root.
fn projected_places(function: &Function, aliases: &AliasRoots) -> Vec<bool> {
    let mut projected = vec![false; function.places.len()];
    let mut incoming = vec![false; function.places.len()];
    for block in &function.blocks {
        for edge in edges(&block.terminator.as_ref().expect("verified terminator").kind) {
            for parameter in &function
                .block(edge.target)
                .expect("verified target")
                .parameters
            {
                if let EntityId::Place(place) = parameter {
                    incoming[place.index()] = true;
                }
            }
        }
    }
    for block in &function.blocks {
        for parameter in &block.parameters {
            if let EntityId::Place(place) = parameter {
                projected[place.index()] = !incoming[place.index()]
                    || !aliases.overlap(EntityId::Place(*place), EntityId::Place(*place));
            }
        }
    }
    for instruction in &function.instructions {
        if matches!(
            instruction.operation,
            Operation::FieldPlace { .. }
                | Operation::ContainerElementPlace { .. }
                | Operation::TaggedPayloadPlace { .. }
                | Operation::HeapPayloadPlace { .. }
                | Operation::SharedPayloadPlace { .. }
        ) {
            let EntityId::Place(place) = instruction.results[0] else {
                unreachable!("verified place result")
            };
            projected[place.index()] = true;
        }
    }
    loop {
        let mut changed = false;
        for block in &function.blocks {
            for edge in edges(&block.terminator.as_ref().expect("verified terminator").kind) {
                for (argument, parameter) in edge.arguments.iter().zip(
                    &function
                        .block(edge.target)
                        .expect("verified target")
                        .parameters,
                ) {
                    if let (EntityId::Place(argument), EntityId::Place(parameter)) =
                        (argument, parameter)
                        && projected[argument.index()]
                        && !projected[parameter.index()]
                    {
                        projected[parameter.index()] = true;
                        changed = true;
                    }
                }
            }
        }
        if !changed {
            break;
        }
    }
    projected
}
